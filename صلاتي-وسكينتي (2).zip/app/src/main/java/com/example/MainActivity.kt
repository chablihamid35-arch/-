package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.ThemeLightingMode
import com.example.ui.SalatiViewModel
import com.example.ui.screens.GleasonQiblaScreen
import com.example.ui.screens.PrayerTimesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SpiritualReliefScreen
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: SalatiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            val isDark = when (uiState.themeLightingMode) {
                ThemeLightingMode.LIGHT -> false
                ThemeLightingMode.DARK -> true
                ThemeLightingMode.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            MyApplicationTheme(darkTheme = isDark) {
                SalatiMainApp(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDndStatus()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalatiMainApp(viewModel: SalatiViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Request permissions launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            viewModel.detectGpsLocation()
        }
    }

    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            permissionsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (permissionsToRequest.isNotEmpty()) {
            permissionsLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    // Show message toast / snackbar
    LaunchedEffect(uiState.messageToast) {
        uiState.messageToast?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    // Handle layout direction and localization
    val baseConfiguration = androidx.compose.ui.platform.LocalConfiguration.current
    val locale: Locale = remember(uiState.selectedLanguage) {
        when (uiState.selectedLanguage) {
            "en" -> Locale.ENGLISH
            "fr" -> Locale.FRENCH
            else -> Locale("ar")
        }
    }
    val localizedConfig = remember(locale, baseConfiguration) {
        android.content.res.Configuration(baseConfiguration).apply {
            setLocale(locale)
            setLayoutDirection(locale)
        }
    }
    val localizedContext = remember(locale, context, localizedConfig) {
        context.createConfigurationContext(localizedConfig)
    }
    val layoutDirection = if (uiState.selectedLanguage == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        androidx.compose.ui.platform.LocalConfiguration provides localizedConfig,
        LocalContext provides localizedContext,
        LocalLayoutDirection provides layoutDirection
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.NightsStay,
                                contentDescription = null,
                                tint = IslamicGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.app_name),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 19.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    actions = {
                        IconButton(
                            onClick = { viewModel.toggleQuickLighting() },
                            modifier = Modifier.testTag("quick_lighting_toggle")
                        ) {
                            val (icon, tint) = when (uiState.themeLightingMode) {
                                ThemeLightingMode.LIGHT -> Pair(Icons.Default.WbSunny, IslamicGold)
                                ThemeLightingMode.DARK -> Pair(Icons.Default.NightsStay, AccentGreen)
                                ThemeLightingMode.SYSTEM -> Pair(Icons.Default.BrightnessAuto, MaterialTheme.colorScheme.primary)
                            }
                            Icon(
                                imageVector = icon,
                                contentDescription = stringResource(R.string.quick_lighting_toggle),
                                tint = tint
                            )
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple(0, R.string.tab_prayer, Icons.Default.AccessTime),
                        Triple(1, R.string.tab_relief, Icons.Default.VolunteerActivism),
                        Triple(2, R.string.tab_qibla, Icons.Default.Explore),
                        Triple(3, R.string.tab_settings, Icons.Default.Settings)
                    )

                    tabs.forEach { (index, titleRes, icon) ->
                        NavigationBarItem(
                            selected = uiState.currentTab == index,
                            onClick = { viewModel.setTab(index) },
                            icon = { Icon(icon, contentDescription = stringResource(titleRes)) },
                            label = {
                                Text(
                                    text = stringResource(titleRes),
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (uiState.currentTab) {
                    0 -> PrayerTimesScreen(viewModel = viewModel, uiState = uiState)
                    1 -> SpiritualReliefScreen(viewModel = viewModel, uiState = uiState)
                    2 -> GleasonQiblaScreen(viewModel = viewModel, uiState = uiState)
                    3 -> SettingsScreen(viewModel = viewModel, uiState = uiState)
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "صلاتي وسكينتي $name", modifier = modifier)
}
