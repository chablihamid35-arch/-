package com.example.model

enum class PrayerType(val displayNameAr: String, val displayNameEn: String, val displayNameFr: String) {
    FAJR("الفجر", "Fajr", "Fajr"),
    SUNRISE("الشروق", "Sunrise", "Chourouq"),
    DHUHR("الظهر", "Dhuhr", "Dohr"),
    ASR("العصر", "Asr", "Asr"),
    MAGHRIB("المغرب", "Maghrib", "Maghreb"),
    ISHA("العشاء", "Isha", "Icha");

    fun localizedName(lang: String): String {
        return when (lang) {
            "fr" -> displayNameFr
            "en" -> displayNameEn
            else -> displayNameAr
        }
    }
}

data class PrayerTimeItem(
    val type: PrayerType,
    val timeFormatted: String,
    val timeMillis: Long,
    val isNext: Boolean = false,
    val isCurrent: Boolean = false
)

enum class CalculationMethod(
    val titleAr: String,
    val titleEn: String,
    val titleFr: String
) {
    UMM_AL_QURA("أم القرى (مكة المكرمة)", "Umm Al-Qura (Makkah)", "Oumm Al-Qura (La Mecque)"),
    MUSLIM_WORLD_LEAGUE("رابطة العالم الإسلامي", "Muslim World League", "Ligue Islamique Mondiale"),
    EGYPTIAN("الهيئة المصرية العامة للمساحة", "Egyptian General Authority", "Autorité Générale Égyptienne"),
    KARACHI("جامعة العلوم الإسلامية بكراتشي", "University of Islamic Sciences, Karachi", "Université des Sciences Islamiques, Karachi"),
    NORTH_AMERICA("الجمعية الإسلامية لأمريكا الشمالية (ISNA)", "Islamic Society of North America (ISNA)", "Société Islamique d'Amérique du Nord (ISNA)");

    fun localizedTitle(lang: String): String = when (lang) {
        "fr" -> titleFr
        "en" -> titleEn
        else -> titleAr
    }
}

enum class AsrJuristic(
    val titleAr: String,
    val titleEn: String,
    val titleFr: String
) {
    STANDARD(
        "الجمهور (الشافعي، المالكي، الحنبلي)",
        "Standard (Shafi'i, Maliki, Hanbali)",
        "Standard (Chaféite, Malékite, Hanbalite)"
    ),
    HANAFI(
        "الحنفي (ضعف الظل)",
        "Hanafi (Double shadow)",
        "Hanafite (Double ombre)"
    );

    fun localizedTitle(lang: String): String = when (lang) {
        "fr" -> titleFr
        "en" -> titleEn
        else -> titleAr
    }
}

enum class SilenceRingerMode {
    SILENT,
    VIBRATE
}

enum class ThemeLightingMode(
    val titleAr: String,
    val titleEn: String,
    val titleFr: String
) {
    LIGHT("نهاري مشرق (إضاءة كاملة)", "Bright Daylight (Full Light)", "Jour lumineux (Plein éclat)"),
    DARK("ليلي هادئ (مضيء)", "Calm Night (Illuminated)", "Nuit paisible (Éclairé)"),
    SYSTEM("تلقائي النظام", "System Default", "Selon le système");

    fun localizedTitle(lang: String): String = when (lang) {
        "fr" -> titleFr
        "en" -> titleEn
        else -> titleAr
    }
}

data class SpiritualReliefResponse(
    val id: String = System.currentTimeMillis().toString(),
    val problem: String,
    val comfortMessage: String,
    val quranAyah: String,
    val quranReference: String,
    val hadith: String,
    val hadithSource: String,
    val salafQuote: String,
    val salafAuthor: String,
    val dua: String,
    val timestamp: Long = System.currentTimeMillis()
)
