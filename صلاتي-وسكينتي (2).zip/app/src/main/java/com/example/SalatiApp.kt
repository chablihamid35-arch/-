package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class SalatiApp : Application() {

    companion object {
        const val CHANNEL_PRAYER_ALERTS = "prayer_alerts_channel"
        const val CHANNEL_HOURLY_WISDOM = "hourly_wisdom_channel"
        lateinit var instance: SalatiApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val prayerChannel = NotificationChannel(
                CHANNEL_PRAYER_ALERTS,
                "أوقات الصلاة وكتم الصوت",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات أوقات الصلاة وكتم الصوت التلقائي"
                enableVibration(true)
            }

            val wisdomChannel = NotificationChannel(
                CHANNEL_HOURLY_WISDOM,
                "نفحات الفرج واليقين",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "آيات وأحاديث صحيحة لتفريج الكروب وتجديد اليقين"
                enableVibration(true)
            }

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(prayerChannel)
            notificationManager.createNotificationChannel(wisdomChannel)
        }
    }
}
