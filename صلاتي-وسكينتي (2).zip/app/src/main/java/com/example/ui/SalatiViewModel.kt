package com.example.ui

import android.app.Application
import android.content.Context
import android.location.LocationManager
import android.os.CountDownTimer
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

data class CityPreset(
    val nameAr: String,
    val nameEn: String,
    val nameFr: String,
    val lat: Double,
    val lon: Double
) {
    fun localizedName(lang: String): String = when (lang) {
        "fr" -> nameFr
        "en" -> nameEn
        else -> nameAr
    }
}

data class SalatiUiState(
    val currentTab: Int = 0,
    val cityName: String = "مكة المكرمة",
    val latitude: Double = 21.4225,
    val longitude: Double = 39.8262,
    val isDetectingLocation: Boolean = false,
    val prayerTimes: List<PrayerTimeItem> = emptyList(),
    val nextPrayer: PrayerTimeItem? = null,
    val nextPrayerCountdown: String = "--:--:--",
    val isNowPrayerTime: Boolean = false,

    // Auto-silence
    val autoSilenceEnabled: Boolean = true,
    val silenceDurationMinutes: Int = 20,
    val preAlertMinutes: Int = 10,
    val silenceMode: SilenceRingerMode = SilenceRingerMode.SILENT,
    val hasDndPermission: Boolean = false,
    val isCurrentlyMuted: Boolean = false,

    // Spiritual Relief AI
    val problemInput: String = "",
    val isLoadingRelief: Boolean = false,
    val activeRelief: SpiritualReliefResponse? = null,
    val hourlyDeliveryEnabled: Boolean = false,
    val hourlyIntervalHours: Int = 1,
    val reliefHistory: List<SpiritualReliefResponse> = emptyList(),

    // Gleason Qibla
    val compassHeading: Float = 0f,
    val qiblaResult: GleasonQiblaCalculator.QiblaResult = GleasonQiblaCalculator.calculateQibla(21.4225, 39.8262),
    val isGleasonProjection: Boolean = true,
    val isAlignedWithQibla: Boolean = false,

    // Settings
    val themeLightingMode: ThemeLightingMode = ThemeLightingMode.LIGHT,
    val selectedLanguage: String = "ar",
    val calcMethod: CalculationMethod = CalculationMethod.UMM_AL_QURA,
    val asrJuristic: AsrJuristic = AsrJuristic.STANDARD,
    val minuteAdjustments: Map<PrayerType, Int> = emptyMap(),
    val messageToast: String? = null
)

class SalatiViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val prefs = context.getSharedPreferences("salati_settings", Context.MODE_PRIVATE)
    private val spPrefs = context.getSharedPreferences("salati_spiritual_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(SalatiUiState())
    val uiState: StateFlow<SalatiUiState> = _uiState.asStateFlow()

    private val compassManager = CompassSensorManager(context)
    private var countdownTimer: CountDownTimer? = null

    val cityPresets = listOf(
        CityPreset("مكة المكرمة", "Makkah", "La Mecque", 21.4225, 39.8262),
        CityPreset("المدينة المنورة", "Madinah", "Médine", 24.5247, 39.5692),
        CityPreset("الرياض", "Riyadh", "Riyad", 24.7136, 46.6753),
        CityPreset("القاهرة", "Cairo", "Le Caire", 30.0444, 31.2357),
        CityPreset("القدس الشريف", "Jerusalem", "Jérusalem", 31.7683, 35.2137),
        CityPreset("الدار البيضاء", "Casablanca", "Casablanca", 33.5731, -7.5898),
        CityPreset("دبي", "Dubai", "Dubaï", 25.2048, 55.2708),
        CityPreset("إسطنبول", "Istanbul", "Istanbul", 41.0082, 28.9784),
        CityPreset("الجزائر العاصمة", "Algiers", "Alger", 36.7538, 3.0588),
        CityPreset("تونس", "Tunis", "Tunis", 36.8065, 10.1815),
        CityPreset("باريس", "Paris", "Paris", 48.8566, 2.3522),
        CityPreset("لندن", "London", "Londres", 51.5074, -0.1278),
        CityPreset("نيويورك", "New York", "New York", 40.7128, -74.0060)
    )

    init {
        loadSettings()
        refreshDndStatus()
        recomputePrayerTimes()
        startCountdownTicker()
        loadSpiritualHistory()

        // Listen to compass
        compassManager.start()
        viewModelScope.launch {
            compassManager.headingFlow.collect { heading ->
                val targetQibla = if (_uiState.value.isGleasonProjection) {
                    _uiState.value.qiblaResult.gleasonBearingDeg
                } else {
                    _uiState.value.qiblaResult.geodeticBearingDeg
                }
                var diff = kotlin.math.abs(heading - targetQibla)
                if (diff > 180f) diff = 360f - diff
                val aligned = diff <= 4f

                _uiState.update {
                    it.copy(
                        compassHeading = heading,
                        isAlignedWithQibla = aligned
                    )
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        compassManager.stop()
        countdownTimer?.cancel()
    }

    private fun getLocalizedContext(lang: String = _uiState.value.selectedLanguage): Context {
        val locale = when (lang) {
            "en" -> Locale.ENGLISH
            "fr" -> Locale.FRENCH
            else -> Locale("ar")
        }
        val config = android.content.res.Configuration(context.resources.configuration).apply {
            setLocale(locale)
        }
        return context.createConfigurationContext(config)
    }

    private fun loadSettings() {
        val lat = prefs.getFloat("lat", 21.4225f).toDouble()
        val lon = prefs.getFloat("lon", 39.8262f).toDouble()
        val lang = prefs.getString("app_lang", "ar") ?: "ar"
        val savedCity = prefs.getString("city", "مكة المكرمة") ?: "مكة المكرمة"
        val matchingCity = cityPresets.find {
            it.nameAr == savedCity || it.nameEn == savedCity || it.nameFr == savedCity
        }
        val city = matchingCity?.localizedName(lang) ?: savedCity

        val autoSilence = prefs.getBoolean("auto_silence", true)
        val duration = prefs.getInt("duration", 20)
        val preAlert = prefs.getInt("pre_alert", 10)
        val modeStr = prefs.getString("mode", SilenceRingerMode.SILENT.name) ?: SilenceRingerMode.SILENT.name
        val mode = try { SilenceRingerMode.valueOf(modeStr) } catch (e: Exception) { SilenceRingerMode.SILENT }
        val methodStr = prefs.getString("calc_method", CalculationMethod.UMM_AL_QURA.name) ?: CalculationMethod.UMM_AL_QURA.name
        val method = try { CalculationMethod.valueOf(methodStr) } catch (e: Exception) { CalculationMethod.UMM_AL_QURA }
        val asrStr = prefs.getString("asr_juristic", AsrJuristic.STANDARD.name) ?: AsrJuristic.STANDARD.name
        val asr = try { AsrJuristic.valueOf(asrStr) } catch (e: Exception) { AsrJuristic.STANDARD }
        val themeStr = prefs.getString("theme_mode", ThemeLightingMode.LIGHT.name) ?: ThemeLightingMode.LIGHT.name
        val themeMode = try { ThemeLightingMode.valueOf(themeStr) } catch (e: Exception) { ThemeLightingMode.LIGHT }

        val hourlyEnabled = spPrefs.getBoolean("hourly_enabled", false)
        val hourlyInterval = spPrefs.getInt("interval_hours", 1)
        val activeProblem = spPrefs.getString("active_problem", "") ?: ""

        val qibla = GleasonQiblaCalculator.calculateQibla(lat, lon)

        _uiState.update {
            it.copy(
                latitude = lat,
                longitude = lon,
                cityName = city,
                autoSilenceEnabled = autoSilence,
                silenceDurationMinutes = duration,
                preAlertMinutes = preAlert,
                silenceMode = mode,
                calcMethod = method,
                asrJuristic = asr,
                selectedLanguage = lang,
                themeLightingMode = themeMode,
                hourlyDeliveryEnabled = hourlyEnabled,
                hourlyIntervalHours = hourlyInterval,
                problemInput = activeProblem,
                qiblaResult = qibla
            )
        }
    }

    fun setTab(tab: Int) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun refreshDndStatus() {
        val granted = AutoSilenceManager.hasDndPermission(context)
        val muted = AutoSilenceManager.isCurrentlyMuted(context)
        _uiState.update { it.copy(hasDndPermission = granted, isCurrentlyMuted = muted) }
    }

    fun openDndSettings() {
        AutoSilenceManager.openDndSettings(context)
    }

    fun testMuteNow() {
        refreshDndStatus()
        val success = AutoSilenceManager.mutePhoneForPrayer(context, _uiState.value.silenceMode)
        val locCtx = getLocalizedContext()
        _uiState.update {
            it.copy(
                isCurrentlyMuted = true,
                messageToast = if (success) locCtx.getString(com.example.R.string.toast_muted_success) else locCtx.getString(com.example.R.string.toast_muted_no_permission)
            )
        }
    }

    fun restoreRingerNow() {
        val success = AutoSilenceManager.restorePhoneRinger(context)
        val locCtx = getLocalizedContext()
        _uiState.update {
            it.copy(
                isCurrentlyMuted = false,
                messageToast = if (success) locCtx.getString(com.example.R.string.toast_unmuted_success) else locCtx.getString(com.example.R.string.toast_unmuted_success)
            )
        }
    }

    fun toggleAutoSilence(enabled: Boolean) {
        _uiState.update { it.copy(autoSilenceEnabled = enabled) }
        prefs.edit().putBoolean("auto_silence", enabled).apply()
        scheduleAlarms()
    }

    fun setSilenceDuration(minutes: Int) {
        _uiState.update { it.copy(silenceDurationMinutes = minutes) }
        prefs.edit().putInt("duration", minutes).apply()
        scheduleAlarms()
    }

    fun setPreAlertMinutes(minutes: Int) {
        _uiState.update { it.copy(preAlertMinutes = minutes) }
        prefs.edit().putInt("pre_alert", minutes).apply()
        scheduleAlarms()
    }

    fun setSilenceMode(mode: SilenceRingerMode) {
        _uiState.update { it.copy(silenceMode = mode) }
        prefs.edit().putString("mode", mode.name).apply()
    }

    fun selectCity(city: CityPreset) {
        val qibla = GleasonQiblaCalculator.calculateQibla(city.lat, city.lon)
        _uiState.update {
            it.copy(
                cityName = city.localizedName(it.selectedLanguage),
                latitude = city.lat,
                longitude = city.lon,
                qiblaResult = qibla
            )
        }
        prefs.edit()
            .putString("city", city.nameAr)
            .putFloat("lat", city.lat.toFloat())
            .putFloat("lon", city.lon.toFloat())
            .apply()

        recomputePrayerTimes()
    }

    fun detectGpsLocation() {
        _uiState.update { it.copy(isDetectingLocation = true) }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val locManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val providers = locManager.getProviders(true)
                var bestLocation: android.location.Location? = null

                for (provider in providers) {
                    try {
                        @Suppress("MissingPermission")
                        val l = locManager.getLastKnownLocation(provider)
                        if (l != null && (bestLocation == null || l.accuracy < bestLocation.accuracy)) {
                            bestLocation = l
                        }
                    } catch (se: SecurityException) {
                        Log.w("SalatiVM", "Location permission missing", se)
                    }
                }

                if (bestLocation != null) {
                    val lat = bestLocation.latitude
                    val lon = bestLocation.longitude
                    val qibla = GleasonQiblaCalculator.calculateQibla(lat, lon)
                    val locLabel = String.format(Locale.getDefault(), "%.2f°, %.2f°", lat, lon)
                    val locCtx = getLocalizedContext()

                    _uiState.update {
                        it.copy(
                            latitude = lat,
                            longitude = lon,
                            cityName = locLabel,
                            qiblaResult = qibla,
                            isDetectingLocation = false,
                            messageToast = locCtx.getString(com.example.R.string.toast_gps_success)
                        )
                    }
                    prefs.edit()
                        .putFloat("lat", lat.toFloat())
                        .putFloat("lon", lon.toFloat())
                        .putString("city", locLabel)
                        .apply()

                    launch(Dispatchers.Main) { recomputePrayerTimes() }
                } else {
                    val locCtx = getLocalizedContext()
                    _uiState.update {
                        it.copy(
                            isDetectingLocation = false,
                            messageToast = locCtx.getString(com.example.R.string.toast_gps_failed)
                        )
                    }
                }
            } catch (e: Exception) {
                val locCtx = getLocalizedContext()
                _uiState.update {
                    it.copy(
                        isDetectingLocation = false,
                        messageToast = locCtx.getString(com.example.R.string.toast_gps_failed)
                    )
                }
            }
        }
    }

    fun recomputePrayerTimes() {
        val state = _uiState.value
        val params = PrayerCalculator.PrayerCalculationParams(
            method = state.calcMethod,
            asrJuristic = state.asrJuristic,
            minuteAdjustments = state.minuteAdjustments
        )
        val times = PrayerCalculator.calculatePrayerTimes(
            Calendar.getInstance(),
            state.latitude,
            state.longitude,
            params
        )

        val next = times.firstOrNull { it.isNext } ?: times.firstOrNull()
        _uiState.update {
            it.copy(
                prayerTimes = times,
                nextPrayer = next
            )
        }
        scheduleAlarms()
    }

    private fun scheduleAlarms() {
        val state = _uiState.value
        PrayerAlarmScheduler.schedulePrayerAlarms(
            context,
            state.prayerTimes,
            state.autoSilenceEnabled,
            state.silenceDurationMinutes,
            state.preAlertMinutes,
            state.silenceMode
        )
    }

    private fun startCountdownTicker() {
        countdownTimer?.cancel()
        countdownTimer = object : CountDownTimer(Long.MAX_VALUE, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val now = System.currentTimeMillis()
                val next = _uiState.value.nextPrayer
                if (next != null) {
                    val diff = next.timeMillis - now
                    if (diff > 0) {
                        val hours = (diff / (1000 * 60 * 60)) % 24
                        val mins = (diff / (1000 * 60)) % 60
                        val secs = (diff / 1000) % 60
                        val formatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, mins, secs)
                        _uiState.update { it.copy(nextPrayerCountdown = formatted, isNowPrayerTime = false) }
                    } else if (diff in -(_uiState.value.silenceDurationMinutes * 60 * 1000L)..0) {
                        _uiState.update { it.copy(nextPrayerCountdown = "00:00:00", isNowPrayerTime = true) }
                    } else {
                        // Need recompute for next prayer
                        recomputePrayerTimes()
                    }
                }
            }
            override fun onFinish() {}
        }.start()
    }

    // --- Spiritual AI Relief Section ---
    fun updateProblemInput(text: String) {
        _uiState.update { it.copy(problemInput = text) }
    }

    fun submitProblemForRelief(problemOverride: String? = null) {
        val query = problemOverride ?: _uiState.value.problemInput
        if (query.isBlank()) return

        _uiState.update { it.copy(isLoadingRelief = true, problemInput = query) }
        spPrefs.edit().putString("active_problem", query).apply()

        viewModelScope.launch {
            try {
                val result = SpiritualAiCounselor.consultSpiritualRelief(context, query, _uiState.value.selectedLanguage)
                _uiState.update {
                    it.copy(
                        isLoadingRelief = false,
                        activeRelief = result,
                        reliefHistory = listOf(result) + it.reliefHistory.filter { item -> item.id != result.id }
                    )
                }
            } catch (e: Exception) {
                val fallback = SpiritualAiCounselor.getCuratedAuthenticRelief(query)
                _uiState.update {
                    it.copy(
                        isLoadingRelief = false,
                        activeRelief = fallback,
                        reliefHistory = listOf(fallback) + it.reliefHistory.filter { item -> item.id != fallback.id }
                    )
                }
            }
        }
    }

    fun toggleHourlyDelivery(enabled: Boolean) {
        _uiState.update { it.copy(hourlyDeliveryEnabled = enabled) }
        spPrefs.edit().putBoolean("hourly_enabled", enabled).apply()
        val locCtx = getLocalizedContext()

        if (enabled) {
            PrayerAlarmScheduler.scheduleHourlyWisdom(context, _uiState.value.hourlyIntervalHours)
            _uiState.update { it.copy(messageToast = locCtx.getString(com.example.R.string.toast_hourly_enabled)) }
        } else {
            PrayerAlarmScheduler.cancelHourlyWisdom(context)
            _uiState.update { it.copy(messageToast = locCtx.getString(com.example.R.string.toast_hourly_disabled)) }
        }
    }

    fun setHourlyInterval(hours: Int) {
        _uiState.update { it.copy(hourlyIntervalHours = hours) }
        spPrefs.edit().putInt("interval_hours", hours).apply()
        if (_uiState.value.hourlyDeliveryEnabled) {
            PrayerAlarmScheduler.scheduleHourlyWisdom(context, hours)
        }
    }

    private fun loadSpiritualHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            val history = SpiritualAiCounselor.getHistory(context)
            _uiState.update {
                it.copy(
                    reliefHistory = history,
                    activeRelief = history.firstOrNull() ?: it.activeRelief
                )
            }
        }
    }

    // --- Gleason Qibla ---
    fun toggleProjectionMode() {
        _uiState.update { it.copy(isGleasonProjection = !it.isGleasonProjection) }
    }

    // --- Settings ---
    fun setLanguage(lang: String) {
        val currentCityName = _uiState.value.cityName
        val matchingCity = cityPresets.find {
            it.nameAr == currentCityName || it.nameEn == currentCityName || it.nameFr == currentCityName
        }
        val newCityName = matchingCity?.localizedName(lang) ?: currentCityName

        _uiState.update {
            it.copy(
                selectedLanguage = lang,
                cityName = newCityName
            )
        }
        prefs.edit().putString("app_lang", lang).apply()
        recomputePrayerTimes()
    }

    fun setCalculationMethod(method: CalculationMethod) {
        _uiState.update { it.copy(calcMethod = method) }
        prefs.edit().putString("calc_method", method.name).apply()
        recomputePrayerTimes()
    }

    fun setAsrJuristic(asr: AsrJuristic) {
        _uiState.update { it.copy(asrJuristic = asr) }
        prefs.edit().putString("asr_juristic", asr.name).apply()
        recomputePrayerTimes()
    }

    fun setMinuteAdjustment(type: PrayerType, delta: Int) {
        val map = _uiState.value.minuteAdjustments.toMutableMap()
        map[type] = delta
        _uiState.update { it.copy(minuteAdjustments = map) }
        recomputePrayerTimes()
    }

    fun setThemeLightingMode(mode: ThemeLightingMode) {
        _uiState.update { it.copy(themeLightingMode = mode) }
        prefs.edit().putString("theme_mode", mode.name).apply()
    }

    fun toggleQuickLighting() {
        val next = when (_uiState.value.themeLightingMode) {
            ThemeLightingMode.LIGHT -> ThemeLightingMode.DARK
            ThemeLightingMode.DARK -> ThemeLightingMode.SYSTEM
            ThemeLightingMode.SYSTEM -> ThemeLightingMode.LIGHT
        }
        setThemeLightingMode(next)
    }

    fun clearToast() {
        _uiState.update { it.copy(messageToast = null) }
    }
}
