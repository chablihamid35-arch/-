package com.example.ui.screens

import android.graphics.Paint
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.SalatiUiState
import com.example.ui.SalatiViewModel
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.*

@Composable
fun GleasonQiblaScreen(
    viewModel: SalatiViewModel,
    uiState: SalatiUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val targetBearing = if (uiState.isGleasonProjection) {
        uiState.qiblaResult.gleasonBearingDeg
    } else {
        uiState.qiblaResult.geodeticBearingDeg
    }

    // Alignment status color
    val statusColor by animateColorAsState(
        targetValue = if (uiState.isAlignedWithQibla) AccentGreen else MaterialTheme.colorScheme.primary,
        label = "statusColor"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Header Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Explore,
                        contentDescription = null,
                        tint = IslamicGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.gleason_qibla_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.gleason_qibla_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Live Alignment Banner
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (uiState.isAlignedWithQibla) AccentGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (uiState.isAlignedWithQibla) AccentGreen else Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (uiState.isAlignedWithQibla) Icons.Default.CheckCircle else Icons.Default.CompassCalibration,
                    contentDescription = null,
                    tint = if (uiState.isAlignedWithQibla) AccentGreen else IslamicGold,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (uiState.isAlignedWithQibla) {
                        stringResource(R.string.aligned_with_qibla)
                    } else {
                        stringResource(R.string.turn_phone_hint)
                    },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (uiState.isAlignedWithQibla) AccentGreen else MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Gleason Interactive Compass Canvas
        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
        Box(
            modifier = Modifier
                .size(310.dp)
                .shadow(12.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = if (isDark) {
                            listOf(
                                Color(0xFF134E48),
                                Color(0xFF0C3330),
                                Color(0xFF061E1C)
                            )
                        } else {
                            listOf(
                                Color(0xFFF0FDF9),
                                Color(0xFFDCF6F0),
                                Color(0xFFBCEAE1)
                            )
                        }
                    )
                )
                .border(
                    width = 2.5.dp,
                    brush = Brush.linearGradient(
                        if (uiState.isAlignedWithQibla) {
                            listOf(AccentGreen, Color.White, AccentGreen)
                        } else if (isDark) {
                            listOf(LuminousBorderDark, SoftGold, LuminousBorderDark)
                        } else {
                            listOf(EmeraldPrimary, IslamicGold, EmeraldPrimaryLight)
                        }
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            GleasonCompassCanvas(
                heading = uiState.compassHeading,
                targetBearing = targetBearing,
                userX = uiState.qiblaResult.userGleasonX,
                userY = uiState.qiblaResult.userGleasonY,
                kaabaX = uiState.qiblaResult.kaabaGleasonX,
                kaabaY = uiState.qiblaResult.kaabaGleasonY,
                isAligned = uiState.isAlignedWithQibla,
                isDark = isDark
            )
        }

        // Metrics Grid (Bearing, Heading, Distance)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                label = stringResource(R.string.qibla_angle),
                value = String.format(Locale.getDefault(), "%.1f°", targetBearing),
                icon = Icons.Default.NearMe,
                tint = IslamicGold,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = stringResource(R.string.compass_heading),
                value = String.format(Locale.getDefault(), "%.1f°", uiState.compassHeading),
                icon = Icons.Default.Navigation,
                tint = statusColor,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = stringResource(R.string.distance_to_kaaba),
                value = stringResource(R.string.distance_km_format, uiState.qiblaResult.distanceKm.toInt()),
                icon = Icons.Default.Straighten,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1.2f)
            )
        }

        // Projection Mode Toggle
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.toggle_gleason_mode),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (uiState.isGleasonProjection) {
                            stringResource(R.string.projection_gleason)
                        } else {
                            stringResource(R.string.projection_geodetic)
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = IslamicGold
                    )
                }

                Switch(
                    checked = uiState.isGleasonProjection,
                    onCheckedChange = { viewModel.toggleProjectionMode() }
                )
            }
        }

        // Calibration Note
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.calibrate_compass),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun GleasonCompassCanvas(
    heading: Float,
    targetBearing: Float,
    userX: Float,
    userY: Float,
    kaabaX: Float,
    kaabaY: Float,
    isAligned: Boolean,
    isDark: Boolean
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension / 2f - 18.dp.toPx()

        val ringColor = if (isDark) Color(0xFF2DD4BF) else EmeraldPrimary
        val equatorColor = if (isDark) SoftGold else IslamicGold
        val meridianColor = if (isDark) Color(0xFF2DD4BF) else EmeraldPrimary

        // Rotate the entire Gleason map plate with phone compass heading
        rotate(-heading, pivot = center) {
            // Draw Gleason Azimuthal Equidistant Polar Concentric Latitude Circles
            drawCircle(
                color = ringColor.copy(alpha = 0.5f),
                radius = radius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
            // Tropic of Capricorn
            drawCircle(
                color = ringColor.copy(alpha = 0.35f),
                radius = radius * 0.75f,
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )
            // Equator (Golden ring)
            drawCircle(
                color = equatorColor.copy(alpha = 0.75f),
                radius = radius * 0.55f,
                center = center,
                style = Stroke(width = 1.8.dp.toPx())
            )
            // Tropic of Cancer
            drawCircle(
                color = ringColor.copy(alpha = 0.35f),
                radius = radius * 0.38f,
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )
            // North Pole (Center point)
            drawCircle(
                color = if (isDark) Color.White.copy(alpha = 0.9f) else EmeraldPrimary,
                radius = 4.dp.toPx(),
                center = center
            )

            // Radial Hour Meridians (24 lines = every 15 degrees)
            for (angle in 0 until 360 step 15) {
                val angleRad = Math.toRadians(angle.toDouble())
                val endX = center.x + radius * sin(angleRad).toFloat()
                val endY = center.y - radius * cos(angleRad).toFloat()
                val isCardinal = angle % 90 == 0
                val color = if (isCardinal) equatorColor.copy(alpha = 0.85f) else meridianColor.copy(alpha = 0.22f)
                val width = if (isCardinal) 2.dp.toPx() else 0.8.dp.toPx()

                drawLine(
                    color = color,
                    start = center,
                    end = Offset(endX, endY),
                    strokeWidth = width
                )
            }

            // User location pin on Gleason map
            val userCanvasX = center.x + userX * radius * 0.95f
            val userCanvasY = center.y + userY * radius * 0.95f
            drawCircle(
                color = Color(0xFF0284C7),
                radius = 6.dp.toPx(),
                center = Offset(userCanvasX, userCanvasY)
            )

            // Holy Kaaba pin on Gleason map (Makkah)
            val kaabaCanvasX = center.x + kaabaX * radius * 0.95f
            val kaabaCanvasY = center.y + kaabaY * radius * 0.95f
            drawCircle(
                color = IslamicGold,
                radius = 7.5.dp.toPx(),
                center = Offset(kaabaCanvasX, kaabaCanvasY)
            )

            // Direct laser trajectory from User to Kaaba on Gleason map
            drawLine(
                color = SoftGold.copy(alpha = 0.9f),
                start = Offset(userCanvasX, userCanvasY),
                end = Offset(kaabaCanvasX, kaabaCanvasY),
                strokeWidth = 2.5.dp.toPx()
            )
        }

        // Static overlay: Compass needle pointing to Qibla
        // The angle between current heading and Qibla bearing
        val relativeQiblaAngle = targetBearing - heading

        rotate(relativeQiblaAngle, pivot = center) {
            val needlePath = Path().apply {
                moveTo(center.x, center.y - radius * 0.92f)
                lineTo(center.x - 12.dp.toPx(), center.y)
                lineTo(center.x, center.y - 10.dp.toPx())
                close()
            }
            val needleColor = if (isAligned) AccentGreen else IslamicGold
            drawPath(needlePath, color = needleColor)

            val needlePathRight = Path().apply {
                moveTo(center.x, center.y - radius * 0.92f)
                lineTo(center.x + 12.dp.toPx(), center.y)
                lineTo(center.x, center.y - 10.dp.toPx())
                close()
            }
            drawPath(needlePathRight, color = if (isAligned) Color(0xFF34D399) else Color(0xFFF59E0B))

            // Tail of the needle
            val tailPath = Path().apply {
                moveTo(center.x, center.y + radius * 0.55f)
                lineTo(center.x - 8.dp.toPx(), center.y)
                lineTo(center.x, center.y + 8.dp.toPx())
                close()
            }
            val tailColor = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF0F172A).copy(alpha = 0.35f)
            drawPath(tailPath, color = tailColor)

            val tailPathRight = Path().apply {
                moveTo(center.x, center.y + radius * 0.55f)
                lineTo(center.x + 8.dp.toPx(), center.y)
                lineTo(center.x, center.y + 8.dp.toPx())
                close()
            }
            drawPath(tailPathRight, color = tailColor.copy(alpha = tailColor.alpha * 0.6f))
        }

        // Center hub
        val hubColor = if (isAligned) AccentGreen else (if (isDark) SoftGold else IslamicGold)
        drawCircle(
            color = hubColor,
            radius = 9.dp.toPx(),
            center = center
        )
        drawCircle(
            color = Color.White,
            radius = 3.dp.toPx(),
            center = center
        )
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
        }
    }
}
