package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Enhanced Luminous Emerald Islamic Palette
val EmeraldPrimary = Color(0xFF0D7E73)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryLight = Color(0xFF14B8A6)
val EmeraldPrimaryContainer = Color(0xFFD1FAE5)
val EmeraldOnPrimaryContainer = Color(0xFF064E3B)

val IslamicGold = Color(0xFFD97706)
val IslamicGoldContainer = Color(0xFFFEF3C7)
val IslamicOnGoldContainer = Color(0xFF78350F)
val GoldGlow = Color(0xFFFDE68A)

val IslamicDarkBg = Color(0xFF071B1A)
val IslamicDarkSurface = Color(0xFF0E2E2C)
val IslamicDarkCard = Color(0xFF15403D)

val LightBackground = Color(0xFFF6FAF9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6F3F1)

val DarkBackground = Color(0xFF071B1A)
val DarkSurface = Color(0xFF0E2E2C)
val DarkSurfaceVariant = Color(0xFF15403D)

val AccentGreen = Color(0xFF34D399)
val SoftGold = Color(0xFFFCD34D)
val WarningRed = Color(0xFFEF4444)
val LuminousCyan = Color(0xFF22D3EE)
val LuminousBorderLight = Color(0xFF0D9488)
val LuminousBorderDark = Color(0xFF2DD4BF)

