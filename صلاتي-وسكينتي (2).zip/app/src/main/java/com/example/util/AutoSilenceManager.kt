package com.example.util

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.example.model.SilenceRingerMode

object AutoSilenceManager {

    private const val TAG = "AutoSilenceManager"
    private const val PREFS_NAME = "salati_silence_prefs"
    private const val KEY_SAVED_RINGER_MODE = "saved_ringer_mode"
    private const val KEY_IS_CURRENTLY_MUTED = "is_currently_muted"

    fun hasDndPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.isNotificationPolicyAccessGranted
        } else {
            true
        }
    }

    fun openDndSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to open DND settings", e)
            }
        }
    }

    fun mutePhoneForPrayer(context: Context, mode: SilenceRingerMode): Boolean {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        try {
            // Save current ringer mode if not already muted
            val isCurrentlyMuted = prefs.getBoolean(KEY_IS_CURRENTLY_MUTED, false)
            if (!isCurrentlyMuted) {
                val currentRinger = audioManager.ringerMode
                prefs.edit()
                    .putInt(KEY_SAVED_RINGER_MODE, currentRinger)
                    .putBoolean(KEY_IS_CURRENTLY_MUTED, true)
                    .apply()
            }

            // If DND permission granted, adjust filter
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && hasDndPermission(context)) {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (mode == SilenceRingerMode.SILENT) {
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
                } else {
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                }
            }

            // Set audio manager mode
            val targetMode = if (mode == SilenceRingerMode.SILENT) {
                AudioManager.RINGER_MODE_SILENT
            } else {
                AudioManager.RINGER_MODE_VIBRATE
            }

            audioManager.ringerMode = targetMode
            Log.d(TAG, "Phone silenced for prayer with mode: $mode")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error muting phone: ${e.message}", e)
            return false
        }
    }

    fun restorePhoneRinger(context: Context): Boolean {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        try {
            val savedRinger = prefs.getInt(KEY_SAVED_RINGER_MODE, AudioManager.RINGER_MODE_NORMAL)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && hasDndPermission(context)) {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }

            audioManager.ringerMode = savedRinger
            prefs.edit()
                .putBoolean(KEY_IS_CURRENTLY_MUTED, false)
                .apply()

            Log.d(TAG, "Phone ringer restored to mode: $savedRinger")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error restoring phone ringer: ${e.message}", e)
            return false
        }
    }

    fun isCurrentlyMuted(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_IS_CURRENTLY_MUTED, false)
    }
}
