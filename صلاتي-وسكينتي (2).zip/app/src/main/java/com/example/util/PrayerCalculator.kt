package com.example.util

import com.example.model.AsrJuristic
import com.example.model.CalculationMethod
import com.example.model.PrayerTimeItem
import com.example.model.PrayerType
import java.util.Calendar
import java.util.Locale
import kotlin.math.*

object PrayerCalculator {

    data class PrayerCalculationParams(
        val method: CalculationMethod = CalculationMethod.UMM_AL_QURA,
        val asrJuristic: AsrJuristic = AsrJuristic.STANDARD,
        val minuteAdjustments: Map<PrayerType, Int> = emptyMap()
    )

    fun calculatePrayerTimes(
        calendar: Calendar,
        latitude: Double,
        longitude: Double,
        params: PrayerCalculationParams = PrayerCalculationParams()
    ): List<PrayerTimeItem> {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val timezoneOffsetHours = calendar.timeZone.getOffset(calendar.timeInMillis) / 3600000.0

        // Julian Date
        val julianDate = calculateJulianDate(year, month, day)
        val d = julianDate - 2451545.0

        // Mean solar noon & sun position
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(Math.toRadians(g)) + 0.020 * sin(Math.toRadians(2 * g)))
        val e = 23.439 - 0.00000036 * d

        // Sun declination & equation of time
        val sinDeclination = sin(Math.toRadians(e)) * sin(Math.toRadians(l))
        val declination = Math.toDegrees(asin(sinDeclination))
        val cosDeclination = cos(Math.toRadians(declination))

        val ra = fixAngle(Math.toDegrees(atan2(cos(Math.toRadians(e)) * sin(Math.toRadians(l)), cos(Math.toRadians(l))))) / 15.0
        val equationOfTime = (q / 15.0) - ra

        // Midday / Dhuhr
        val dhuhrHours = 12.0 + timezoneOffsetHours - (longitude / 15.0) - equationOfTime

        // Method angles
        val fajrAngle = when (params.method) {
            CalculationMethod.UMM_AL_QURA -> 18.5
            CalculationMethod.MUSLIM_WORLD_LEAGUE -> 18.0
            CalculationMethod.EGYPTIAN -> 19.5
            CalculationMethod.KARACHI -> 18.0
            CalculationMethod.NORTH_AMERICA -> 15.0
        }

        val ishaAngle = when (params.method) {
            CalculationMethod.UMM_AL_QURA -> 0.0 // 90 min after Maghrib
            CalculationMethod.MUSLIM_WORLD_LEAGUE -> 17.0
            CalculationMethod.EGYPTIAN -> 17.5
            CalculationMethod.KARACHI -> 18.0
            CalculationMethod.NORTH_AMERICA -> 15.0
        }

        // Sunrise & Sunset (horizon with atmospheric refraction 0.833 deg)
        val sunRiseHourAngle = calculateHourAngle(latitude, declination, 90.833)
        val sunriseHours = dhuhrHours - (sunRiseHourAngle / 15.0)
        val maghribHours = dhuhrHours + (sunRiseHourAngle / 15.0)

        // Fajr
        val fajrHourAngle = calculateHourAngle(latitude, declination, 90.0 + fajrAngle)
        val fajrHours = dhuhrHours - (fajrHourAngle / 15.0)

        // Asr
        val shadowFactor = if (params.asrJuristic == AsrJuristic.HANAFI) 2.0 else 1.0
        val asrAltitude = Math.toDegrees(atan(1.0 / (shadowFactor + tan(Math.toRadians(abs(latitude - declination))))))
        val asrHourAngle = calculateHourAngle(latitude, declination, 90.0 - asrAltitude)
        val asrHours = dhuhrHours + (asrHourAngle / 15.0)

        // Isha
        val ishaHours = if (params.method == CalculationMethod.UMM_AL_QURA) {
            maghribHours + 1.5 // 90 mins
        } else {
            val ishaHourAngle = calculateHourAngle(latitude, declination, 90.0 + ishaAngle)
            dhuhrHours + (ishaHourAngle / 15.0)
        }

        val prayerTimesMap = mapOf(
            PrayerType.FAJR to fajrHours,
            PrayerType.SUNRISE to sunriseHours,
            PrayerType.DHUHR to dhuhrHours,
            PrayerType.ASR to asrHours,
            PrayerType.MAGHRIB to maghribHours,
            PrayerType.ISHA to ishaHours
        )

        val nowMillis = System.currentTimeMillis()
        val result = mutableListOf<PrayerTimeItem>()

        val baseCalendar = (calendar.clone() as Calendar).apply {
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        for (type in PrayerType.values()) {
            val rawHour = prayerTimesMap[type] ?: 12.0
            val adjustmentMinutes = params.minuteAdjustments[type] ?: 0

            val totalMinutes = (rawHour * 60.0).roundToInt() + adjustmentMinutes
            val prayerHour = (totalMinutes / 60) % 24
            val prayerMinute = totalMinutes % 60

            val prayerCal = (baseCalendar.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, prayerHour)
                set(Calendar.MINUTE, prayerMinute)
            }

            val timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", prayerHour, prayerMinute)
            result.add(
                PrayerTimeItem(
                    type = type,
                    timeFormatted = timeFormatted,
                    timeMillis = prayerCal.timeInMillis
                )
            )
        }

        // Determine current and next prayer
        val sortedPrayers = result.filter { it.type != PrayerType.SUNRISE }
        var nextPrayerIndex = -1

        for (i in result.indices) {
            val item = result[i]
            if (item.timeMillis > nowMillis) {
                nextPrayerIndex = i
                break
            }
        }

        // If all prayers today have passed, Fajr of next day is next
        val isNextFound = nextPrayerIndex != -1

        return result.mapIndexed { index, item ->
            val isNext = if (isNextFound) index == nextPrayerIndex else (index == 0)
            val isCurrent = if (isNextFound && nextPrayerIndex > 0) {
                index == nextPrayerIndex - 1
            } else if (!isNextFound) {
                index == result.size - 1
            } else false

            item.copy(isNext = isNext, isCurrent = isCurrent)
        }
    }

    private fun calculateHourAngle(latitude: Double, declination: Double, zenith: Double): Double {
        val latRad = Math.toRadians(latitude)
        val decRad = Math.toRadians(declination)
        val zenRad = Math.toRadians(zenith)

        val cosH = (cos(zenRad) - sin(latRad) * sin(decRad)) / (cos(latRad) * cos(decRad))
        val clampedCosH = cosH.coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(clampedCosH))
    }

    private fun fixAngle(angle: Double): Double {
        var a = angle - 360.0 * floor(angle / 360.0)
        if (a < 0) a += 360.0
        return a
    }

    private fun calculateJulianDate(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }
}
