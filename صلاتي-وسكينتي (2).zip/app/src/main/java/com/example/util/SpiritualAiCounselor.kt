package com.example.util

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.model.SpiritualReliefResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object SpiritualAiCounselor {

    private const val TAG = "SpiritualAiCounselor"
    private const val PREFS_NAME = "salati_spiritual_prefs"
    private const val KEY_HISTORY = "spiritual_history"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun consultSpiritualRelief(context: Context, problem: String, lang: String = "ar"): SpiritualReliefResponse = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY" && apiKey != "placeholder") {
            try {
                val apiResult = callGeminiApi(apiKey, problem, lang)
                if (apiResult != null) {
                    saveToHistory(context, apiResult)
                    return@withContext apiResult
                }
            } catch (e: Exception) {
                Log.w(TAG, "Gemini API failed, falling back to curated authentic database", e)
            }
        }

        // Fallback to our extensive curated authentic Sunni database
        val fallbackResult = getCuratedAuthenticRelief(problem)
        saveToHistory(context, fallbackResult)
        fallbackResult
    }

    private fun callGeminiApi(apiKey: String, problem: String, lang: String = "ar"): SpiritualReliefResponse? {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val langInstruction = when (lang) {
            "en" -> "Important: The user has selected English. All output values (comfortMessage, quranAyah with English translation, hadith with English translation, salafQuote in English, dua with translation) must be provided in English."
            "fr" -> "Important: L'utilisateur a sélectionné le français. Toutes les valeurs du résultat (comfortMessage, quranAyah avec traduction française, hadith avec traduction française, salafQuote en français, dua avec traduction) doivent être fournies en français."
            else -> "ملاحظة هامة: لغة الرد المطلوبة هي اللغة العربية الفصحى البليغة."
        }

        val prompt = """
            أنت مرشد إيماني رباني موثوق، تستند حصراً إلى القرآن الكريم والسنة النبوية الصحيحة وفق فهم سلف الأمة وأهل السنة والجماعة.
            طرح المستخدم مسألته أو كربته التي لا تعجز الله:
            "$problem"

            $langInstruction

            المطلوب: توليد رد إيماني بليغ يبعث اليقين والرجاء في الله تعالى ولا يتضمن إلا الأحاديث الصحيحة الثابتة (صحيح البخاري، صحيح مسلم أو ما صححه المحدثون المعتمدون كالألباني وأحمد).
            يجب أن يكون الإخراج نص JSON فقط بالبنية التالية دون أي كود ماركداون:
            {
              "comfortMessage": "رسالة طمأنينة ويقين تخاطب القلب وتبين أن الله على كل شيء قدير وأن الفرج قريب",
              "quranAyah": "نص الآية القرآنية الكريمة الدالة على الفرج والقدرة الإلهية",
              "quranReference": "اسم السورة ورقم الآية",
              "hadith": "متن الحديث النبوي الشريف الصحيح",
              "hadithSource": "تخريج الحديث (مثال: رواه البخاري برقم ... أو رواه مسلم برقم ...)",
              "salafQuote": "قول مأثور لصحابي أو تابعي أو إمام من أهل السنة والجماعة (كالحسن البصري، ابن القيم، ابن تيمية، الشافعي، أحمد بن حنبل)",
              "salafAuthor": "اسم القائل وصفته",
              "dua": "دعاء مأثور مستجاب يناسب هذه الكربة"
            }
        """.trimIndent()

        val jsonRequest = JSONObject().apply {
            val contentsArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            }
            put("contents", contentsArray)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.3)
                put("responseMimeType", "application/json")
            })
        }

        val requestBody = jsonRequest.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(endpoint)
            .post(requestBody)
            .build()

        val response = okHttpClient.newCall(request).execute()
        if (!response.isSuccessful) {
            Log.e(TAG, "Gemini API HTTP error: ${response.code} - ${response.message}")
            return null
        }

        val responseString = response.body?.string() ?: return null
        val responseJson = JSONObject(responseString)
        val candidates = responseJson.optJSONArray("candidates")
        val content = candidates?.optJSONObject(0)?.optJSONObject("content")
        val parts = content?.optJSONArray("parts")
        val text = parts?.optJSONObject(0)?.optString("text") ?: return null

        val parsed = JSONObject(text)
        return SpiritualReliefResponse(
            problem = problem,
            comfortMessage = parsed.optString("comfortMessage"),
            quranAyah = parsed.optString("quranAyah"),
            quranReference = parsed.optString("quranReference"),
            hadith = parsed.optString("hadith"),
            hadithSource = parsed.optString("hadithSource"),
            salafQuote = parsed.optString("salafQuote"),
            salafAuthor = parsed.optString("salafAuthor"),
            dua = parsed.optString("dua")
        )
    }

    /**
     * Curated authentic database of verses, Sahih hadiths, and quotes of Ahlus-Sunnah
     */
    fun getCuratedAuthenticRelief(problem: String): SpiritualReliefResponse {
        val p = problem.lowercase()

        return when {
            p.contains("دين") || p.contains("مال") || p.contains("رزق") || p.contains("فقر") || p.contains("وظيفة") || p.contains("عمل") || p.contains("debt") || p.contains("money") -> {
                SpiritualReliefResponse(
                    problem = problem,
                    comfortMessage = "اعلم علم اليقين أن خزائن السماوات والأرض بيد الله وحده، وأن الرزق مكتوب لا يفوته أحد، وما من دابة في الأرض إلا على الله رزقها. فتوكل على الحي الذي لا يموت واطرق بابه بالاستغفار والدعاء المخلص، فإن الفرج أقرب مما تظن.",
                    quranAyah = "﴿وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا • وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ إِنَّ اللَّهَ بَالِغُ أَمْرِهِ قَدْ جَعَلَ اللَّهُ لِكُلِّ شَيْءٍ قَدْرًا﴾",
                    quranReference = "سورة الطلاق: الآيات 2-3",
                    hadith = "عن علي رضي الله عنه أن مكاتباً جاءه فقال: إني عجزت عن كتابتي فأعني، قال: ألا أعلمك كلمات علمنيهن رسول الله ﷺ لو كان عليك مثل جبل صير ديناً أداه الله عنك؟ قل: «اللَّهُمَّ اكْفِنِي بِحَلالِكَ عَنْ حَرَامِكَ، وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ».",
                    hadithSource = "رواه الترمذي وحسنه، وصححه الحاكم والألباني في صحيح الجامع (2625)",
                    salafQuote = "«لو توكلتم على الله حق توكله لرزقكم كما يرزق الطير تغدو خماصاً وتروح بطاناً.. من وثق بالله كفاه، ومن توكل عليه هداه، ومن انقطع إليه تولاه».",
                    salafAuthor = "الإمام ابن القيم الجوزية رحمه الله",
                    dua = "«اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ، وَغَلَبَةِ الرِّجَالِ»."
                )
            }
            p.contains("مرض") || p.contains("شفاء") || p.contains("وجع") || p.contains("ألم") || p.contains("صحة") || p.contains("sick") || p.contains("cure") || p.contains("heal") -> {
                SpiritualReliefResponse(
                    problem = problem,
                    comfortMessage = "إن الله تبارك وتعالى لم ينزل داءً إلا أنزل له شفاء، علمه من علمه وجهله من جهله. والمرض كفارة للذنوب ورفعة في الدرجات، والشفاء بيد الشافي المعافي سبحانه، نادى أيوب ربه فكشف ما به من ضر، فتيقن برحمته.",
                    quranAyah = "﴿وَإِذَا مَرِضْتُ فَهُوَ يَشْفِينِ • وَالَّذِي يُمِيتُنِي ثُمَّ يُحْيِينِ﴾",
                    quranReference = "سورة الشعراء: الآيات 80-81",
                    hadith = "عن عائشة رضي الله عنها أن النبي ﷺ كان يعوِّذ بعض أهله يمسح بيده اليمنى ويقول: «اللَّهُمَّ رَبَّ النَّاسِ، أَذْهِبِ الْبَأْسَ، اشْفِ أَنْتَ الشَّافِي، لا شِفَاءَ إِلا شِفَاؤُكَ، شِفَاءً لا يُغَادِرُ سَقَمًا».",
                    hadithSource = "صحيح البخاري (5743) وصحيح مسلم (2191)",
                    salafQuote = "«ما أصاب العبد من نصب ولا وصب ولا هم ولا حزن حتى الشوكة يشاكها إلا كفر الله بها من خطاياه.. وإذا أحب الله قوماً ابتلاهم، فمن رضي فله الرضا».",
                    salafAuthor = "الحسن البصري رحمه الله",
                    dua = "«أَسْأَلُ اللَّهَ الْعَظِيمَ رَبَّ الْعَرْشِ الْعَظِيمِ أَنْ يَشْفِيَكَ» (سبع مرات)."
                )
            }
            p.contains("قلق") || p.contains("حزن") || p.contains("هم") || p.contains("خوف") || p.contains("ضيق") || p.contains("anxiety") || p.contains("sad") -> {
                SpiritualReliefResponse(
                    problem = problem,
                    comfortMessage = "لا تحزن ولا يضق صدرك، فإن الذي خلقك يتولاك، وهو أرحم بك من أمك وأبيك. إن بعد العسر يسراً، وإن مع الشدة رخاءً، وما أغلق الله باباً بحكمته إلا فتح لك بابين برحمته.",
                    quranAyah = "﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾ • ﴿فَإِنَّ مَعَ الْعُسْرِ يُسْرًا • إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾",
                    quranReference = "سورة الرعد: 28 وسورة الشرح: 5-6",
                    hadith = "عن عبد الله بن مسعود رضي الله عنه قال: قال رسول الله ﷺ: «مَا أَصَابَ أَحَدًا قَطُّ هَمٌّ وَلا حَزَنٌ فَقَالَ: اللَّهُمَّ إِنِّي عَبْدُكَ ابْنُ عَبْدِكَ ابْنُ أَمَتِكَ، نَاصِيَتِي بِيَدِكَ، مَاضٍ فِيَّ حُكْمُكَ، عَدْلٌ فِيَّ قَضَاؤُكَ، أَسْأَلُكَ بِكُلِّ اسْمٍ هُوَ لَكَ سَمَّيْتَ بِهِ نَفْسَكَ أَوْ عَلَّمْتَهُ أَحَدًا مِنْ خَلْقِكَ أَوْ أَنْزَلْتَهُ فِي كِتَابِكَ أَوِ اسْتَأْثَرْتَ بِهِ فِي عِلْمِ الْغَيْبِ عِنْدَكَ، أَنْ تَجْعَلَ الْقُرْآنَ رَبِيعَ قَلْبِي، وَنُورَ صَدْرِي، وَجِلاءَ حُزْنِي، وَذَهَابَ هَمِّي، إِلا أَذْهَبَ اللَّهُ هَمَّهُ وَحُزْنَهُ وَأَبْدَلَهُ مَكَانَهُ فَرَجًا».",
                    hadithSource = "رواه أحمد (3712) وابن حبان، وصححه الألباني في السلسلة الصحيحة (199)",
                    salafQuote = "«ما نزل بلاء إلا بذنب، ولا رفع إلا بتوبة.. واعلم أن النصر مع الصبر، وأن الفرج مع الكرب، وأن مع العسر يسراً».",
                    salafAuthor = "أمير المؤمنين علي بن أبي طالب رضي الله عنه",
                    dua = "«لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ» • «يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ»."
                )
            }
            p.contains("أهل") || p.contains("زوج") || p.contains("ولد") || p.contains("أسرة") || p.contains("طلاق") || p.contains("family") -> {
                SpiritualReliefResponse(
                    problem = problem,
                    comfortMessage = "إن القلوب بين إصبعين من أصابع الرحمن يقلبها كيف يشاء، وما استُجلبت المودة والرحمة بمثل الدعاء والإحسان والصبر. سل الله أن يؤلف بين القلوب وأن يصلح ذات بينكم، فإنه سبحانه هو القائل: ﴿عَسَى اللَّهُ أَن يَجْعَلَ بَيْنَكُمْ وَبَيْنَ الَّذِينَ عَادَيْتُم مِّنْهُم مَّوَدَّةً﴾.",
                    quranAyah = "﴿وَالَّذِينَ يَقُولُونَ رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا﴾",
                    quranReference = "سورة الفرقان: الآية 74",
                    hadith = "عن عبد الله بن عمرو بن العاص رضي الله عنهما أنه سمع رسول الله ﷺ يقول: «إِنَّ قُلُوبَ بَنِي آدَمَ كُلَّهَا بَيْنَ إِصْبَعَيْنِ مِنْ أَصَابِعِ الرَّحْمَنِ كَقَلْبٍ وَاحِدٍ يُصَرِّفُهُ حَيْثُ يَشَاءُ، ثُمَّ قَالَ: اللَّهُمَّ مُصَرِّفَ الْقُلُوبِ صَرِّفْ قُلُوبَنَا عَلَى طَاعَتِكَ».",
                    hadithSource = "صحيح مسلم (2654)",
                    salafQuote = "«إني لأعصي الله فأعرف ذلك في خُلُق دابتي وزوجتي.. فأرجع إلى ربي مستغفراً تائباً فيصلح الله لي أمري كله».",
                    salafAuthor = "الفضيل بن عياض رحمه الله",
                    dua = "«رَبَّنَا أَصْلِحْ لَنَا فِي ذُرِّيَّاتِنَا وَأَهْلِينَا، وَأَلِّفْ بَيْنَ قُلُوبِنَا، وَاهْدِنَا سُبُلَ السَّلَامِ»."
                )
            }
            p.contains("امتحان") || p.contains("دراسة") || p.contains("نجاح") || p.contains("مستقبل") || p.contains("exam") || p.contains("test") -> {
                SpiritualReliefResponse(
                    problem = problem,
                    comfortMessage = "خذ بالأسباب واعقلها وتوكل، ولا تعجز؛ فإن المؤمن القوي خير وأحب إلى الله من المؤمن الضعيف وفي كلٍ خير. احرص على ما ينفعك واستعن بالله، فإنه لا سهل إلا ما جعله الله سهلاً.",
                    quranAyah = "﴿رَبِّ اشْرَحْ لِي صَدْرِي • وَيَسِّرْ لِي أَمْرِي • وَاحْلُلْ عُقْدَةً مِّن لِّسَانِي • يَفْقَهُوا قَوْلِي﴾",
                    quranReference = "سورة طه: الآيات 25-28",
                    hadith = "عن أنس بن مالك رضي الله عنه أن رسول الله ﷺ كان يقول: «اللَّهُمَّ لا سَهْلَ إِلا مَا جَعَلْتَهُ سَهْلاً، وَأَنْتَ تَجْعَلُ الْحَزْنَ إِذَا شِئْتَ سَهْلاً».",
                    hadithSource = "رواه ابن حبان في صحيحه (974) وصححه الألباني في السلسلة الصحيحة (2886)",
                    salafQuote = "«العلم يرفع بيتاً لا عماد له.. ومن استعان بالله في طلب العلم والخير أعانه الله وسدده وفتح عليه فتوح العارفين».",
                    salafAuthor = "الإمام الشافعي رحمه الله",
                    dua = "«اللَّهُمَّ عَلِّمْنِي مَا يَنْفَعُنِي، وَانْفَعْنِي بِمَا عَلَّمْتَنِي، وَزِدْنِي عِلْمًا وَتَوْفِيقًا يَا رَبَّ العَالَمِينَ»."
                )
            }
            else -> {
                SpiritualReliefResponse(
                    problem = problem,
                    comfortMessage = "اعلم يا عبد الله أنك تأوي إلى ركن شديد، وأن الذي بيده ملكوت كل شيء يسمع نجواك ويعلم سرك ونجواك. لا تتعاظم على الله مسألة، فإنه إذا أراد شيئاً فإنما يقول له كن فيكون. ثق بربك وتضرع إليه بيقين المستيقن بإجابته.",
                    quranAyah = "﴿أَمَّن يُجِيبُ الْمُضْطَرَّ إِذَا دَعَاهُ وَيَكْشِفُ السُّوءَ وَيَجْعَلُكُمْ خُلَفَاءَ الْأَرْضِ أَإِلَٰهٌ مَّعَ اللَّهِ قَلِيلًا مَّا تَذَكَّرُونَ﴾",
                    quranReference = "سورة النمل: الآية 62",
                    hadith = "عن ابن عباس رضي الله عنهما قال: كنت خلف النبي ﷺ يوماً فقال: «يَا غُلامُ إِنِّي أُعَلِّمُكَ كَلِمَاتٍ: احْفَظِ اللَّهَ يَحْفَظْكَ، احْفَظِ اللَّهَ تَجِدْهُ تُجَاهَكَ، إِذَا سَأَلْتَ فَاسْأَلِ اللَّهَ، وَإِذَا اسْتَعَنْتَ فَاسْتَعِنْ بِاللَّهِ، وَاعْلَمْ أَنَّ الأُمَّةَ لَوْ اجْتَمَعَتْ عَلَى أَنْ يَنْفَعُوكَ بِشَيْءٍ لَمْ يَنْفَعُوكَ إِلاَّ بِشَيْءٍ قَدْ كَتَبَهُ اللَّهُ لَكَ، وَلَوْ اجْتَمَعُوا عَلَى أَنْ يَضُرُّوكَ بِشَيْءٍ لَمْ يَضُرُّوكَ إِلاَّ بِشَيْءٍ قَدْ كَتَبَهُ اللَّهُ عَلَيْكَ، رُفِعَتِ الأَقْلامُ وَجَفَّتِ الصُّحُفُ».",
                    hadithSource = "رواه الترمذي (2516) وقال: حديث حسن صحيح",
                    salafQuote = "«إذا فتح الله لك باب فهم الدعاء فاعلم أنه يريد أن يعطيك.. واليقين ألا ترجو أحداً إلا الله، وألا تخاف إلا ذنبك».",
                    salafAuthor = "أمير المؤمنين عمر بن الخطاب رضي الله عنه",
                    dua = "«يَا فَارِجَ الْهَمِّ، وَيَا كَاشِفَ الْغَمِّ، فَرِّجْ هَمِّي، وَيَسِّرْ أَمْرِي، وَارْحَمْ ضَعْفِي وَقِلَّةَ حِيلَتِي، وَارْزُقْنِي مِنْ حَيْثُ لا أَحْتَسِبُ»."
                )
            }
        }
    }

    private fun saveToHistory(context: Context, response: SpiritualReliefResponse) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val historyJson = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
            val array = JSONArray(historyJson)

            val itemObj = JSONObject().apply {
                put("id", response.id)
                put("problem", response.problem)
                put("comfortMessage", response.comfortMessage)
                put("quranAyah", response.quranAyah)
                put("quranReference", response.quranReference)
                put("hadith", response.hadith)
                put("hadithSource", response.hadithSource)
                put("salafQuote", response.salafQuote)
                put("salafAuthor", response.salafAuthor)
                put("dua", response.dua)
                put("timestamp", response.timestamp)
            }

            // Put latest on top, keep max 20
            val newArray = JSONArray()
            newArray.put(itemObj)
            for (i in 0 until minOf(array.length(), 19)) {
                newArray.put(array.getJSONObject(i))
            }

            prefs.edit().putString(KEY_HISTORY, newArray.toString()).apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save spiritual history", e)
        }
    }

    fun getHistory(context: Context): List<SpiritualReliefResponse> {
        val result = mutableListOf<SpiritualReliefResponse>()
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val historyJson = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
            val array = JSONArray(historyJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    SpiritualReliefResponse(
                        id = obj.optString("id"),
                        problem = obj.optString("problem"),
                        comfortMessage = obj.optString("comfortMessage"),
                        quranAyah = obj.optString("quranAyah"),
                        quranReference = obj.optString("quranReference"),
                        hadith = obj.optString("hadith"),
                        hadithSource = obj.optString("hadithSource"),
                        salafQuote = obj.optString("salafQuote"),
                        salafAuthor = obj.optString("salafAuthor"),
                        dua = obj.optString("dua"),
                        timestamp = obj.optLong("timestamp")
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load spiritual history", e)
        }
        return result
    }
}
