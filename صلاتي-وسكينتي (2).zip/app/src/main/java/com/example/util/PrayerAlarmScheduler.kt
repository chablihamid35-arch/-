package com.example.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.model.PrayerTimeItem
import com.example.model.PrayerType
import com.example.model.SilenceRingerMode
import com.example.receiver.PrayerAlarmReceiver
import java.util.Calendar

object PrayerAlarmScheduler {

    private const val TAG = "PrayerAlarmScheduler"

    fun schedulePrayerAlarms(
        context: Context,
        prayerTimes: List<PrayerTimeItem>,
        autoSilenceEnabled: Boolean,
        silenceDurationMinutes: Int,
        preAlertMinutes: Int,
        silenceMode: SilenceRingerMode
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()

        for (item in prayerTimes) {
            if (item.type == PrayerType.SUNRISE) continue // Sunrise is not a congregation prayer to silence

            val prayerTime = item.timeMillis

            // 1. Pre-alert alarm
            if (preAlertMinutes > 0) {
                val preAlertTime = prayerTime - (preAlertMinutes * 60 * 1000L)
                if (preAlertTime > now) {
                    val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                        action = PrayerAlarmReceiver.ACTION_PRE_PRAYER_ALERT
                        putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_NAME, item.type.name)
                    }
                    val pi = PendingIntent.getBroadcast(
                        context,
                        item.type.ordinal * 10 + 1,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    setExactAlarm(alarmManager, preAlertTime, pi)
                }
            }

            // 2. Mute alarm at prayer time
            if (autoSilenceEnabled && prayerTime > now) {
                val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    action = PrayerAlarmReceiver.ACTION_PRAYER_MUTE
                    putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_NAME, item.type.name)
                    putExtra(PrayerAlarmReceiver.EXTRA_SILENCE_DURATION, silenceDurationMinutes)
                    putExtra(PrayerAlarmReceiver.EXTRA_SILENCE_MODE, silenceMode.name)
                }
                val pi = PendingIntent.getBroadcast(
                    context,
                    item.type.ordinal * 10 + 2,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                setExactAlarm(alarmManager, prayerTime, pi)
            }
        }
        Log.d(TAG, "Scheduled prayer alarms. AutoSilence: $autoSilenceEnabled, PreAlert: $preAlertMinutes min")
    }

    fun scheduleUnmute(context: Context, durationMinutes: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val unmuteTime = System.currentTimeMillis() + (durationMinutes * 60 * 1000L)

        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = PrayerAlarmReceiver.ACTION_PRAYER_UNMUTE
        }
        val pi = PendingIntent.getBroadcast(
            context,
            9999,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setExactAlarm(alarmManager, unmuteTime, pi)
        Log.d(TAG, "Scheduled unmute in $durationMinutes minutes")
    }

    fun scheduleHourlyWisdom(context: Context, intervalHours: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerTime = System.currentTimeMillis() + (intervalHours * 3600 * 1000L)

        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = PrayerAlarmReceiver.ACTION_HOURLY_WISDOM
        }
        val pi = PendingIntent.getBroadcast(
            context,
            8888,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setExactAlarm(alarmManager, triggerTime, pi)
        Log.d(TAG, "Scheduled next hourly wisdom alarm in $intervalHours hours")
    }

    fun cancelHourlyWisdom(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = PrayerAlarmReceiver.ACTION_HOURLY_WISDOM
        }
        val pi = PendingIntent.getBroadcast(
            context,
            8888,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            alarmManager.cancel(pi)
            pi.cancel()
        }
    }

    fun rescheduleAll(context: Context) {
        val prefs = context.getSharedPreferences("salati_settings", Context.MODE_PRIVATE)
        val lat = prefs.getFloat("lat", 24.7136f).toDouble()
        val lon = prefs.getFloat("lon", 46.6753f).toDouble()
        val autoSilence = prefs.getBoolean("auto_silence", true)
        val duration = prefs.getInt("duration", 20)
        val preAlert = prefs.getInt("pre_alert", 10)
        val mode = SilenceRingerMode.valueOf(prefs.getString("mode", SilenceRingerMode.SILENT.name) ?: SilenceRingerMode.SILENT.name)

        val todayTimes = PrayerCalculator.calculatePrayerTimes(Calendar.getInstance(), lat, lon)
        schedulePrayerAlarms(context, todayTimes, autoSilence, duration, preAlert, mode)

        val spPrefs = context.getSharedPreferences("salati_spiritual_prefs", Context.MODE_PRIVATE)
        if (spPrefs.getBoolean("hourly_enabled", false)) {
            val hours = spPrefs.getInt("interval_hours", 1)
            scheduleHourlyWisdom(context, hours)
        }
    }

    private fun setExactAlarm(alarmManager: AlarmManager, timeMillis: Long, pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pi)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeMillis, pi)
            }
        } catch (e: SecurityException) {
            // In Android 12+, exact alarm permission might be restricted, fallback gracefully
            alarmManager.set(AlarmManager.RTC_WAKEUP, timeMillis, pi)
        }
    }
}
