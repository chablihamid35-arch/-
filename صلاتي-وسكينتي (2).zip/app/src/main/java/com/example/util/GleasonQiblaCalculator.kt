package com.example.util

import kotlin.math.*

object GleasonQiblaCalculator {

    const val KAABA_LATITUDE = 21.422487
    const val KAABA_LONGITUDE = 39.826206

    data class QiblaResult(
        val gleasonBearingDeg: Float,
        val geodeticBearingDeg: Float,
        val distanceKm: Double,
        val userGleasonX: Float, // Normalized -1..1
        val userGleasonY: Float, // Normalized -1..1
        val kaabaGleasonX: Float, // Normalized -1..1
        val kaabaGleasonY: Float  // Normalized -1..1
    )

    /**
     * Calculates Qibla direction on the Gleason Azimuthal Equidistant flat projection,
     * as well as standard geodetic spherical great circle bearing and distance.
     */
    fun calculateQibla(userLat: Double, userLon: Double): QiblaResult {
        // 1. Gleason projection coordinate mapping
        // On Gleason map: North Pole is center (0,0).
        // Max latitude span from North Pole (90) down to Ice Rim (-65 or -75) -> range ~160 degrees
        val maxDeg = 165.0
        val userRadius = ((90.0 - userLat).coerceIn(0.0, maxDeg) / maxDeg)
        val userLonRad = Math.toRadians(userLon)
        val userX = (userRadius * sin(userLonRad)).toFloat()
        val userY = (-userRadius * cos(userLonRad)).toFloat()

        val kaabaRadius = ((90.0 - KAABA_LATITUDE).coerceIn(0.0, maxDeg) / maxDeg)
        val kaabaLonRad = Math.toRadians(KAABA_LONGITUDE)
        val kaabaX = (kaabaRadius * sin(kaabaLonRad)).toFloat()
        val kaabaY = (-kaabaRadius * cos(kaabaLonRad)).toFloat()

        // Gleason planar flat vector bearing (relative to true North at user location)
        val dx = kaabaX - userX
        val dy = kaabaY - userY

        // Angle on flat Cartesian Gleason map:
        // True North at user location points directly towards center (0,0), so vector to North is (-userX, -userY)
        val toNorthAngle = atan2(-userX.toDouble(), -userY.toDouble())
        val toKaabaAngle = atan2(dx.toDouble(), -dy.toDouble())
        var gleasonBearing = Math.toDegrees(toKaabaAngle - toNorthAngle)
        if (gleasonBearing < 0) gleasonBearing += 360.0
        if (gleasonBearing >= 360.0) gleasonBearing -= 360.0

        // 2. Standard Geodetic Great Circle bearing
        val userLatRad = Math.toRadians(userLat)
        val kaabaLatRad = Math.toRadians(KAABA_LATITUDE)
        val dLonRad = Math.toRadians(KAABA_LONGITUDE - userLon)

        val y = sin(dLonRad) * cos(kaabaLatRad)
        val x = cos(userLatRad) * sin(kaabaLatRad) - sin(userLatRad) * cos(kaabaLatRad) * cos(dLonRad)
        var geodeticBearing = Math.toDegrees(atan2(y, x))
        if (geodeticBearing < 0) geodeticBearing += 360.0
        if (geodeticBearing >= 360.0) geodeticBearing -= 360.0

        // 3. Great circle distance (Haversine)
        val earthRadiusKm = 6371.0
        val dLat = Math.toRadians(KAABA_LATITUDE - userLat)
        val a = sin(dLat / 2).pow(2) + cos(userLatRad) * cos(kaabaLatRad) * sin(dLonRad / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        val distanceKm = earthRadiusKm * c

        return QiblaResult(
            gleasonBearingDeg = gleasonBearing.toFloat(),
            geodeticBearingDeg = geodeticBearing.toFloat(),
            distanceKm = distanceKm,
            userGleasonX = userX,
            userGleasonY = userY,
            kaabaGleasonX = kaabaX,
            kaabaGleasonY = kaabaY
        )
    }
}
