package com.example.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.SalatiApp
import com.example.model.PrayerType
import com.example.model.SilenceRingerMode
import com.example.util.AutoSilenceManager
import com.example.util.PrayerAlarmScheduler
import com.example.util.SpiritualAiCounselor

class PrayerAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_PRAYER_MUTE = "com.aistudio.salatisakina.ACTION_PRAYER_MUTE"
        const val ACTION_PRAYER_UNMUTE = "com.aistudio.salatisakina.ACTION_PRAYER_UNMUTE"
        const val ACTION_PRE_PRAYER_ALERT = "com.aistudio.salatisakina.ACTION_PRE_PRAYER_ALERT"
        const val ACTION_HOURLY_WISDOM = "com.aistudio.salatisakina.ACTION_HOURLY_WISDOM"

        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_SILENCE_DURATION = "extra_silence_duration"
        const val EXTRA_SILENCE_MODE = "extra_silence_mode"

        const val NOTIFICATION_ID_PRAYER = 1001
        const val NOTIFICATION_ID_WISDOM = 2002
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.d("PrayerAlarmReceiver", "Received broadcast action: $action")

        val prefs = context.getSharedPreferences("salati_settings", Context.MODE_PRIVATE)
        val lang = prefs.getString("app_lang", "ar") ?: "ar"
        val locale = when (lang) {
            "en" -> java.util.Locale.ENGLISH
            "fr" -> java.util.Locale.FRENCH
            else -> java.util.Locale("ar")
        }
        val config = android.content.res.Configuration(context.resources.configuration).apply {
            setLocale(locale)
        }
        val localizedContext = context.createConfigurationContext(config)

        fun resolvePrayerName(raw: String?): String {
            if (raw == null) return ""
            val type = try { PrayerType.valueOf(raw) } catch (e: Exception) { null }
            return type?.localizedName(lang) ?: raw
        }

        when (action) {
            ACTION_PRAYER_MUTE -> {
                val rawPrayerName = intent.getStringExtra(EXTRA_PRAYER_NAME)
                val prayerName = resolvePrayerName(rawPrayerName)
                val durationMinutes = intent.getIntExtra(EXTRA_SILENCE_DURATION, 20)
                val modeStr = intent.getStringExtra(EXTRA_SILENCE_MODE) ?: SilenceRingerMode.SILENT.name
                val mode = try {
                    SilenceRingerMode.valueOf(modeStr)
                } catch (e: Exception) {
                    SilenceRingerMode.SILENT
                }

                // Mute phone
                AutoSilenceManager.mutePhoneForPrayer(context, mode)

                // Post notification
                showNotification(
                    context,
                    SalatiApp.CHANNEL_PRAYER_ALERTS,
                    NOTIFICATION_ID_PRAYER,
                    localizedContext.getString(com.example.R.string.notif_prayer_time_title, prayerName),
                    localizedContext.getString(com.example.R.string.notif_prayer_muted_body, durationMinutes)
                )

                // Schedule unmute
                PrayerAlarmScheduler.scheduleUnmute(context, durationMinutes)
            }

            ACTION_PRAYER_UNMUTE -> {
                AutoSilenceManager.restorePhoneRinger(context)
                showNotification(
                    context,
                    SalatiApp.CHANNEL_PRAYER_ALERTS,
                    NOTIFICATION_ID_PRAYER,
                    localizedContext.getString(com.example.R.string.notif_prayer_accepted_title),
                    localizedContext.getString(com.example.R.string.notif_prayer_unmuted_body)
                )
            }

            ACTION_PRE_PRAYER_ALERT -> {
                val rawPrayerName = intent.getStringExtra(EXTRA_PRAYER_NAME)
                val prayerName = resolvePrayerName(rawPrayerName)
                showNotification(
                    context,
                    SalatiApp.CHANNEL_PRAYER_ALERTS,
                    NOTIFICATION_ID_PRAYER + 1,
                    localizedContext.getString(com.example.R.string.notif_pre_prayer_title, prayerName),
                    localizedContext.getString(com.example.R.string.notif_pre_prayer_body, prayerName)
                )
            }

            ACTION_HOURLY_WISDOM -> {
                val spPrefs = context.getSharedPreferences("salati_spiritual_prefs", Context.MODE_PRIVATE)
                val problem = spPrefs.getString("active_problem", "") ?: ""
                val relief = SpiritualAiCounselor.getCuratedAuthenticRelief(
                    if (problem.isNotBlank()) problem else "تفويض الأمر إلى الله"
                )

                showNotification(
                    context,
                    SalatiApp.CHANNEL_HOURLY_WISDOM,
                    NOTIFICATION_ID_WISDOM,
                    localizedContext.getString(com.example.R.string.notif_wisdom_title, relief.quranReference),
                    relief.quranAyah + "\n" + relief.hadith
                )

                // Schedule next hourly cycle
                val intervalHours = spPrefs.getInt("interval_hours", 1)
                PrayerAlarmScheduler.scheduleHourlyWisdom(context, intervalHours)
            }

            Intent.ACTION_BOOT_COMPLETED -> {
                PrayerAlarmScheduler.rescheduleAll(context)
            }
        }
    }

    private fun showNotification(
        context: Context,
        channelId: String,
        notificationId: Int,
        title: String,
        message: String
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(notificationId, notification)
    }
}
