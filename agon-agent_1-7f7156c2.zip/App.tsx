import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';

import { AppProvider, useApp } from './src/context/AppContext';
import { HomeScreen } from './src/screens/HomeScreen';
import { SpiritualSupportScreen } from './src/screens/SpiritualSupportScreen';
import { HourlyStreamScreen } from './src/screens/HourlyStreamScreen';
import { AthkarAudioScreen } from './src/screens/AthkarAudioScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';

const Tab = createBottomTabNavigator();

function MainTabNavigator() {
  const { t } = useApp();
  const insets = useSafeAreaInsets();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: [
          styles.tabBar,
          {
            height: 64 + (insets.bottom > 0 ? insets.bottom : 10),
            paddingBottom: insets.bottom > 0 ? insets.bottom : 8,
          },
        ],
        tabBarActiveTintColor: '#10B981',
        tabBarInactiveTintColor: '#64748B',
        tabBarLabelStyle: styles.tabBarLabel,
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap = 'home';

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Support') {
            iconName = focused ? 'heart' : 'heart-outline';
          } else if (route.name === 'HourlyStream') {
            iconName = focused ? 'time' : 'time-outline';
          } else if (route.name === 'Athkar') {
            iconName = focused ? 'disc' : 'disc-outline';
          } else if (route.name === 'Settings') {
            iconName = focused ? 'settings' : 'settings-outline';
          }

          return <Ionicons name={iconName} size={size || 22} color={color} />;
        },
      })}
    >
      <Tab.Screen 
        name="Home" 
        component={HomeScreen} 
        options={{ tabBarLabel: t.tabHome }} 
      />
      <Tab.Screen 
        name="Support" 
        component={SpiritualSupportScreen} 
        options={{ tabBarLabel: t.tabSupport }} 
      />
      <Tab.Screen 
        name="HourlyStream" 
        component={HourlyStreamScreen} 
        options={{ tabBarLabel: t.tabHourlyStream }} 
      />
      <Tab.Screen 
        name="Athkar" 
        component={AthkarAudioScreen} 
        options={{ tabBarLabel: t.tabAthkar }} 
      />
      <Tab.Screen 
        name="Settings" 
        component={SettingsScreen} 
        options={{ tabBarLabel: t.tabSettings }} 
      />
    </Tab.Navigator>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({
    ...Ionicons.font,
  });

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingContainer}>
        <StatusBar style="light" />
      </View>
    );
  }

  return (
    <SafeAreaProvider style={styles.safeArea}>
      <AppProvider>
        <NavigationContainer>
          <StatusBar style="light" backgroundColor="#0F172A" />
          <MainTabNavigator />
        </NavigationContainer>
      </AppProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#0F172A',
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabBar: {
    backgroundColor: '#0F172A',
    borderTopWidth: 1,
    borderTopColor: '#1E293B',
    paddingTop: 6,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  tabBarLabel: {
    fontSize: 10,
    fontWeight: '700',
  },
});