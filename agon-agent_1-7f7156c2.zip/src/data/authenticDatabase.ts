import { AuthenticWisdom } from '../types';

export const AUTHENTIC_DATABASE: AuthenticWisdom[] = [
  // 1. Anxiety & Stress (القلق والتوتر)
  {
    id: 'anxiety_1',
    category: 'anxiety_stress',
    type: 'quran',
    arabicText: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',
    translation: {
      ar: 'ألا بذكر الله تطمئن القلوب وتسكن النفوس من كل فزع ورهبة.',
      en: 'Unquestionably, by the remembrance of Allah do hearts find rest.',
      fr: 'N\'est-ce pas par l\'évocation d\'Allah que les cœurs se tranquillisent ?',
      ur: 'خبردار! اللہ کے ذکر سے ہی دلوں کو اطمینان و سکون ملتا ہے۔',
      tr: 'Bilesiniz ki, kalpler ancak Allah\'ı anmakla huzur bulur.',
      id: 'Ingatlah, hanya dengan mengingat Allah hati menjadi tenteram.'
    },
    source: 'سورة الرعد - الآية 28',
    narratorOrAuthor: 'القرآن الكريم',
    psychologicalContext: {
      ar: 'عندما ينتابك القلق الحاد، يعود سبب التوتر إلى شعور العقل بعدم الأمان والتفكير المتسارع. ذكر الله يرسخ اليقين بأن زمام الأمور كلها بيد الحكيم الخبير.',
      en: 'When acute anxiety strikes, your nervous system is over-triggered by uncertainty. Dhikr refocuses your cognitive attention on the Ultimate Sustainer.',
      fr: 'Lorsque l\'anxiété frappe, votre esprit cherche un ancrage solide. L\'évocation d\'Allah réaligne vos pensées sur la Paix divine.',
      ur: 'جب شدید تشویش ہو تو ذہن انتشار کا شکار ہوتا ہے۔ اللہ کا ذکر آپ کے قلبی سکون کو بحال کرتا ہے۔',
      tr: 'Kaygı anında zihin kontrolü kaybeder. Allah\'ı anmak kalbe sarsılmaz bir güven ve düzen verir.',
      id: 'Saat kecemasan melanda, zikir mengembalikan fokus dan ketenangan jiwa kepada Allah.'
    },
    diagnosticQuestion: {
      ar: 'ما الذي يجعلك تظن أن أمور غدك أثقل من قدرة الله على لطفه بك اليوم؟',
      en: 'What specific element of tomorrow feels bigger than Allah\'s care for you today?',
      fr: 'Qu\'est-ce qui vous fait penser que demain sera trop lourd pour la grâce d\'Allah ?',
      ur: 'آپ کو کیوں لگتا ہے کہ کل کا بوجھ اللہ کی رحمت سے بڑا ہے؟',
      tr: 'Yarınki hangi yük size Allah\'ın lütfundan daha büyük geliyor?',
      id: 'Hal apa yang membuat Anda merasa esok hari lebih berat dari rahmat Allah?'
    }
  },
  {
    id: 'anxiety_2',
    category: 'anxiety_stress',
    type: 'hadith_sahih',
    arabicText: 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ، وَغَلَبَةِ الرِّجَالِ',
    translation: {
      ar: 'كان النبي ﷺ يكثر من هذا الدعاء الجامع لدفع الهموم والضغوط النفسية والديون.',
      en: 'O Allah, I seek refuge in You from anxiety and grief, helplessness and laziness, cowardice and stinginess, the burden of debt and the overpowering of men.',
      fr: 'Ô Allah, je cherche refuge auprès de Toi contre l\'anxiété, la tristesse, l\'incapacité et la paresse.',
      ur: 'اے اللہ! میں پریشانی، غم، عاجزی، سستی، بزدلی، بخل، قرض کے بوجھ اور لوگوں کے تسلط سے تیری پناہ مانگتا ہوں۔',
      tr: 'Allah\'ım! Kaygıdan, kederden, acizlikten, tembellikten, borç yükünden ve insanların baskısından sana sığınırım.',
      id: 'Ya Allah, aku berlindung kepada-Mu dari keluh kesah, duka cita, kelemahan, kemalasan, beban hutang, dan tekanan orang.'
    },
    source: 'صحيح البخاري - 6363',
    narratorOrAuthor: 'رسول الله ﷺ (عن أنس بن مالك رضي الله عنه)',
    psychologicalContext: {
      ar: 'هذا الدعاء يفصل بين (الهم) وهو القلق من المستقبل، و(الحزن) وهو الأسى على الماضي. الاعتراف بهما واستعاذة الله منهما أول خطوات الاستشفاء النفسي.',
      en: 'This prayer distinguishes anxiety (fear of future) from grief (regret of past). Acknowledging both allows mental release and restoration.',
      fr: 'Ce Dua distingue l\'anxiété (futur) du chagrin (passé). Les exprimer est la première étape du soulagement.',
      ur: 'یہ دعا مستقبل کی تشویش اور ماضی کے غم کا علاج ہے۔ ان کا اعتراف سکون لاتا ہے۔',
      tr: 'Bu dua gelecek kaygısı ile geçmiş kederini ayırır ve zihni özgürleştirir.',
      id: 'Doa ini memisahkan kecemasan masa depan dan kesedihan masa lalu untuk kebebasan jiwa.'
    },
    diagnosticQuestion: {
      ar: 'هل المشاعر التي تثقل كاهلك حالياً مرتبطة بخوف من القادم أم بحزن على ما فات؟',
      en: 'Is your current emotional heavy weight rooted in fear of what is to come, or regret of what has passed?',
      fr: 'Votre lourdeur actuelle provient-elle de la peur du futur ou du regret du passé ?',
      ur: 'کیا آپ کا موجودہ بوجھ مستقبل کے خوف کا ہے یا ماضی کے پچھتاوے کا؟',
      tr: 'Sizi yoran şey geleceğin korkusu mu yoksa geçmişin pişmanlığı mı?',
      id: 'Apakah beban berat Anda saat ini berakar pada ketakutan masa depan atau penyesalan masa lalu?'
    }
  },
  {
    id: 'anxiety_3',
    category: 'anxiety_stress',
    type: 'imam_sunnah',
    arabicText: 'إنَّ فِي الدُّنْيَا جَنَّةً مَنْ لَمْ يَدْخُلْهَا لَمْ يَدْخُلْ جَنَّةَ الْآخِرَةِ: جَنَّةُ مَعْرِفَةِ اللَّهِ وَمَحَبَّتِهِ وَالسَّكِينَةِ بِهِ',
    translation: {
      ar: 'طمأنينة القلب بالله وقربك منه هي جنة تعجل لك في الدنيا قبل الآخرة.',
      en: 'There is a Paradise in this world; whoever does not enter it will not enter the Paradise of the Hereafter: the paradise of knowing Allah, loving Him, and finding peace in Him.',
      fr: 'Il y a un Paradis dans ce monde : la connaissance d\'Allah, Son amour et la sérénité en Lui.',
      ur: 'دنیا میں ایک جنت ہے، جو اس میں داخل نہ ہوا وہ آخرت کی جنت میں داخل نہیں ہوگا: وہ اللہ کی معرفت اور سکون کی جنت ہے۔',
      tr: 'Dünyada bir cennet vardır; ona girmeyen ahiret cennetine giremez: Allah\'ı tanıma ve O\'nunla huzur bulma cenneti.',
      id: 'Ada surga di dunia: mengenal Allah, mencintai-Nya, dan menemukan kedamaian dalam-Nya.'
    },
    source: 'الوابل الصيب - ص 67',
    narratorOrAuthor: 'الإمام ابن قيم الجوزية رحمه الله',
    psychologicalContext: {
      ar: 'السكينة ليست غياب المشاكل حولك، بل هي قوة داخلية تجعلك ثابتاً وسط العواصف، متكئاً على عظمة ربك.',
      en: 'Peace is not the total absence of life storms; it is internal stability anchored in Divine reliance.',
      fr: 'La paix n\'est pas l\'absence de problèmes, mais la sérénité intérieure ancrée dans la confiance en Allah.',
      ur: 'سکون حالات کے ٹھیک ہونے کا نام نہیں، بلکہ اللہ کی ذات پر بھروسے سے ملنے والے اندرونی اطمینان کا نام ہے۔',
      tr: 'Huzur sorunların bitmesi değil, kalbin Allah ile güvende olmasıdır.',
      id: 'Ketenangan bukanlah hilangnya masalah, melainkan kedamaian hati bersama Allah.'
    },
    diagnosticQuestion: {
      ar: 'ما الشيء الذي لو سلمت أمره لله اليوم لشعرت بزوال جبل من على صدرك؟',
      en: 'Which single issue, if completely surrendered to Allah today, would lift a mountain off your shoulders?',
      fr: 'Quelle affaire, si vous la confiez totalement à Allah aujourd\'hui, allégerait votre cœur ?',
      ur: 'وہ کونسی ایک بات ہے جسے اگر آپ اللہ کے سپرد کر دیں تو آپ کا بوجھ ہلکا ہو جائے گا؟',
      tr: 'Bugün hangi konuyu tamamen Allah\'a havale etseniz kalbiniz rahatlar?',
      id: 'Hal mana yang jika Anda pasrahkan sepenuhnya kepada Allah hari ini akan mengangkat beban Anda?'
    }
  },

  // 2. Waswas & Overthinking (الوسواس وتشتت الذهن)
  {
    id: 'waswas_1',
    category: 'waswas_overthinking',
    type: 'hadith_sahih',
    arabicText: 'جَاءَ أُنَاسٌ مِنْ أَصْحَابِ النَّبِيِّ ﷺ فَسَأَلُوهُ: إِنَّا نَجِدُ فِي أَنْفُسِنَا مَا يَتَعَاظَمُ أَحَدُنَا أَنْ يَتَكَلَّمَ بِهِ. قَالَ: «وَقَدْ وَجَدْتُمُوهُ؟» قَالُوا: نَعَمْ. قَالَ: «ذَاكَ صَرِيحُ الْإِيمَانِ»',
    translation: {
      ar: 'جاء أصحاب النبي يشتكون من أفكار ووساوس تهجم على عقولهم ويكرهونها، فبشرهم النبي أن كرههم لهذه الوساوس دليل على صدق إيمانهم.',
      en: 'Companions came asking: "We find in ourselves thoughts too awful to speak of." The Prophet asked: "Do you really experience that?" They said: "Yes." He said: "That is clear, authentic faith."',
      fr: 'Des compagnons sont venus dire : "Nous éprouvons des pensées si graves que nous n\'osons les verbaliser." Le Prophète dit : "C\'est la preuve d\'une foi pure."',
      ur: 'صحابه کرام نے عرض کیا: ہمارے دلوں میں ایسے وسوسے آتے ہیں جن کا بولنا بھی بڑا گناہ لگتا ہے۔ آپ ﷺ نے فرمایا: "یہ صریح ایمان کی علامت ہے۔"',
      tr: 'Sahabiler geldiler ve "İçimizden söylemesi bile ağır gelen vesveseler geçiyor" dediler. Peygamberimiz: "Bu apaçık imandır" buyurdu.',
      id: 'Sahabat datang mengadu tentang bisikan hati yang berat. Nabi bersabda: "Itu adalah tanda keimanan yang murni."'
    },
    source: 'صحيح مسلم - 132',
    narratorOrAuthor: 'رسول الله ﷺ (عن أبي هريرة رضي الله عنه)',
    psychologicalContext: {
      ar: 'الأفكار التسلطية والوساوس ليست أنت! نزاعك مع الوسواس وكرهك له يثبت أن عقلك السليم يرفضه. لا تجادل الوسواس، بل أعرض عنه ولا تحاكم نفسك عليه.',
      en: 'Intrusive thoughts are NOT your identity. Fighting or disliking them proves your sound core self rejects them. Do not debate the whisper; disengage.',
      fr: 'Les pensées intrusives ne sont pas ce que vous êtes. Votre rejet de ces pensées prouve la pureté de votre cœur. Ne débattez pas avec elles.',
      ur: 'وسوسے اور برے خیالات آپ کی شخصیت نہیں۔ ان سے آپ کی ناگواری آپ کے سچے ایمان کی دلیل ہے۔',
      tr: 'Aklınıza gelen vesveseler sizin karakteriniz değildir. Onlardan rahatsız olmanız imanınızın delilidir.',
      id: 'Pikiran negatif/waswas bukanlah diri Anda. Keberatan Anda terhadapnya membuktikan kesucian iman Anda.'
    },
    diagnosticQuestion: {
      ar: 'هل تعلم أن الشيطان يهاجم فقط القلوب الممتلئة بالإيمان لأنه لا يطرق بيتاً خرباً؟',
      en: 'Do you realize that Satan only targets hearts with valuable faith, as thieves never target empty houses?',
      fr: 'Réalisez-vous que le diable ne s\'attaque qu\'aux cœurs illuminés par la foi ?',
      ur: 'کیا آپ جانتے ہیں کہ چور صرف بھری ہوئی تجوری پر حملے کرتا ہے، خالی گھر پر نہیں؟',
      tr: 'Şeytanın sadece imanlı kalplere vesvese verdiğini, boş eve hırsız girmediğini biliyor musunuz?',
      id: 'Tahukah Anda bahwa bisikan setan hanya menyerang hati yang beriman karena pencuri tidak mendatangi rumah kosong?'
    }
  },
  {
    id: 'waswas_2',
    category: 'waswas_overthinking',
    type: 'tabi',
    arabicText: 'إِنَّ الشَّيْطَانَ إِذَا رَأَى العَبْدَ يَلْجَأُ إِلَى اللَّهِ وَلاَ يَسْتَجِيبُ لِلْوَسْوَاسِ، انْخَنَسَ وَصَغُرَ حَتَّى يَكُونَ كَالذُّبَابِ',
    translation: {
      ar: 'الوسواس كالكلب العواء، كلما التفت إليه زاد نباحه، وإذا استعذت بالله وتجاهلته انخنس وتضاءل.',
      en: 'When Satan sees a servant taking refuge in Allah and refusing to engage with whispers, he shrinks until he becomes like a tiny fly.',
      fr: 'Quand Satan voit le serviteur se réfugier auprès d\'Allah sans prêter attention aux murmures, il s\'amenuise comme une mouche.',
      ur: 'جب شیطان دیکھتا ہے کہ بندہ اللہ کی پناہ لیتا ہے اور وسوسوں کی پروا نہیں کرتا تو وہ مکھی کی طرح چھوٹا اور بے بس ہو جاتا ہے۔',
      tr: 'Şeytan kulun Allah\'a sığınıp vesveseye aldırış etmediğini görünce sinek gibi küçülür.',
      id: 'Ketika setan melihat hamba berlindung kepada Allah dan mengabaikan bisikan, ia mengecil seperti lalat.'
    },
    source: 'الزهد للإمام أحمد - ص 112',
    narratorOrAuthor: 'الحسن البصري رحمه الله',
    psychologicalContext: {
      ar: 'التقنية النفسية الذهنية المثبتة مع الوسواس هي (التجاهل النشط): قل "آمنت بالله ورسله" واشتغل بما ينفعك مباشرة دون تحليل الفكرة.',
      en: 'The proven psychological technique for intrusive thoughts is active disengagement: Say "I believe in Allah", then focus on a physical action.',
      fr: 'La technique efficace face aux pensées intrusives est l\'ignorance active : Dites "J\'ai foi en Allah" puis occupez-vous.',
      ur: 'وسوسے سے بچنے کا بہترین نفسیاتی طریقہ یہ ہے کہ کہیں: "آمنت بالله" اور فوراً کسی مفيد کام میں مصروف ہو جائیں۔',
      tr: 'Vesveseyi yenmenin yolu onunla tartışmamaktır: "Allah\'a imân ettim" deyin ve işinize bakın.',
      id: 'Teknik psikologis untuk mengabaikan bisikan: katakan "Aku beriman kepada Allah" dan alihkan fokus.'
    },
    diagnosticQuestion: {
      ar: 'ما الفكرة التكرارية التي لو أوقفت مناقشتها واستعذت بالله منها الآن لاسترحت فوراً؟',
      en: 'Which repeating thought, if you stopped analyzing and ignored right now, would bring instant relief?',
      fr: 'Quelle pensée répétitive, si vous arrêtiez de l\'analyser maintenant, vous apaiserait immédiatement ?',
      ur: 'وہ کونسی سوچ ہے جسے اگر آپ ابھی سوچنا بند کر دیں تو فوراً سکون مل جائے گا؟',
      tr: 'Hangi tekrarlayan düşünceyi analiz etmeyi bıraksanız hemen rahatlarsınız?',
      id: 'Pikiran berulang mana yang jika Anda hentikan analisanya sekarang akan memberi relief instan?'
    }
  },

  // 3. Sadness & Grief (الحزن والحسرة)
  {
    id: 'sadness_1',
    category: 'sadness_grief',
    type: 'quran',
    arabicText: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا • إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    translation: {
      ar: 'تأكيد إلهي جازم: مع كل ضيق ومحنة يسران وفرج محيط به من كل جانب.',
      en: 'For indeed, with hardship [will be] ease. Indeed, with hardship [will be] ease.',
      fr: 'A côté de la difficulté est certes une facilité ! A côté de la difficulté est certes une facilité !',
      ur: 'پس یقیناً مشکل کے ساتھ آسانی ہے۔ بے شک مشکل کے ساتھ ہی آسانی ہے۔',
      tr: 'Şüphesiz zorlukla beraber bir kolaylık vardır. Gerçekten zorlukla beraber bir kolaylık vardır.',
      id: 'Maka sesungguhnya bersama kesulitan ada kemudahan. Sesungguhnya bersama kesulitan ada kemudahan.'
    },
    source: 'سورة الشرح - الآية 5-6',
    narratorOrAuthor: 'القرآن الكريم',
    psychologicalContext: {
      ar: 'لاحظ حكمة استخدام حرف "مع" وليس "بعد"! اليسر يتخلق في رحم العسر نفسه. الرحمة والفرج موجودان داخل محنتك الحالية وسوف تجليهما الأيام.',
      en: 'Notice Allah says "WITH hardship", not "after". The relief is embedded inside the trial itself.',
      fr: 'Remarquez le mot "AVEC" la difficulté et non "après". La facilité est enveloppée au cœur de l\'épreuve.',
      ur: 'غور کیجیے کہ "مشکل کے ساتھ" فرمایا، "مشکل کے بعد" نہیں۔ آسانی تکلیف کے اندر ہی موجود ہوتی ہے۔',
      tr: 'Ayet "zorluktan sonra" değil, "zorlukla BERABER" diyor. Kolaylık zorluğun içinde gizlidir.',
      id: 'Perhatikan kata "bersama" kesulitan, bukan "setelah". Kemudahan tersimpan di dalam ujian itu sendiri.'
    },
    diagnosticQuestion: {
      ar: 'ما الألطاف الصغيرة والخفية التي تحيط بك اليوم رغم وجود هذا الحزن؟',
      en: 'What small, subtle mercies surround you today despite the existence of this sorrow?',
      fr: 'Quelles sont les petites grâces discrètes qui vous entourent aujourd\'hui malgré la tristesse ?',
      ur: 'اس غم کے باوجود آج کونسی چھوٹی چھوٹی نعمتیں اور الٰہی مہر و کرم آپ کے ساتھ ہیں؟',
      tr: 'Bu hüzne rağmen bugün etrafınızda olan küçük lütuflar nelerdir?',
      id: 'Kebaikan kecil apa yang tetap menyertai Anda hari ini di tengah rasa sedih?'
    }
  },

  // 4. Debt & Provision (الضيق والرزق والديون)
  {
    id: 'debt_1',
    category: 'debt_poverty',
    type: 'hadith_sahih',
    arabicText: 'مَنْ لَزِمَ الاِسْتِغْفَارَ جَعَلَ اللَّهُ لَهُ مِنْ كُلِّ ضِيقٍ مَخْرَجًا، وَمِنْ كُلِّ هَمٍّ فَرَجًا، وَرَزَقَهُ مِنْ حَيْثُ لاَ يَحْتَسِبُ',
    translation: {
      ar: 'الاستغفار يفتح الأبواب المغلقة، ويزيل ضغوط الرزق والديون، ويرزق العبد من حيث لا يدري.',
      en: 'Whoever adheres to seeking forgiveness, Allah will make for him a way out of every distress, relief from every anxiety, and provide for him from where he never expected.',
      fr: 'Quiconque s\'attache à la demande de pardon, Allah lui ménagera une issue à toute détresse et le pourvoira d\'où il ne s\'attend pas.',
      ur: 'جو شخص استغفار کو لازمی پکڑ لے، اللہ اس کے لیے ہر تنگی سے نکلنے کا راستہ اور ہر غم سے کشادگی پیدا فرماتا ہے۔',
      tr: 'Kim bağışlanma dilemeye devam ederse, Allah ona her darlık bir çıkış yolu ve her kederden bir ferahlık verir.',
      id: 'Barangsiapa melazimkan istighfar, Allah akan memberi jalan keluar dari setiap kesempitan dan rezeki yang tak terduga.'
    },
    source: 'سنن أبي داود - 1518 (حسن)',
    narratorOrAuthor: 'رسول الله ﷺ (عن ابن عباس رضي الله عنهما)',
    psychologicalContext: {
      ar: 'الاستغفار يفرغ شحنة العجز النفسي ويصلح العلاقة مع المسبب سبحانه، مما يفتح الذهن للتفكير الصافي والعمل السليم.',
      en: 'Istighfar cleanses inner anxiety and reconnects the heart to the Source of all provisions.',
      fr: 'L\'Istighfar libère de la pression psychologique et ouvre l\'esprit aux solutions divines.',
      ur: 'استغفار دل کی گھبراہٹ کو دور کرتا ہے اور رزق کے تمام راستے کھول دیتا ہے۔',
      tr: 'İstiğfar zihindeki çaresizlik hissini siler ve kalbi Rızık Veren\'e bağlar.',
      id: 'Istighfar membersihkan rasa cemas dan membuka jalan rezeki dari sumber yang tak terduga.'
    },
    diagnosticQuestion: {
      ar: 'هل رزقك أمس وجاءك اليوم يجعلك تثق بأن رزق غدٍ متكفل به الخالق؟',
      en: 'Does the fact that Allah provided for you yesterday and today give you peace that tomorrow is guaranteed?',
      fr: 'Le fait qu\'Allah vous ait pourvu hier et aujourd\'hui ne vous rassure-t-il pas pour demain ?',
      ur: 'کیا کل اور آج کا رزق ملنے سے آپ کو یقین نہیں آتا کہ کل کا رزق بھی اللہ کے ذمے ہے؟',
      tr: 'Dün ve bugün rızkınızı veren Allah\'ın yarın da vereceğine güveniyor musunuz?',
      id: 'Apakah fakta bahwa Allah memberi rezeki kemarin dan hari ini membuat Anda yakin akan esok hari?'
    }
  },

  // 5. Anger & Conflict (الغضب والانفعال)
  {
    id: 'anger_1',
    category: 'anger_conflict',
    type: 'hadith_sahih',
    arabicText: 'لَيْسَ الشَّدِيدُ بِالصُُّرَعَةِ، إِنَّمَا الشَّدِيدُ الَّذِي يَمْلِكُ نَفْسَهُ عِنْدَ الْغَضَبِ',
    translation: {
      ar: 'القوة الحقيقية ليست في الغلبة الجسدية، بل في ضبط النفس والسيطرة على الانفعال عند الغضب.',
      en: 'The strong is not the one who overcomes people by his strength, but the strong is the one who controls himself while in anger.',
      fr: 'Le fort n\'est pas celui qui terrasse ses adversaires, mais celui qui maîtrise son âme dans la colère.',
      ur: 'پہلوان وہ نہیں جو لوگوں کو پچھاڑ دے، بلکہ طاقتور وہ ہے جو غصے کے وقت اپنے نفس پر قابو رکھے۔',
      tr: 'Pehlivan insanları yenen değildir; gerçek güçlü, öfke anında kendine hakim olandır.',
      id: 'Orang kuat bukanlah yang menang bergulat, melainkan yang mampu menahan dirinya saat marah.'
    },
    source: 'صحيح البخاري - 6114',
    narratorOrAuthor: 'رسول الله ﷺ (عن أبي هريرة رضي الله عنه)',
    psychologicalContext: {
      ar: 'الغضب جمرة من الشيطان تحجب العقل. ضبط النفس لدقيقة واحدة عند الاستفزاز ينجيك من ندم سنوات.',
      en: 'Anger clouds rational judgment. Pausing for 10 seconds during provocation saves years of regret.',
      fr: 'La colère obstrue le jugement. Un arrêt de vài secondes préserve de regrets durables.',
      ur: 'غصہ عقل کو ڈھانپ دیتا ہے۔ غصے کے وقت ایک لمحے کا ضبط سالوں کے پچھتاوے سے بچاتا ہے۔',
      tr: 'Öfke aklı örter. Öfke anındaki bir saniyelik sabır yıllarca sürecek pişmanlığı engeller.',
      id: 'Kemarahan menutupi akal sehat. Menahan diri sejenak menyelamatkan dari penyesalan panjang.'
    },
    diagnosticQuestion: {
      ar: 'هل القرار أو الكلمة التي تريد قولها الآن صادرة من عقل حكيم أم من جمرة غضب ستندم عليها؟',
      en: 'Is the action or word you want to release right now coming from wisdom, or an impulse you will regret?',
      fr: 'La parole que vous voulez dire vient-elle de la sagesse ou d\'un élan de colère ?',
      ur: 'کیا وہ بات جو آپ ابھی کہنا چاہتے ہیں حکمت پر مبنی ہے یا غصے کا ایک ابال جو بعد میں پچھتاوا بنے گا؟',
      tr: 'Şu an söylemek istediğiniz söz hikmetten mi geliyor yoksa öfke patlamasından mı?',
      id: 'Apakah ucapan yang ingin Anda katakan saat ini berasal dari hikmah atau luapan emosi?'
    }
  },

  // 6. Fear of Future (الخوف من المستقبل)
  {
    id: 'fear_1',
    category: 'fear_future',
    type: 'sahaba',
    arabicText: 'لَوْ كُشِفَ الْغِطَاءُ مَا ازْدَدْتُ يَقِينًا.. وَلَوْ عَلِمْتُمْ كَيْفَ يُدَبِّرُ اللَّهُ أُمُورَكُمْ لَذَابَتْ قُلُوبُكُمْ مِنْ مَحَبَّتِهِ',
    translation: {
      ar: 'لو علم العبد كيف يدبر الله أموره باللطف والخفاء لتقطع قلبه حباً لله ولأيقن أن المستقبل بأمان.',
      en: 'If you knew how Allah plans and manages your affairs in secret, your heart would melt out of love for Him.',
      fr: 'Si vous saviez comment Allah régit vos affaires en secret, votre cœur fondrait d\'amour pour Lui.',
      ur: 'اگر آپ کو معلوم ہو جائے کہ اللہ کس طرح آپ کے امور کی تدبیر فرما رہا ہے تو آپ کا دل اس کی محبت سے بھر جائے۔',
      tr: 'Allah\'ın işlerinizi arkada nasıl lütufla yönettiğini bilseydiniz, kalbiniz O\'nun sevgisiyle erirdi.',
      id: 'Jika Anda tahu bagaimana Allah mengatur urusan Anda di balik layar, hati Anda akan meleleh karena cinta pada-Nya.'
    },
    source: 'مدارج السالكين - ج 2 ص 150',
    narratorOrAuthor: 'علي بن أبي طالب رضي الله عنه',
    psychologicalContext: {
      ar: 'الخوف من المستقبل نابع من محاولة العقل التحكم فيما لا يملك. التفويض لله يعيد السكينة والاطمئنان النفسي.',
      en: 'Fear of the future comes from trying to control what is not in your hands. Entrusting Allah brings peace.',
      fr: 'La peur du futur provient de la volonté de tout contrôler. Remettre son sort à Allah apporte le repos.',
      ur: 'مستقبل کا خوف غیر یقینی حالات کو کنٹرول کرنے کی کوشش سے آتا ہے۔ معاملات اللہ کے سپرد کرنا ہی سکون ہے۔',
      tr: 'Gelecek korkusu kontrol edemediğimiz şeyleri yönetme çabasından doğar. Tevekkül huzur getirir.',
      id: 'Ketakutan akan masa depan timbul dari mencoba mengontrol hal di luar kemampuan. Pasrah membawa kedamaian.'
    },
    diagnosticQuestion: {
      ar: 'كم مرة خفت في الماضي من أمر ثم لطف الله بك ومضى الأزمة بسلام؟',
      en: 'How many times in the past were you terrified of a future event, yet Allah carried you through safely?',
      fr: 'Combien de fois avez-vous eu peur dans le passé, et pourtant Allah vous en a sorti avec douceur ?',
      ur: 'ماضی میں کتنی بار آپ کسی بات سے ڈرے اور پھر اللہ نے کرم فرمایا اور وہ مشکل ٹل گئی؟',
      tr: 'Geçmişte kaç kez bir şeyden korktunuz ama Allah sizi salimen o durumdan çıkardı?',
      id: 'Berapا kali di masa lalu Anda takut akan sesuatu, namun Allah menyelamatkan Anda dengan lembut?'
    }
  },

  // 7. Sin & Guilt (الشعور بالتقصير والذنب)
  {
    id: 'sin_1',
    category: 'sin_guilt',
    type: 'quran',
    arabicText: 'قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَى أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ إِنَّ اللَّهَ يَغْفِرُ الذُّنُوبَ جَمِيعًا إِنَّهُ هُوَ الْغَفُورُ الرَّحِيمُ',
    translation: {
      ar: 'نداء الرحمة الإلهي: مهما عظمت ذنوبك أو تكررت، باب التوبة مفتوح ورحمة الله أوسع من كل خطيئة.',
      en: 'Say, "O My servants who have transgressed against themselves, do not despair of the mercy of Allah. Indeed, Allah forgives all sins."',
      fr: 'Dis : "Ô Mes serviteurs qui avez commis des excès à votre propre détriment, ne désespérez pas de la miséricorde d\'Allah."',
      ur: 'فرما دیجیے: اے میرے بندو جنہوں نے اپنی جانوں پر زیادتی کی ہے! اللہ کی رحمت سے مایوس نہ ہو، بے شک اللہ تمام گناہ معاف فرماتا ہے۔',
      tr: 'De ki: "Ey kendi aleyhlerine haddi aşan kullarım! Allah\'ın rahmetinden ümidinizi kesmeyin. Allah bütün günahları bağışlar."',
      id: 'Katakanlah: "Wahai hamba-hamba-Ku yang melampaui batas, janganlah kamu berputus asa dari rahmat Allah."'
    },
    source: 'سورة الزمر - الآية 53',
    narratorOrAuthor: 'القرآن الكريم',
    psychologicalContext: {
      ar: 'الشيطان يريدك أن تيأس لتستمر في الذنب، بينما الله يدعوك للتوبة لتطهر روحك. انكسار قلبك للندم هو بداية طهارتك.',
      en: 'Satan wants you in despair so you keep sinning; Allah calls you to return so your soul heals.',
      fr: 'Satan veut votre désespoir pour vous garder dans le péché ; Allah vous appelle au pardon pour guérir votre âme.',
      ur: 'شیطان آپ کو مایوس کرنا چاہتا ہے تاکہ آپ گناہ میں رہیں، جبکہ اللہ آپ کو معافی کی طرف بلاتا ہے۔',
      tr: 'Şeytan umutsuzluğa düşürüp günaha devam ettirmek ister; Allah ise bağışlayıp kalbi arındırmak ister.',
      id: 'Setan menginginkan Anda putus asa agar terus berbuat dosa; Allah memanggil Anda untuk diampuni.'
    },
    diagnosticQuestion: {
      ar: 'هل تعلم أن أوجع ما يضر الشيطان هو أن تستغفر وتتوب فوراً كلما سقطت؟',
      en: 'Do you know that the biggest defeat to Satan is when you immediately repent whenever you stumble?',
      fr: 'Savez-vous que la plus grande défaite de Satan est votre repentir immédiat après chaque chute ?',
      ur: 'کیا آپ جانتے ہیں کہ شیطان کو سب سے زیادہ تکلیف تب ہوتی ہے جب آپ گرنے کے فوراً بعد توبہ کر لیتے ہیں؟',
      tr: 'Şeytanı en çok kahreden şeyin her düştüğünüzde anında tövbe etmeniz olduğunu biliyor musunuz?',
      id: 'Tahukah Anda bahwa pukulan terberat bagi setan adalah ketika Anda langsung bertaubat setiap kali jatuh?'
    }
  },

  // 8. Loneliness (الوحدة والشعور بالغرب)
  {
    id: 'loneliness_1',
    category: 'loneliness',
    type: 'quran',
    arabicText: 'وَنَحْنُ أَقْرَبُ إِلَيْهِ مِنْ حَبْلِ الْوَرِيدِ',
    translation: {
      ar: 'الله معك في كل لحظة، أقرب إليك من نبضك وأفكارك، ولست وحدك أبداً.',
      en: 'And We are closer to him than his jugular vein.',
      fr: 'Et Nous sommes plus près de lui que sa veine jugulaire.',
      ur: 'اور ہم اس کے شہ رگ سے بھی زیادہ قریب ہیں۔',
      tr: 'Biz ona şah damarından daha yakınız.',
      id: 'Dan Kami lebih dekat kepadanya daripada urat lehernya.'
    },
    source: 'سورة ق - الآية 16',
    narratorOrAuthor: 'القرآن الكريم',
    psychologicalContext: {
      ar: 'الشعور بالوحدة يزول تماماً عندما تدرك أن الله يستمع لمناجاتك الخفية ويعلم ما في قلبك دون حاجة لشرح.',
      en: 'Loneliness dissolves when you realize Allah hears your silent whispers and knows your heart without explanation.',
      fr: 'La solitude s\'évanouit lorsque vous réalisez qu\'Allah entend vos murmures secrets et connaît votre cœur.',
      ur: 'تنہائی کا احساس اس وقت ختم ہو جاتا ہے جب آپ کو اندازہ ہوتا ہے کہ اللہ آپ کے دل کا حال بن کہے جانتا ہے۔',
      tr: 'Yalnızlık hissi, Allah\'ın sessiz dualarınızı duyduğunu ve kalbinizi bildiğini anladığınızda yok olur.',
      id: 'Rasa kesepian sirna saat Anda menyadari Allah mendengar bisikan hati Anda tanpa perlu penjelasan.'
    },
    diagnosticQuestion: {
      ar: 'هل جربت أن تحول وحدتك إلى خلوة مناجاة مع الله وتفرغ ما في صدرك له؟',
      en: 'Have you tried transforming your solitude into a quiet conversation with Allah to pour out your heart?',
      fr: 'Avez-vous essayé de transformer votre solitude en un moment d\'intimité paisible avec Allah ?',
      ur: 'کیا آپ نے کبھی اپنی تنہائی کو اللہ سے راز و نیاز کی مناجات میں بدلنے کی کوشش کی ہے؟',
      tr: 'Yalnızlığınızı Allah ile dertleştiğiniz huzurlu bir münacata dönüştürmeyi denediniz mi?',
      id: 'Pernahkah Anda mengubah kesendirian Anda menjadi momen bermunajat mesra dengan Allah?'
    }
  },

  // 9. Illness & Physical Pain (المرض والابتلاء)
  {
    id: 'illness_1',
    category: 'illness_pain',
    type: 'hadith_sahih',
    arabicText: 'مَا يُصِيبُ الْمُسْلِمَ مِنْ نَصَبٍ وَلاَ وَصَبٍ وَلاَ هَمٍّ وَلاَ حَزَنٍ وَلاَ أَذًى وَلاَ غَمٍّ، حَتَّى الشَّوْكَةِ يُشَاكُهَا، إِلاَّ كَفَّرَ اللَّهُ بِهَا مِنْ خَطَايَاهُ',
    translation: {
      ar: 'كل ألم أو تعب أو هم يشعر به المؤمن، حتى الشوكة الصغيرة، يتكفل الله بجعلها كفارة لذنوبه ورفعة لدرجاته.',
      en: 'No fatigue, illness, anxiety, sorrow, harm, or distress befalls a Muslim - even the prick of a thorn - but Allah expiates some of his sins thereby.',
      fr: 'Aucune fatigue, maladie, anxiété, tristesse ou mal ne touche le musulman sans qu\'Allah ne lui efface ses péchés.',
      ur: 'مسلمان کو جو بھی تھکاوٹ، بیماری، فکر، غم یا تکلیف پہنچتی ہے، یہاں تک کہ ایک کانٹا بھی چبھتا ہے، اللہ اس کے بدلے اس کے گناہ معاف فرما دیتا ہے۔',
      tr: 'Müslümana batan bir diken bile olsa, uğradığı her yorgunluk, hastalık, keder ve eziyet günahlarına kefaret olur.',
      id: 'Tidaklah seorang muslim tertimpa keletihan, penyakit, kesusahan, atau rasa sakit bahkan duri yang menusuknya melainkan Allah hapuskan dosanya.'
    },
    source: 'صحيح البخاري - 5641',
    narratorOrAuthor: 'رسول الله ﷺ (عن أبي سعيد وأبي هريرة رضي الله عنهما)',
    psychologicalContext: {
      ar: 'ألمك ليس عبثاً ولا عقوبة بل هو تطهير ورفع درجات وصبرك عليه يكتب عند الله عبادة عظيمة.',
      en: 'Your pain is not in vain. It cleanses, elevates, and every patient moment is written as worship.',
      fr: 'Votre douleur n\'est pas vaine. Elle purifie, élève et chaque instant de patience est une adoration.',
      ur: 'آپ کی تکلیف ضائع نہیں ہو رہی۔ یہ گناہوں کی پاکیزگی اور درجات کی بلندی کا ذریعہ ہے۔',
      tr: 'Çektiğiniz acı boşa değildir; günahlara kefaret ve deracatı yükselten bir ibadettir.',
      id: 'Rasa sakit Anda tidak sia-sia. Itu menyucikan dosa dan menaikkan derajat di sisi Allah.'
    },
    diagnosticQuestion: {
      ar: 'هل يستشعر قلبك أن هذا الألم العابر يبني لك مقعد صدق وأجراً بغير حساب في الجنة؟',
      en: 'Can your heart sense that this temporary pain is building an immeasurable reward in Paradise?',
      fr: 'Votre cœur ressent-il que cette peine passagère vous prépare une récompense infinie au Paradis ?',
      ur: 'کیا آپ کا دل اس بات کو محسوس کرتا ہے کہ یہ عارضی تکلیف آپ کے لیے جنت میں بے حساب اجر بنا رہی ہے؟',
      tr: 'Kalbiniz bu geçici acının cennette hesapsız bir mükafat hazırladığını hissediyor mu?',
      id: 'Apakah hati Anda merasakan bahwa rasa sakit sementara ini sedang membangun pahala tanpa batas di Surga?'
    }
  }
];
