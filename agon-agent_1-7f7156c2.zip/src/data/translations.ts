import { Language } from '../types';

export interface TranslationDictionary {
  appName: string;
  appSubtitle: string;
  tabHome: string;
  tabSupport: string;
  tabHourlyStream: string;
  tabAthkar: string;
  tabSettings: string;
  
  // Prayer & Mute
  nextPrayer: string;
  muteStatusActive: string;
  muteStatusInactive: string;
  autoMuteMessage: string;
  muteDurationText: string;
  enableAutoMute: string;
  manualMuteToggle: string;
  mosqueModeOn: string;
  mosqueModeOff: string;
  houseOfAllahMessage: string;
  smsAutoReplyTitle: string;
  smsAutoReplyDesc: string;
  qiblaDirection: string;
  cityCountry: string;
  gpsDetectBtn: string;
  gpsDetectSuccess: string;
  
  // Psychological Support
  enterBurdenTitle: string;
  enterBurdenSubtitle: string;
  enterBurdenPlaceholder: string;
  analyzeBurdenBtn: string;
  selectHardshipCategory: string;
  hourlyWisdomTitle: string;
  hourlyWisdomSubtitle: string;
  quickPeaceShot: string;
  identifyProblemTitle: string;
  gentleQuestionTitle: string;
  authenticSourceNotice: string;
  sunniAuthenticityGuarantee: string;
  saveJournalBtn: string;
  
  // Categories
  catAnxiety: string;
  catWaswas: string;
  catSadness: string;
  catDebt: string;
  catAnger: string;
  catFear: string;
  catSin: string;
  catLoneliness: string;
  catIllness: string;
  
  // Common
  share: string;
  bookmark: string;
  bookmarked: string;
  copied: string;
  save: string;
  cancel: string;
  active: string;
  hoursAgo: string;
  minutesAgo: string;
  languageSelect: string;
  sourceLabel: string;
  narratorLabel: string;
}

export const translations: Record<Language, TranslationDictionary> = {
  ar: {
    appName: 'مبعد الشيطان',
    appSubtitle: 'حصنك للسكينة، الصلاة، والدعم النفسي من صحيح السنة والجماعة',
    tabHome: 'الرئيسية',
    tabSupport: 'الدعم النفسي',
    tabHourlyStream: 'سرد السكينة',
    tabAthkar: 'الأذكار والسبحة',
    tabSettings: 'الإعدادات',
    
    nextPrayer: 'الصلاة القادمة',
    muteStatusActive: 'وضع الكتم الصوتي مفعّل تلقائياً (أنا في بيت الله)',
    muteStatusInactive: 'وضع الكتم جاهز للعمل عند رفع الأذان',
    autoMuteMessage: 'أنا في بيت الله - أؤدي الصلاة حالياً وسأتصل بك لاحقاً إن شاء الله',
    muteDurationText: 'مدة الكتم بعد الأذان',
    enableAutoMute: 'تفعيل كتم الهاتف التلقائي في أوقات الصلاة',
    manualMuteToggle: 'كتم الصمت الفوري في المسجد',
    mosqueModeOn: 'الهاتف صامت الآن',
    mosqueModeOff: 'الهاتف بوضع الصوت العادي',
    houseOfAllahMessage: 'رسالة التلقائية: "أنا في بيت الله"',
    smsAutoReplyTitle: 'إرسال الرد التلقائي أثناء الصلاة',
    smsAutoReplyDesc: 'يرسل تلقائياً للمتصلين عند كتم الهاتف في أوقات الصلاة',
    qiblaDirection: 'اتجاه القبلة الشريفة',
    cityCountry: 'المدينة والبلد',
    gpsDetectBtn: 'تحديد موقعي بـ GPS',
    gpsDetectSuccess: 'تم تحديث أوقات الصلاة تلقائياً حسب موقعك الحرفي الجغرافي',
    
    enterBurdenTitle: 'ما الذي يجهدك ويهلكك في هذه الأيام؟',
    enterBurdenSubtitle: 'اكتب ما في قلبك بكل حرية وسنساعدك بتحديد المشكلة وتقديم السكينة والدعم النفسي بأدلة صحيحة',
    enterBurdenPlaceholder: 'مثال: أشعر بضيق شديد وخوف من المستقبل وتشتت الأفكار...',
    analyzeBurdenBtn: 'ابدأ بالدعم النفسي والسكينة',
    selectHardshipCategory: 'أو اختر نوع التحدي الذي تمر به:',
    hourlyWisdomTitle: 'جرعة السكينة وسرد الساعة',
    hourlyWisdomSubtitle: 'آيات وأحاديث وأقوال الصحابة وأئمة أهل السنة والجماعة',
    quickPeaceShot: 'طمأنينة فورية (اضغط هنا)',
    identifyProblemTitle: 'تحديد جذر المشكلة ولطف التشخيص',
    gentleQuestionTitle: 'سؤال للتفكر وتفكيك الضغط:',
    authenticSourceNotice: 'تنبيه إيماني: جميع الأحاديث والأقوال الواردة هنا صحيحة وثابتة عن الرسول ﷺ والصحابة والأئمة',
    sunniAuthenticityGuarantee: 'مضمون المصدر: كتاب الله، صحيح البخاري ومسلم، وأئمة أهل السنة (أبو حنيفة، مالك، الشافعي، أحمد، ابن القيم)',
    saveJournalBtn: 'حفظ في سجل السكينة الشخصي',
    
    catAnxiety: 'القلق والتوتر',
    catWaswas: 'الوسواس وتشتت الذهن',
    catSadness: 'الحزن والحسرة',
    catDebt: 'الضيق والرزق والديون',
    catAnger: 'الغضب والانفعال',
    catFear: 'الخوف من المستقبل',
    catSin: 'الشعور بالتقصير والذنب',
    catLoneliness: 'الوحدة والشعور بالغرب',
    catIllness: 'الم المرض والابتلاء',
    
    share: 'مشاركة',
    bookmark: 'حفظ',
    bookmarked: 'محفوظ',
    copied: 'تم النسخ',
    save: 'حفظ',
    cancel: 'إلغاء',
    active: 'نشط',
    hoursAgo: 'ساعة',
    minutesAgo: 'دقيقة',
    languageSelect: 'لغة التطبيق',
    sourceLabel: 'المصدر',
    narratorLabel: 'القائل / الراوي',
  },
  
  en: {
    appName: "Mu'bid Al-Shaitan",
    appSubtitle: 'Your Shield for Peace, Prayer Muting, and Authentic Psychological Support',
    tabHome: 'Home',
    tabSupport: 'Peace Support',
    tabHourlyStream: 'Hourly Stream',
    tabAthkar: 'Athkar & Tasbeeh',
    tabSettings: 'Settings',
    
    nextPrayer: 'Next Prayer',
    muteStatusActive: 'Auto Mute Active (I am in the House of Allah)',
    muteStatusInactive: 'Auto Mute Ready for Adhan',
    autoMuteMessage: 'I am in the House of Allah - currently praying and will return your call soon InshaAllah',
    muteDurationText: 'Mute Duration after Adhan',
    enableAutoMute: 'Enable Auto Mute during Prayer Times',
    manualMuteToggle: 'Instant Mosque Silent Mode',
    mosqueModeOn: 'Phone is now Silent',
    mosqueModeOff: 'Phone is in Normal Sound Profile',
    houseOfAllahMessage: 'Auto Message: "I am in the House of Allah"',
    smsAutoReplyTitle: 'Send Auto-Reply Message during Prayer',
    smsAutoReplyDesc: 'Automatically replies to incoming callers when phone is muted for prayer',
    qiblaDirection: 'Qibla Direction',
    cityCountry: 'City & Country',
    gpsDetectBtn: 'GPS Location Search',
    gpsDetectSuccess: 'Prayer times auto-updated based on your exact GPS coordinates',
    
    enterBurdenTitle: 'What is exhausting you these days?',
    enterBurdenSubtitle: 'Express what troubles your heart. We will gently guide you with authentic Sunni Quran & Hadith support',
    enterBurdenPlaceholder: 'e.g., I feel overwhelmed with anxiety, fear of the future, and negative thoughts...',
    analyzeBurdenBtn: 'Start Psychological & Spiritual Peace Support',
    selectHardshipCategory: 'Or choose your challenge category:',
    hourlyWisdomTitle: 'Hourly Peace Stream',
    hourlyWisdomSubtitle: 'Authentic Verses, Hadiths, and quotes of Sahaba and renowned Sunni Imams',
    quickPeaceShot: 'Instant Tranquility Relief',
    identifyProblemTitle: 'Identify Root Problem with Gentle Diagnosis',
    gentleQuestionTitle: 'Reflective Question to Deconstruct Stress:',
    authenticSourceNotice: 'Strict Authenticity: Only authentic Bukhari, Muslim, Sahaba and Sunni Imams statements are used',
    sunniAuthenticityGuarantee: 'Verified Sources: Qur’an, Sahih Bukhari & Muslim, Imams Abu Hanifa, Malik, Shafi’i, Ahmad, Ibn Al-Qayyim',
    saveJournalBtn: 'Save to Peace Journal',
    
    catAnxiety: 'Anxiety & Stress',
    catWaswas: 'Waswas & Overthinking',
    catSadness: 'Sadness & Grief',
    catDebt: 'Financial Strain & Debt',
    catAnger: 'Anger & Frustration',
    catFear: 'Fear of Future',
    catSin: 'Guilt & Seeking Forgiveness',
    catLoneliness: 'Loneliness & Alienation',
    catIllness: 'Pain & Physical Suffering',
    
    share: 'Share',
    bookmark: 'Save',
    bookmarked: 'Saved',
    copied: 'Copied',
    save: 'Save',
    cancel: 'Cancel',
    active: 'Active',
    hoursAgo: 'h ago',
    minutesAgo: 'm ago',
    languageSelect: 'App Language',
    sourceLabel: 'Source',
    narratorLabel: 'Narrator / Scholar',
  },
  
  fr: {
    appName: "Mu'bid Al-Shaitan",
    appSubtitle: 'Votre bouclier pour la paix, le silence de prière et le soutien psychologique authentique',
    tabHome: 'Accueil',
    tabSupport: 'Soutien النفسي',
    tabHourlyStream: 'Flux Horaire',
    tabAthkar: 'Athkar & Tasbeeh',
    tabSettings: 'Paramètres',
    
    nextPrayer: 'Prochaine Prière',
    muteStatusActive: 'Mode Silence Actif (Je suis à la Mosquée)',
    muteStatusInactive: 'Silence Automatique Prêt pour l\'Adhan',
    autoMuteMessage: 'Je suis dans la maison d\'Allah - je prie actuellement, je vous rappelle plus tard InchaAllah',
    muteDurationText: 'Durée du silence après l\'Adhan',
    enableAutoMute: 'Activer le silence automatique aux heures de prière',
    manualMuteToggle: 'Mode Silence Instantané Mosquée',
    mosqueModeOn: 'Téléphone en Mode Silencieux',
    mosqueModeOff: 'Téléphone en Mode Normal',
    houseOfAllahMessage: 'Message Auto : "Je suis dans la maison d\'Allah"',
    smsAutoReplyTitle: 'Envoyer une réponse auto pendant la prière',
    smsAutoReplyDesc: 'Répond automatiquement aux appels lorsque le téléphone est silencieux pour la prière',
    qiblaDirection: 'Direction de la Qibla',
    cityCountry: 'Ville & Pays',
    gpsDetectBtn: 'Détection GPS',
    gpsDetectSuccess: 'Heures de prière mises à jour selon votre position GPS exacte',
    
    enterBurdenTitle: 'Qu\'est-ce qui vous pèse en ce moment ?',
    enterBurdenSubtitle: 'Exprimez vos soucis. Nous vous guidons avec douceur à travers le Coran et la Sunna authentique',
    enterBurdenPlaceholder: 'ex: Je ressens de l\'anxiété, la peur de l\'avenir et un esprit agité...',
    analyzeBurdenBtn: 'Obtenir du soutien psychologique et spirituel',
    selectHardshipCategory: 'Ou choisissez la catégorie de votre épreuve :',
    hourlyWisdomTitle: 'Flux de Sérénité Horaire',
    hourlyWisdomSubtitle: 'Versets authentiques, Hadiths et paroles des Sahaba et Grands Imams',
    quickPeaceShot: 'Apaisement Immédiat',
    identifyProblemTitle: 'Identifier la source du problème',
    gentleQuestionTitle: 'Question de réflexion pour apaiser l\'esprit :',
    authenticSourceNotice: 'Authenticité stricte : Uniquement Bukhari, Muslim et grands savants sunnites',
    sunniAuthenticityGuarantee: 'Sources Vérifiées : Coran, Sahih Bukhari & Muslim, Imams Malik, Shafi’i, Ahmad, Ibn Al-Qayyim',
    saveJournalBtn: 'Enregistrer dans le journal de paix',
    
    catAnxiety: 'Anxiété & Stress',
    catWaswas: 'Pensées Obsessives (Waswas)',
    catSadness: 'Tristesse & Chagrin',
    catDebt: 'Dettes & Difficultés Financiéres',
    catAnger: 'Colère & Frustration',
    catFear: 'Peur de l\'Avenir',
    catSin: 'Culpabilité & Repentir',
    catLoneliness: 'Solitude & Isolement',
    catIllness: 'Douleur & Maladie',
    
    share: 'Partager',
    bookmark: 'Sauvegarder',
    bookmarked: 'Sauvegardé',
    copied: 'Copié',
    save: 'Enregistrer',
    cancel: 'Annuler',
    active: 'Actif',
    hoursAgo: 'h',
    minutesAgo: 'm',
    languageSelect: 'Langue de l\'application',
    sourceLabel: 'Source',
    narratorLabel: 'Rapporteur / Savant',
  },
  
  ur: {
    appName: 'مبعد الشيطان',
    appSubtitle: 'سکون، باجماعت نماز کی خاموشی اور مستند نفسیاتی و روحانی سہارے کا حصن',
    tabHome: 'صفحہ اول',
    tabSupport: 'نفسیاتی معاونت',
    tabHourlyStream: 'گھنٹہ وار حکمت',
    tabAthkar: 'اذکار و تسبیح',
    tabSettings: 'ترتیبات',
    
    nextPrayer: 'اگلی نماز',
    muteStatusActive: 'خاموشی موڈ فعال ہے (میں اللہ کے گھر میں ہوں)',
    muteStatusInactive: 'اذان کے وقت خاموشی کا موڈ تیار ہے',
    autoMuteMessage: 'میں اللہ کے گھر میں نماز ادا کر رہا ہوں، ان شاء اللہ جلد رابطہ کروں گا',
    muteDurationText: 'اذان کے بعد خاموشی کا وقت',
    enableAutoMute: 'اوقاتِ نماز میں فون کا خودکار سائلنٹ موڈ',
    manualMuteToggle: 'مسجد میں فوراً سائلنٹ کریں',
    mosqueModeOn: 'فون اس وقت سائلنٹ ہے',
    mosqueModeOff: 'فون نارمل ساؤنڈ موڈ میں ہے',
    houseOfAllahMessage: 'خودکار پیغام: "میں اللہ کے گھر میں ہوں"',
    smsAutoReplyTitle: 'نماز کے دوران خودکار جواب بھیجیں',
    smsAutoReplyDesc: 'نماز کے وقت سائلنٹ ہونے پر کال کرنے والوں کو پیغام جاتا ہے',
    qiblaDirection: 'قبلہ کی سمت',
    cityCountry: 'شہر اور ملک',
    gpsDetectBtn: 'جی پی ایس سے لوکیشن معلوم کریں',
    gpsDetectSuccess: 'آپ کی جی پی ایس لوکیشن کے مطابق نماز کے اوقات اپ ڈیٹ ہو گئے ہیں',
    
    enterBurdenTitle: 'ان دنوں کونسی بات آپ کو پریشان کر رہی ہے؟',
    enterBurdenSubtitle: 'اپنے دل کا حال لکھیں، ہم مستند قرآن و حدیث اور ائمہ اہل سنت کے اقوال سے سکون پہنچائیں گے',
    enterBurdenPlaceholder: 'مثال: مجھے شدید تشویش، مستقبل کا خوف اور ذہن کی بے چینی ہے...',
    analyzeBurdenBtn: 'روحانی و نفسیاتی سکون حاصل کریں',
    selectHardshipCategory: 'یا اپنی مشکل کا زمرہ منتخب کریں:',
    hourlyWisdomTitle: 'ہر گھنٹے کی حکمت و سکون',
    hourlyWisdomSubtitle: 'صحیح آیات، احادیث، صحابہ اور ائمہ اہل سنت کے اقوال',
    quickPeaceShot: 'فوری قلبی تسلی',
    identifyProblemTitle: 'مسئلے کی جڑ کی نشاندہی',
    gentleQuestionTitle: 'سوچنے اور سکون پانے کے لیے سوال:',
    authenticSourceNotice: 'مستند ترین ذرائع: صرف صحیح بخاری، مسلم اور ائمہ اہل سنت کی روایات',
    sunniAuthenticityGuarantee: 'تصدیق شدہ مراجع: قرآن، صحیحین، امام ابو حنیفہ، مالک، شافعی، احمد، ابن القیم',
    saveJournalBtn: 'سکون کی ڈائری میں محفوظ کریں',
    
    catAnxiety: 'تشویش اور تناؤ',
    catWaswas: 'وسوسے اور ذہنی الجھن',
    catSadness: 'غم اور اداسی',
    catDebt: 'تنگدستی اور قرض',
    catAnger: 'غصہ اور اشتعال',
    catFear: 'مستقبل کا خوف',
    catSin: 'گناہ کا احساس اور توبہ',
    catLoneliness: 'تنہائی اور بے کسی',
    catIllness: 'بیماری اور تکلیف',
    
    share: 'شیئر',
    bookmark: 'محفوظ',
    bookmarked: 'محفوظ شدہ',
    copied: 'کاپی ہو گیا',
    save: 'محفوظ کریں',
    cancel: 'منسوخ',
    active: 'فعال',
    hoursAgo: 'گھنٹے پہلے',
    minutesAgo: 'منٹ پہلے',
    languageSelect: 'ایپ کی زبان',
    sourceLabel: 'مصدر',
    narratorLabel: 'راوی / عالم',
  },
  
  tr: {
    appName: "Mub'id Es-Seytan",
    appSubtitle: 'Namazda Sessize Alma, Huzur ve Sahih Sünnetle Psikolojik Destek',
    tabHome: 'Ana Sayfa',
    tabSupport: 'Ruhi Destek',
    tabHourlyStream: 'Saatlik Akış',
    tabAthkar: 'Zikir & Tesbih',
    tabSettings: 'Ayarlar',
    
    nextPrayer: 'Sıradaki Vakit',
    muteStatusActive: 'Otomatik Sessiz Mod Aktif (Allah\'ın Evindeyim)',
    muteStatusInactive: 'Ezan Vakti Otomatik Sessiz Mod Hazır',
    autoMuteMessage: 'Allah\'ın evindeyim - Şu an namaz kılıyorum, InsaAllah daha sonra arayacağım',
    muteDurationText: 'Ezandan Sonra Sessizlik Süresi',
    enableAutoMute: 'Namaz Vakitlerinde Otomatik Sessize Al',
    manualMuteToggle: 'Cami İçin Anında Sessiz Mod',
    mosqueModeOn: 'Telefon Sessiz Modda',
    mosqueModeOff: 'Telefon Normal Modda',
    houseOfAllahMessage: 'Otomatik Mesaj: "Allah\'ın Evindeyim"',
    smsAutoReplyTitle: 'Namaz Esnasında Otomatik Mesaj Gönder',
    smsAutoReplyDesc: 'Namaz vaktinde telefon sessizdeyken arayanlara otomatik cevap verir',
    qiblaDirection: 'Kıble Yönü',
    cityCountry: 'Şehir & Ülke',
    gpsDetectBtn: 'GPS Konumu Tespit Et',
    gpsDetectSuccess: 'Namaz vakitleri GPS konumunuza göre güncellendi',
    
    enterBurdenTitle: 'Bugünlerde sizi en çok ne yoruyor?',
    enterBurdenSubtitle: 'İçinizi dökün. Sahih Kur\'an, Sünnet ve Ehli Sünnet alimlerinin sözleriyle huzur veriyoruz',
    enterBurdenPlaceholder: 'örnek: Aşırı kaygı, gelecek korkusu ve zihinsel karmaşa yaşıyorum...',
    analyzeBurdenBtn: 'Psikolojik ve Manevi Desteği Başlat',
    selectHardshipCategory: 'Veya yaşadığınız sıkıntı kategorisini seçin:',
    hourlyWisdomTitle: 'Saatlik Huzur Akışı',
    hourlyWisdomSubtitle: 'Sahih Ayetler, Hadisler, Sahabe ve Ehli Sünnet İmamlarının Sözleri',
    quickPeaceShot: 'Anında Kalp Ferahlığı',
    identifyProblemTitle: 'Sorunun Kaynağını Nazikçe Teşhis Etme',
    gentleQuestionTitle: 'Zihni Rahatlatıcı Düşünce Sorusu:',
    authenticSourceNotice: 'Kesin Sahihtik: Sadece Buhari, Müslim ve Ehli Sünnet imamlarının rivayetleri',
    sunniAuthenticityGuarantee: 'Güvenilir Kaynaklar: Kur\'an, Sahihayn, Ebu Hanife, Malik, Şafiî, Ahmed, İbn Al-Kayyim',
    saveJournalBtn: 'Huzur Günlüğüne Kaydet',
    
    catAnxiety: 'Kaygı ve Stres',
    catWaswas: 'Vesvese ve Takıntı',
    catSadness: 'Üzüntü ve Keder',
    catDebt: 'Rızık Darlığı ve Borç',
    catAnger: 'Öfke ve Parlama',
    catFear: 'Gelecek Korkusu',
    catSin: 'Pişmanlık ve Tövbe',
    catLoneliness: 'Yalnızlık Hissi',
    catIllness: 'Hastalık ve Ağrı',
    
    share: 'Paylaş',
    bookmark: 'Kaydet',
    bookmarked: 'Kaydedildi',
    copied: 'Kopyalandı',
    save: 'Kaydet',
    cancel: 'İptal',
    active: 'Aktif',
    hoursAgo: 'saat önce',
    minutesAgo: 'dk önce',
    languageSelect: 'Uygulama Dili',
    sourceLabel: 'Kaynak',
    narratorLabel: 'Ravi / Alim',
  },
  
  id: {
    appName: "Mu'bid Al-Shaitan",
    appSubtitle: 'Pelindung Ketenangan, Pembuang Bisikan, dan Dukungan Psikologis Shahih',
    tabHome: 'Beranda',
    tabSupport: 'Dukungan Jiwa',
    tabHourlyStream: 'Aliran Jam-jam',
    tabAthkar: 'Zikir & Tasbih',
    tabSettings: 'Pengaturan',
    
    nextPrayer: 'Waktu Shalat Berikutnya',
    muteStatusActive: 'Mode Senyap Otomatis Aktif (Saya di Rumah Allah)',
    muteStatusInactive: 'Mode Senyap Siap Saat Adzan',
    autoMuteMessage: 'Saya sedang di Rumah Allah melaksanakan shalat, insyaAllah akan menghubungi Anda kembali',
    muteDurationText: 'Durasi Senyap Setelah Adzan',
    enableAutoMute: 'Aktifkan Mode Senyap Otomatis Saat Waktu Shalat',
    manualMuteToggle: 'Mode Senyap Instan Masjid',
    mosqueModeOn: 'Ponsel Dalam Mode Senyap',
    mosqueModeOff: 'Ponsel Dalam Mode Normal',
    houseOfAllahMessage: 'Pesan Otomatis: "Saya di Rumah Allah"',
    smsAutoReplyTitle: 'Kirim Balasan Otomatis Saat Shalat',
    smsAutoReplyDesc: 'Mengirim pesan otomatis ke pemanggil saat ponsel bisu untuk shalat',
    qiblaDirection: 'Arah Kiblat',
    cityCountry: 'Kota & Negara',
    gpsDetectBtn: 'Deteksi Lokasi GPS',
    gpsDetectSuccess: 'Waktu shalat diperbarui otomatis sesuai koordinat GPS Anda',
    
    enterBurdenTitle: 'Apa yang membuat Anda lelah dan cemas hari ini?',
    enterBurdenSubtitle: 'Tuliskan beban hati Anda. Kami bantu dengan lembut melalui Qur’an & Hadits Shahih Ahlus Sunnah',
    enterBurdenPlaceholder: 'Contoh: Saya merasa sangat cemas, takut akan masa depan, dan kecemasan berlebih...',
    analyzeBurdenBtn: 'Mulai Dukungan Psikologis & Ketenangan',
    selectHardshipCategory: 'Atau pilih kategori ujian yang Anda hadapi:',
    hourlyWisdomTitle: 'Aliran Ketenangan Setiap Jam',
    hourlyWisdomSubtitle: 'Ayat, Hadits Shahih, dan Ucapan Sahabat & Imam Ahlus Sunnah',
    quickPeaceShot: 'Ketenangan Kebut Kening',
    identifyProblemTitle: 'Mengidentifikasi Akar Masalah dengan Lembut',
    gentleQuestionTitle: 'Pertanyaan Refleksi Untuk Menenangkan Jiwa:',
    authenticSourceNotice: 'Jaminan Shahih: Hanya dari Shahih Bukhari, Muslim, Sahabat & Imam Ahlus Sunnah',
    sunniAuthenticityGuarantee: 'Sumber Terverifikasi: Al-Qur\'an, Shahih Bukhari & Muslim, Imam Abu Hanifah, Malik, Syafi\'i, Ahmad, Ibn Al-Qayyim',
    saveJournalBtn: 'Simpan ke Jurnal Ketenangan',
    
    catAnxiety: 'Kecemasan & Stres',
    catWaswas: 'Was-was & Pikiran Berlebihan',
    catSadness: 'Kesedihan & Duka',
    catDebt: 'Kesulitan Rezeki & Hutang',
    catAnger: 'Kemarahan & Emosi',
    catFear: 'Ketakutan Masa Depan',
    catSin: 'Rasa Salah & Taubat',
    catLoneliness: 'Kesepian & Kehampaian',
    catIllness: 'Rasa Sakit & Ujian Fisik',
    
    share: 'Bagikan',
    bookmark: 'Simpan',
    bookmarked: 'Tersimpan',
    copied: 'Tersalin',
    save: 'Simpan',
    cancel: 'Batal',
    active: 'Aktif',
    hoursAgo: 'jam lalu',
    minutesAgo: 'mnt lalu',
    languageSelect: 'Bahasa Aplikasi',
    sourceLabel: 'Sumber',
    narratorLabel: 'Perawi / Ulama',
  }
};