import { PrayerTime, CountryCity, Language } from '../types';

export const CITY_PRESETS: CountryCity[] = [
  {
    countryCode: 'SA',
    countryName: { ar: 'المملكة العربية السعودية', en: 'Saudi Arabia', fr: 'Arabie Saoudite', ur: 'سعودی عرب', tr: 'Suudi Arabistan', id: 'Arab Saudi' },
    cityName: { ar: 'مكة المكرمة', en: 'Makkah', fr: 'La Mecque', ur: 'مکہ مکرمہ', tr: 'Mekke', id: 'Makkah' },
    latitude: 21.4225,
    longitude: 39.8262,
    timezone: 'Asia/Riyadh'
  },
  {
    countryCode: 'SA_MED',
    countryName: { ar: 'المملكة العربية السعودية', en: 'Saudi Arabia', fr: 'Arabie Saoudite', ur: 'سعودی عرب', tr: 'Suudi Arabistan', id: 'Arab Saudi' },
    cityName: { ar: 'المدينة المنورة', en: 'Madinah', fr: 'Médine', ur: 'مدینہ منورہ', tr: 'Medine', id: 'Madinah' },
    latitude: 24.4672,
    longitude: 39.6112,
    timezone: 'Asia/Riyadh'
  },
  {
    countryCode: 'EG',
    countryName: { ar: 'جمهورية مصر العربية', en: 'Egypt', fr: 'Égypte', ur: 'مصر', tr: 'Mısır', id: 'Mesir' },
    cityName: { ar: 'القاهرة', en: 'Cairo', fr: 'Le Caire', ur: 'قاہرہ', tr: 'Kahire', id: 'Kairo' },
    latitude: 30.0444,
    longitude: 31.2357,
    timezone: 'Africa/Cairo'
  },
  {
    countryCode: 'AE',
    countryName: { ar: 'الإمارات العربية المتحدة', en: 'UAE', fr: 'Émirats Arabes Unis', ur: 'متحدہ عرب امارات', tr: 'Birleşik Arap Emirlikleri', id: 'Uni Emirat Arab' },
    cityName: { ar: 'أبو ظبي / دبي', en: 'Dubai / Abu Dhabi', fr: 'Dubaï / Abou Dhabi', ur: 'دبئی / ابوظہبی', tr: 'Dubai / Abu Dabi', id: 'Dubai / Abu Dhabi' },
    latitude: 25.2048,
    longitude: 55.2708,
    timezone: 'Asia/Dubai'
  },
  {
    countryCode: 'DZ',
    countryName: { ar: 'الجزائر', en: 'Algeria', fr: 'Algérie', ur: 'الجیریا', tr: 'Cezayir', id: 'Aljazair' },
    cityName: { ar: 'الجزائر العاصمة', en: 'Algiers', fr: 'Alger', ur: 'الجیرئس', tr: 'Cezayir', id: 'Algiers' },
    latitude: 36.7538,
    longitude: 3.0588,
    timezone: 'Africa/Algiers'
  },
  {
    countryCode: 'MA',
    countryName: { ar: 'المملكة المغربية', en: 'Morocco', fr: 'Maroc', ur: 'مراکش', tr: 'Fas', id: 'Maroko' },
    cityName: { ar: 'الرباط / الدار البيضاء', en: 'Rabat / Casablanca', fr: 'Rabat / Casablanca', ur: 'رباط / رباط', tr: 'Rabat / Kasablanka', id: 'Rabat' },
    latitude: 34.0209,
    longitude: -6.8416,
    timezone: 'Africa/Casablanca'
  },
  {
    countryCode: 'TR',
    countryName: { ar: 'تركيا', en: 'Turkey', fr: 'Turquie', ur: 'ترکی', tr: 'Türkiye', id: 'Turki' },
    cityName: { ar: 'إسطنبول', en: 'Istanbul', fr: 'Istanbul', ur: 'استنبول', tr: 'İstanbul', id: 'Istanbul' },
    latitude: 41.0082,
    longitude: 28.9784,
    timezone: 'Europe/Istanbul'
  },
  {
    countryCode: 'ID',
    countryName: { ar: 'إندونيسيا', en: 'Indonesia', fr: 'Indonésie', ur: 'انڈونیشیا', tr: 'Endonezya', id: 'Indonesia' },
    cityName: { ar: 'جاكرتا', en: 'Jakarta', fr: 'Jakarta', ur: 'جکارتہ', tr: 'Cakarta', id: 'Jakarta' },
    latitude: -6.2088,
    longitude: 106.8456,
    timezone: 'Asia/Jakarta'
  },
  {
    countryCode: 'PK',
    countryName: { ar: 'باكستان', en: 'Pakistan', fr: 'Pakistan', ur: 'پاکستان', tr: 'Pakistan', id: 'Pakistan' },
    cityName: { ar: 'إسلام آباد / كراتشي', en: 'Karachi / Islamabad', fr: 'Karachi', ur: 'کراچی / اسلام آباد', tr: 'Karaçi', id: 'Karachi' },
    latitude: 24.8607,
    longitude: 67.0011,
    timezone: 'Asia/Karachi'
  },
  {
    countryCode: 'US',
    countryName: { ar: 'الولايات المتحدة الأمريكية', en: 'United States', fr: 'États-Unis', ur: 'امریکہ', tr: 'Amerika Birleşik Devletleri', id: 'Amerika Serikat' },
    cityName: { ar: 'نيويورك', en: 'New York', fr: 'New York', ur: 'نیویارک', tr: 'New York', id: 'New York' },
    latitude: 40.7128,
    longitude: -74.0060,
    timezone: 'America/New_York'
  },
  {
    countryCode: 'GB',
    countryName: { ar: 'المملكة المتحدة', en: 'United Kingdom', fr: 'Royaume-Uni', ur: 'برطانیہ', tr: 'Birleşik Krallık', id: 'Inggris' },
    cityName: { ar: 'لندن', en: 'London', fr: 'Londres', ur: 'لندن', tr: 'Londra', id: 'London' },
    latitude: 51.5074,
    longitude: -0.1278,
    timezone: 'Europe/London'
  },
  {
    countryCode: 'FR',
    countryName: { ar: 'فرنسا', en: 'France', fr: 'France', ur: 'فرانس', tr: 'Fransa', id: 'Prancis' },
    cityName: { ar: 'باريس', en: 'Paris', fr: 'Paris', ur: 'پیرس', tr: 'Paris', id: 'Paris' },
    latitude: 48.8566,
    longitude: 2.3522,
    timezone: 'Europe/Paris'
  }
];

export function getPrayerTimesForCity(cityCode: string, date: Date = new Date()): PrayerTime[] {
  // Return realistic prayer times adjusted slightly per city latitude offset
  const preset = CITY_PRESETS.find(c => c.countryCode === cityCode) || CITY_PRESETS[0];
  const offset = Math.round((preset.longitude - 39.8262) * 4); // minutes offset relative to Makkah base

  const baseMinutes = {
    fajr: 5 * 60 + 2,
    sunrise: 6 * 60 + 22,
    dhuhr: 12 * 60 + 15,
    asr: 15 * 60 + 32,
    maghrib: 18 * 60 + 10,
    isha: 19 * 60 + 40,
  };

  const formatTime = (totalMins: number) => {
    let normalized = (totalMins - offset + 1440) % 1440;
    const hours = Math.floor(normalized / 60).toString().padStart(2, '0');
    const mins = Math.floor(normalized % 60).toString().padStart(2, '0');
    return `${hours}:${mins}`;
  };

  const times: PrayerTime[] = [
    { name: 'الفجر', key: 'fajr', time: formatTime(baseMinutes.fajr) },
    { name: 'الشروق', key: 'sunrise', time: formatTime(baseMinutes.sunrise) },
    { name: 'الظهر', key: 'dhuhr', time: formatTime(baseMinutes.dhuhr) },
    { name: 'العصر', key: 'asr', time: formatTime(baseMinutes.asr) },
    { name: 'المغرب', key: 'maghrib', time: formatTime(baseMinutes.maghrib) },
    { name: 'العشاء', key: 'isha', time: formatTime(baseMinutes.isha) },
  ];

  return times;
}

export function getNextPrayer(times: PrayerTime[]): { nextPrayer: PrayerTime; timeRemaining: string; minutesUntil: number; isMuteWindowActive: boolean } {
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  let nextPrayer: PrayerTime = times[0];
  let minutesUntil = 9999;
  let isMuteWindowActive = false;

  for (let i = 0; i < times.length; i++) {
    const [h, m] = times[i].time.split(':').map(Number);
    const pMinutes = h * 60 + m;

    // Check if we are currently within 20 mins after prayer time (Mute window)
    if (currentMinutes >= pMinutes && currentMinutes <= pMinutes + 20 && times[i].key !== 'sunrise') {
      isMuteWindowActive = true;
    }

    if (pMinutes > currentMinutes) {
      nextPrayer = times[i];
      minutesUntil = pMinutes - currentMinutes;
      break;
    }
  }

  // If all prayers today have passed, next prayer is Fajr tomorrow
  if (minutesUntil === 9999) {
    const [h, m] = times[0].time.split(':').map(Number);
    const pMinutes = h * 60 + m;
    minutesUntil = (24 * 60 - currentMinutes) + pMinutes;
    nextPrayer = times[0];
  }

  const hours = Math.floor(minutesUntil / 60);
  const mins = minutesUntil % 60;
  const secs = 59 - now.getSeconds();

  const formattedRemaining = `${hours > 0 ? `${hours}h ` : ''}${mins}m ${secs}s`;

  return { nextPrayer, timeRemaining: formattedRemaining, minutesUntil, isMuteWindowActive };
}

export function getQiblaAngle(latitude: number, longitude: number): number {
  // Makkah coordinates
  const makkahLat = 21.4225 * (Math.PI / 180);
  const makkahLng = 39.8262 * (Math.PI / 180);
  
  const userLat = latitude * (Math.PI / 180);
  const userLng = longitude * (Math.PI / 180);
  
  const y = Math.sin(makkahLng - userLng);
  const x = Math.cos(userLat) * Math.tan(makkahLat) - Math.sin(userLat) * Math.cos(makkahLng - userLng);
  
  let qibla = Math.atan2(y, x) * (180 / Math.PI);
  return (qibla + 360) % 360;
}
