import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Share } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { HeaderBar } from '../components/HeaderBar';
import { AuthenticQuoteCard } from '../components/AuthenticQuoteCard';
import { CategoryChips } from '../components/CategoryChips';
import { useApp } from '../context/AppContext';
import { AUTHENTIC_DATABASE } from '../data/authenticDatabase';

export const HourlyStreamScreen: React.FC = () => {
  const { t, currentWisdom, nextHourlyWisdom, activeCategory, language } = useApp();

  const categoryQuotes = AUTHENTIC_DATABASE.filter(q => q.category === activeCategory);

  return (
    <View style={styles.container}>
      <HeaderBar />

      <ScrollView style={styles.scrollArea} showsVerticalScrollIndicator={false}>
        {/* Header Title */}
        <View style={styles.headerBox}>
          <Ionicons name="time-sharp" size={32} color="#10B981" />
          <Text style={styles.title}>{t.hourlyWisdomTitle}</Text>
          <Text style={styles.subtitle}>{t.hourlyWisdomSubtitle}</Text>
        </View>

        {/* Quick Peace Shot Action Bar */}
        <TouchableOpacity style={styles.quickShotBtn} onPress={nextHourlyWisdom}>
          <Ionicons name="flash-sharp" size={20} color="#FFD700" />
          <Text style={styles.quickShotText}>{t.quickPeaceShot}</Text>
          <Ionicons name="refresh-circle" size={22} color="#10B981" />
        </TouchableOpacity>

        {/* Category Chips */}
        <CategoryChips />

        {/* Active Featured Quote Card */}
        <AuthenticQuoteCard wisdom={currentWisdom} />

        {/* Continuous Stream List */}
        <Text style={styles.streamListHeader}>سرد الحِكم والأحاديث لـ {t[`cat${activeCategory.split('_')[0].charAt(0).toUpperCase() + activeCategory.split('_')[0].slice(1)}` as keyof typeof t] || 'هذا المجال'}:</Text>

        {categoryQuotes.map((item) => (
          <View key={item.id} style={styles.streamCard}>
            <View style={styles.streamCardHeader}>
              <View style={styles.badgeSource}>
                <Ionicons name="checkmark-seal" size={12} color="#10B981" />
                <Text style={styles.badgeSourceText}>{item.source}</Text>
              </View>
              <Text style={styles.authorText}>{item.narratorOrAuthor}</Text>
            </View>

            <Text style={styles.streamArabicText}>«{item.arabicText}»</Text>

            <Text style={styles.streamPsychText}>
              {item.psychologicalContext[language] || item.psychologicalContext.ar}
            </Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  scrollArea: {
    flex: 1,
  },
  headerBox: {
    alignItems: 'center',
    marginVertical: 16,
    paddingHorizontal: 16,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    marginTop: 6,
  },
  subtitle: {
    color: '#94A3B8',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 2,
  },
  quickShotBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#064E3B',
    marginHorizontal: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#10B981',
    marginBottom: 10,
  },
  quickShotText: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '800',
  },
  streamListHeader: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    marginHorizontal: 16,
    marginTop: 10,
    marginBottom: 10,
  },
  streamCard: {
    backgroundColor: '#1E293B',
    borderRadius: 16,
    padding: 14,
    marginHorizontal: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  streamCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  badgeSource: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#0F172A',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  badgeSourceText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },
  authorText: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  streamArabicText: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '700',
    lineHeight: 26,
    marginBottom: 8,
  },
  streamPsychText: {
    color: '#CBD5E1',
    fontSize: 12,
    lineHeight: 18,
  },
});
