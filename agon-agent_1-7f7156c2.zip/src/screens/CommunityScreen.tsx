import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { HeaderBar } from '../components/HeaderBar';
import { useApp } from '../context/AppContext';
import { HardshipCategory } from '../types';

export const CommunityScreen: React.FC = () => {
  const { t, communityDuas, togglePrayedForDua, addCommunityDua, activeCategory } = useApp();
  const [newDuaText, setNewDuaText] = useState('');
  const [showInput, setShowInput] = useState(false);

  const handlePostDua = () => {
    if (!newDuaText.trim()) {
      Alert.alert('تنبيه', 'يرجى كتابة دعائك المبتغى لنشره في حلقة الجماعة.');
      return;
    }
    addCommunityDua(newDuaText.trim(), activeCategory);
    setNewDuaText('');
    setShowInput(false);
    Alert.alert('تم بنجاح', 'تم نشر طلب الدعاء في حلقة الجماعة بظهر الغيب.');
  };

  return (
    <View style={styles.container}>
      <HeaderBar />

      <ScrollView style={styles.scrollArea} showsVerticalScrollIndicator={false}>
        {/* Header Title Banner */}
        <View style={styles.banner}>
          <Ionicons name="people-sharp" size={32} color="#10B981" />
          <Text style={styles.bannerTitle}>{t.communityTitle}</Text>
          <Text style={styles.bannerSubtitle}>{t.communitySubtitle}</Text>
        </View>

        {/* Solidarity Authentic Hadith Quote */}
        <View style={styles.hadithNotice}>
          <Ionicons name="ribbon-sharp" size={20} color="#FFD700" />
          <Text style={styles.hadithNoticeText}>
            قال النبي ﷺ: «دَعْوَةُ الْمَرْءِ الْمُسْلِمِ لأَخِيهِ بِظَهْرِ الْغَيْبِ مُسْتَجَابَةٌ، عِنْدَ رَأْسِهِ مَلَكٌ مُوَكَّلٌ كُلَّمَا دَعَا لأَخِيهِ بِخَيْرٍ قَالَ الْمَلَكُ: آمِينَ وَلَكَ بِمِثْلٍ» (صحيح مسلم)
          </Text>
        </View>

        {/* Post Dua Action Button */}
        {!showInput ? (
          <TouchableOpacity style={styles.postTriggerBtn} onPress={() => setShowInput(true)}>
            <Ionicons name="add-circle" size={22} color="#FFF" />
            <Text style={styles.postTriggerText}>{t.requestDua}</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.inputBoxCard}>
            <View style={styles.inputHeader}>
              <Text style={styles.inputHeaderTitle}>اطلب دعاء إخوانك المسلمين بظهر الغيب</Text>
              <TouchableOpacity onPress={() => setShowInput(false)}>
                <Ionicons name="close" size={18} color="#94A3B8" />
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.duaInput}
              placeholder={t.postDuaPlaceholder}
              placeholderTextColor="#64748B"
              multiline
              numberOfLines={3}
              value={newDuaText}
              onChangeText={setNewDuaText}
              textAlignVertical="top"
            />

            <TouchableOpacity style={styles.submitBtn} onPress={handlePostDua}>
              <Ionicons name="paper-plane-sharp" size={16} color="#FFF" />
              <Text style={styles.submitBtnText}>{t.submitDuaBtn}</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Community Dua Feed */}
        <View style={styles.feedHeader}>
          <Ionicons name="heart-sharp" size={18} color="#10B981" />
          <Text style={styles.feedTitle}>{t.communityCircle}</Text>
        </View>

        {communityDuas.map((dua) => (
          <View key={dua.id} style={styles.duaCard}>
            <View style={styles.duaHeader}>
              <View style={styles.authorRow}>
                <View style={styles.authorAvatar}>
                  <Ionicons name="person" size={14} color="#10B981" />
                </View>
                <View>
                  <Text style={styles.authorName}>{dua.authorAlias}</Text>
                  <Text style={styles.metaText}>{dua.country} • {dua.timeAgo}</Text>
                </View>
              </View>

              <View style={styles.countBadge}>
                <Text style={styles.countBadgeText}>{dua.prayedCount} {t.prayedCountLabel}</Text>
              </View>
            </View>

            <Text style={styles.duaBodyText}>"{dua.text}"</Text>

            <View style={styles.duaCardFooter}>
              <TouchableOpacity 
                style={[styles.prayBtn, dua.hasUserPrayed && styles.prayBtnActive]} 
                onPress={() => togglePrayedForDua(dua.id)}
              >
                <Ionicons 
                  name={dua.hasUserPrayed ? "heart" : "heart-outline"} 
                  size={18} 
                  color={dua.hasUserPrayed ? "#FFF" : "#10B981"} 
                />
                <Text style={[styles.prayBtnText, dua.hasUserPrayed && styles.prayBtnTextActive]}>
                  {dua.hasUserPrayed ? 'تم الدعاء لك بظهر الغيب ✓' : t.prayedForYou}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  scrollArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  banner: {
    alignItems: 'center',
    marginVertical: 16,
  },
  bannerTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    marginTop: 6,
  },
  bannerSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 2,
  },
  hadithNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    backgroundColor: '#78350F20',
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#F59E0B40',
    marginBottom: 16,
  },
  hadithNoticeText: {
    color: '#FEF3C7',
    fontSize: 12,
    lineHeight: 20,
    flex: 1,
  },
  postTriggerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#059669',
    paddingVertical: 14,
    borderRadius: 16,
    marginBottom: 20,
  },
  postTriggerText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '700',
  },
  inputBoxCard: {
    backgroundColor: '#1E293B',
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 20,
  },
  inputHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  inputHeaderTitle: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
  },
  duaInput: {
    backgroundColor: '#0F172A',
    borderRadius: 12,
    padding: 10,
    color: '#F8FAFC',
    fontSize: 13,
    minHeight: 70,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 10,
  },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#059669',
    paddingVertical: 10,
    borderRadius: 12,
  },
  submitBtnText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
  },
  feedHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  feedTitle: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '700',
  },
  duaCard: {
    backgroundColor: '#1E293B',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  duaHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  authorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  authorAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#064E3B',
    alignItems: 'center',
    justifyContent: 'center',
  },
  authorName: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
  },
  metaText: {
    color: '#64748B',
    fontSize: 11,
  },
  countBadge: {
    backgroundColor: '#0F172A',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  countBadgeText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },
  duaBodyText: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 12,
  },
  duaCardFooter: {
    borderTopWidth: 1,
    borderTopColor: '#334155',
    paddingTop: 10,
  },
  prayBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#0F172A',
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  prayBtnActive: {
    backgroundColor: '#059669',
    borderColor: '#10B981',
  },
  prayBtnText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
  },
  prayBtnTextActive: {
    color: '#FFF',
  },
});
