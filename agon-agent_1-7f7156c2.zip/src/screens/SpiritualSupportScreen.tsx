import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { HeaderBar } from '../components/HeaderBar';
import { useApp } from '../context/AppContext';
import { AUTHENTIC_DATABASE } from '../data/authenticDatabase';

export const SpiritualSupportScreen: React.FC = () => {
  const { t, language, activeCategory, setActiveCategory, userBurdens, addUserBurden, currentWisdom } = useApp();
  const [inputText, setInputText] = useState('');
  const [activeStep, setActiveStep] = useState<number>(0);
  const [userSelectedIssue, setUserSelectedIssue] = useState<string>('');

  const relevantWisdoms = AUTHENTIC_DATABASE.filter(w => w.category === activeCategory);
  const primaryWisdom = relevantWisdoms[0] || AUTHENTIC_DATABASE[0];

  const handleAnalyze = () => {
    if (!inputText.trim()) {
      Alert.alert('تنبيه', 'يرجى كتابة ما تشعر به لتلقي الدعم والتشخيص اللطيف.');
      return;
    }
    addUserBurden(inputText.trim(), activeCategory);
    setActiveStep(1);
  };

  return (
    <View style={styles.container}>
      <HeaderBar />

      <ScrollView style={styles.scrollArea} showsVerticalScrollIndicator={false}>
        {/* Title Header */}
        <View style={styles.headerSection}>
          <View style={styles.iconCircle}>
            <Ionicons name="heart-dislike-outline" size={28} color="#10B981" />
          </View>
          <Text style={styles.screenTitle}>{t.tabSupport}</Text>
          <Text style={styles.screenSubtitle}>
            تحديد جذر المشكلة والسكينة بالأدلة الصحيحة دون إرشاد قاسية
          </Text>
        </View>

        {/* Step 1: Input Struggle / Burden */}
        <View style={styles.cardBox}>
          <View style={styles.stepTitleRow}>
            <View style={styles.stepBadge}><Text style={styles.stepBadgeText}>1</Text></View>
            <Text style={styles.cardTitle}>{t.enterBurdenTitle}</Text>
          </View>

          <TextInput
            style={styles.textInput}
            placeholder={t.enterBurdenPlaceholder}
            placeholderTextColor="#64748B"
            multiline
            numberOfLines={4}
            value={inputText}
            onChangeText={setInputText}
            textAlignVertical="top"
          />

          <TouchableOpacity style={styles.analyzeBtn} onPress={handleAnalyze}>
            <Ionicons name="sparkles" size={18} color="#FFF" />
            <Text style={styles.analyzeBtnText}>{t.analyzeBurdenBtn}</Text>
          </TouchableOpacity>
        </View>

        {/* Step 2: Gentle Diagnostic Question ("يسأله عن تحديد المشكلة") */}
        <View style={styles.cardBox}>
          <View style={styles.stepTitleRow}>
            <View style={styles.stepBadge}><Text style={styles.stepBadgeText}>2</Text></View>
            <Text style={styles.cardTitle}>{t.identifyProblemTitle}</Text>
          </View>

          <Text style={styles.diagnosticIntro}>
            لتفكيك الضغط الذهني، نسألك بلطف لتحديد مصدر الأذى والوسواس:
          </Text>

          <View style={styles.questionCard}>
            <Ionicons name="help-circle-sharp" size={22} color="#FFD700" />
            <Text style={styles.questionCardText}>
              {primaryWisdom.diagnosticQuestion ? (primaryWisdom.diagnosticQuestion[language] || primaryWisdom.diagnosticQuestion.ar) : 'ما الذي تجده أثقل شأن على قلبك الآن؟'}
            </Text>
          </View>

          <View style={styles.issuesOptionList}>
            {[
              'الخوف من المستقبل وعدم الوضوح',
              'شعور بالفشل أو التقصير الشخصي',
              'وساوس وتفكير متسارع لا يتوقف',
              'ضغط مادي أو علاقات مشحونة'
            ].map((issue, idx) => (
              <TouchableOpacity
                key={idx}
                style={[styles.issueOptionItem, userSelectedIssue === issue && styles.issueOptionActive]}
                onPress={() => setUserSelectedIssue(issue)}
              >
                <Ionicons 
                  name={userSelectedIssue === issue ? "checkmark-circle" : "ellipse-outline"} 
                  size={18} 
                  color={userSelectedIssue === issue ? "#10B981" : "#64748B"} 
                />
                <Text style={[styles.issueOptionText, userSelectedIssue === issue && styles.issueOptionTextActive]}>
                  {issue}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Step 3: Verified Authentic Remedy Plan */}
        <View style={styles.cardBox}>
          <View style={styles.stepTitleRow}>
            <View style={styles.stepBadge}><Text style={styles.stepBadgeText}>3</Text></View>
            <Text style={styles.cardTitle}>الدواء الإيماني والنفسي الثابت</Text>
          </View>

          <View style={styles.remedyBox}>
            <View style={styles.remedyTypeTag}>
              <Ionicons name="shield-checkmark" size={14} color="#FFF" />
              <Text style={styles.remedyTypeText}>دليل من {primaryWisdom.source}</Text>
            </View>

            <Text style={styles.remedyArabic}>«{primaryWisdom.arabicText}»</Text>
            <Text style={styles.remedyAuthor}>- {primaryWisdom.narratorOrAuthor}</Text>

            <View style={styles.remedyExplanation}>
              <Text style={styles.remedyExpText}>
                {primaryWisdom.psychologicalContext[language] || primaryWisdom.psychologicalContext.ar}
              </Text>
            </View>
          </View>

          {/* Practical 3-Step Action Plan */}
          <View style={styles.actionPlanBox}>
            <Text style={styles.planTitle}>خطوات عملية فورية لطرد الوسواس وضيق الصدر:</Text>

            <View style={styles.planItem}>
              <Text style={styles.planNumber}>أ</Text>
              <Text style={styles.planText}>الاستعاذة بالله من الشيطان والوسواس مباشرة: "آمنت بالله ورسله".</Text>
            </View>

            <View style={styles.planItem}>
              <Text style={styles.planNumber}>ب</Text>
              <Text style={styles.planText}>تغيير وضع الجسد والتوضؤ ثم أداء صلاة ركعتين خفيفتين بقلب حاضِر.</Text>
            </View>

            <View style={styles.planItem}>
              <Text style={styles.planNumber}>ج</Text>
              <Text style={styles.planText}>الاطمئنان بأن كل ما أصابك لم يكن ليخطئك، وأن فرج الله قريب جداً.</Text>
            </View>
          </View>
        </View>

        {/* Saved Journal History */}
        {userBurdens.length > 0 && (
          <View style={styles.journalSection}>
            <Text style={styles.journalTitle}>سجل مناجاتك وسكينتك:</Text>
            {userBurdens.map((b) => (
              <View key={b.id} style={styles.journalCard}>
                <View style={styles.journalHeader}>
                  <Ionicons name="calendar-outline" size={14} color="#10B981" />
                  <Text style={styles.journalDate}>{b.date}</Text>
                </View>
                <Text style={styles.journalText}>"{b.userInputText}"</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  scrollArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  headerSection: {
    alignItems: 'center',
    marginVertical: 16,
  },
  iconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#064E3B',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  screenTitle: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '800',
  },
  screenSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 4,
    paddingHorizontal: 20,
  },
  cardBox: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  stepTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 12,
  },
  stepBadge: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepBadgeText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
  cardTitle: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  textInput: {
    backgroundColor: '#0F172A',
    borderRadius: 14,
    padding: 12,
    color: '#F8FAFC',
    fontSize: 13,
    minHeight: 90,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 12,
  },
  analyzeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#059669',
    paddingVertical: 12,
    borderRadius: 14,
  },
  analyzeBtnText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '700',
  },
  diagnosticIntro: {
    color: '#CBD5E1',
    fontSize: 13,
    marginBottom: 10,
  },
  questionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#78350F20',
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#F59E0B40',
    marginBottom: 12,
  },
  questionCardText: {
    color: '#FEF3C7',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
    lineHeight: 20,
  },
  issuesOptionList: {
    gap: 8,
  },
  issueOptionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#0F172A',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  issueOptionActive: {
    backgroundColor: '#064E3B20',
    borderColor: '#10B981',
  },
  issueOptionText: {
    color: '#CBD5E1',
    fontSize: 13,
    flex: 1,
  },
  issueOptionTextActive: {
    color: '#F8FAFC',
    fontWeight: '700',
  },
  remedyBox: {
    backgroundColor: '#0F172A',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 12,
  },
  remedyTypeTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#059669',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginBottom: 8,
  },
  remedyTypeText: {
    color: '#FFF',
    fontSize: 11,
    fontWeight: '700',
  },
  remedyArabic: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '700',
    lineHeight: 28,
    marginBottom: 6,
  },
  remedyAuthor: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 10,
  },
  remedyExplanation: {
    backgroundColor: '#1E293B',
    padding: 10,
    borderRadius: 10,
  },
  remedyExpText: {
    color: '#CBD5E1',
    fontSize: 12,
    lineHeight: 19,
  },
  actionPlanBox: {
    backgroundColor: '#064E3B20',
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#10B98140',
  },
  planTitle: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 8,
  },
  planItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 6,
  },
  planNumber: {
    color: '#FFD700',
    fontWeight: '800',
    fontSize: 12,
  },
  planText: {
    color: '#E2E8F0',
    fontSize: 12,
    flex: 1,
    lineHeight: 18,
  },
  journalSection: {
    marginBottom: 30,
  },
  journalTitle: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 10,
  },
  journalCard: {
    backgroundColor: '#1E293B',
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#334155',
  },
  journalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  journalDate: {
    color: '#94A3B8',
    fontSize: 11,
  },
  journalText: {
    color: '#F8FAFC',
    fontSize: 13,
  },
});
