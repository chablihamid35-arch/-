import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { HeaderBar } from '../components/HeaderBar';
import { useApp } from '../context/AppContext';

const VERIFIED_ATHKAR = [
  {
    id: 'athkar_1',
    title: 'أذكار الصباح والمساء الحاصنة',
    text: '«حَسْبِيَ اللَّهُ لا إِلَهَ إِلاَّ هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ» (7 مرات)',
    reward: 'يكفيك الله ما أهمك من أمر الدنيا والآخرة.'
  },
  {
    id: 'athkar_2',
    title: 'دعاء طرد الوسواس والحيرة',
    text: '«أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ، آَمَنْتُ بِاللَّهِ وَرُسُلِهِ»',
    reward: 'يذهب الشيطان وينخنس كالحشرة.'
  },
  {
    id: 'athkar_3',
    title: 'سيد الاستغفار',
    text: '«اللَّهُمَّ أَنْتَ رَبِّي لاَ إِلَهَ إِلاَّ أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ»',
    reward: 'من قالها موقناً بها ومات دخل الجنة.'
  },
  {
    id: 'athkar_4',
    title: 'دعاء الكرب والتفنيج',
    text: '«لاَ إِلَهَ إِلاَّ اللَّهُ العَظِيمُ الحَلِيمُ، لاَ إِلَهَ إِلاَّ اللَّهُ رَبُّ العَرْشِ العَظِيمِ»',
    reward: 'يكشف الله بها الهم العظيم.'
  }
];

export const AthkarAudioScreen: React.FC = () => {
  const { ambientSound, setAmbientSound, playingAudioId, setPlayingAudioId, t } = useApp();
  const [tasbeehCount, setTasbeehCount] = useState(0);

  return (
    <View style={styles.container}>
      <HeaderBar />

      <ScrollView style={styles.scrollArea} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.headerBox}>
          <Ionicons name="musical-notes-sharp" size={32} color="#10B981" />
          <Text style={styles.title}>{t.tabAthkar}</Text>
          <Text style={styles.subtitle}>أذكار حصن المسلم الثابتة والسكينة الصوتية</Text>
        </View>

        {/* Ambient Sound Switch Card */}
        <View style={styles.ambientCard}>
          <View style={styles.ambientLeft}>
            <Ionicons name="rainy-sharp" size={24} color="#38BDF8" />
            <View>
              <Text style={styles.ambientTitle}>خلفية صوت الطبيعة والاسترخاء</Text>
              <Text style={styles.ambientDesc}>صوت المطر والسكينة لهدوء الأعصاب</Text>
            </View>
          </View>
          <Switch
            value={ambientSound}
            onValueChange={setAmbientSound}
            trackColor={{ false: '#334155', true: '#059669' }}
            thumbColor={ambientSound ? '#10B981' : '#94A3B8'}
          />
        </View>

        {/* Tasbeeh / Dhikr Counter Widget */}
        <View style={styles.tasbeehCard}>
          <View style={styles.tasbeehHeader}>
            <Ionicons name="disc-sharp" size={20} color="#FFD700" />
            <Text style={styles.tasbeehTitle}>سبحة السكينة والاستغفار</Text>
          </View>

          <Text style={styles.tasbeehText}>«أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ»</Text>

          <View style={styles.counterRow}>
            <TouchableOpacity style={styles.resetBtn} onPress={() => setTasbeehCount(0)}>
              <Ionicons name="refresh" size={18} color="#94A3B8" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.countTapBtn} 
              onPress={() => setTasbeehCount(prev => prev + 1)}
              activeOpacity={0.8}
            >
              <Text style={styles.countNumber}>{tasbeehCount}</Text>
              <Text style={styles.countLabel}>اضغط للتسبيح</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Authentic Athkar Cards List */}
        <Text style={styles.sectionHeader}>أذكار صحيحة ومأثورة:</Text>

        {VERIFIED_ATHKAR.map((item) => {
          const isPlaying = playingAudioId === item.id;
          return (
            <View key={item.id} style={styles.athkarCard}>
              <Text style={styles.athkarTitle}>{item.title}</Text>
              <Text style={styles.athkarBody}>{item.text}</Text>

              <View style={styles.rewardBox}>
                <Ionicons name="sparkles" size={14} color="#10B981" />
                <Text style={styles.rewardText}>{item.reward}</Text>
              </View>

              <TouchableOpacity 
                style={[styles.playAudioBtn, isPlaying && styles.playAudioBtnActive]}
                onPress={() => setPlayingAudioId(isPlaying ? null : item.id)}
              >
                <Ionicons name={isPlaying ? "pause" : "play"} size={16} color="#FFF" />
                <Text style={styles.playAudioBtnText}>
                  {isPlaying ? 'إيقاف الصوت' : 'استماع الذكر'}
                </Text>
              </TouchableOpacity>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  scrollArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  headerBox: {
    alignItems: 'center',
    marginVertical: 16,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    marginTop: 6,
  },
  subtitle: {
    color: '#94A3B8',
    fontSize: 12,
    marginTop: 2,
  },
  ambientCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1E293B',
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 16,
  },
  ambientLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  ambientTitle: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
  },
  ambientDesc: {
    color: '#94A3B8',
    fontSize: 11,
  },
  tasbeehCard: {
    backgroundColor: '#064E3B20',
    borderRadius: 20,
    padding: 16,
    borderWidth: 1,
    borderColor: '#10B98140',
    alignItems: 'center',
    marginBottom: 20,
  },
  tasbeehHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  tasbeehTitle: {
    color: '#FFD700',
    fontSize: 14,
    fontWeight: '700',
  },
  tasbeehText: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 14,
  },
  counterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  resetBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0F172A',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  countTapBtn: {
    backgroundColor: '#059669',
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 24,
    alignItems: 'center',
  },
  countNumber: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: '900',
  },
  countLabel: {
    color: '#A7F3D0',
    fontSize: 10,
    fontWeight: '600',
  },
  sectionHeader: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
  },
  athkarCard: {
    backgroundColor: '#1E293B',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  athkarTitle: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 6,
  },
  athkarBody: {
    color: '#F8FAFC',
    fontSize: 15,
    lineHeight: 24,
    fontWeight: '600',
    marginBottom: 10,
  },
  rewardBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#0F172A',
    padding: 10,
    borderRadius: 10,
    marginBottom: 12,
  },
  rewardText: {
    color: '#CBD5E1',
    fontSize: 12,
    flex: 1,
  },
  playAudioBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#059669',
    paddingVertical: 10,
    borderRadius: 12,
  },
  playAudioBtnActive: {
    backgroundColor: '#DC2626',
  },
  playAudioBtnText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
  },
});
