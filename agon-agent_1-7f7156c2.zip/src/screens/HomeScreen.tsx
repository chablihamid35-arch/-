import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { HeaderBar } from '../components/HeaderBar';
import { PrayerCard } from '../components/PrayerCard';
import { AuthenticQuoteCard } from '../components/AuthenticQuoteCard';
import { CategoryChips } from '../components/CategoryChips';
import { ProblemSelectorModal } from '../components/ProblemSelectorModal';
import { useApp } from '../context/AppContext';

export const HomeScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { t, currentWisdom, nextHourlyWisdom, activeCategory, userBurdens, autoReplySmsEnabled, autoReplyText } = useApp();
  const [modalVisible, setModalVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = () => {
    setRefreshing(true);
    nextHourlyWisdom();
    setTimeout(() => setRefreshing(false), 600);
  };

  return (
    <View style={styles.container}>
      <HeaderBar />

      <ScrollView
        style={styles.scrollArea}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#10B981" />}
        showsVerticalScrollIndicator={false}
      >
        {/* Main Prayer Card */}
        <PrayerCard />

        {/* Input Problem Callout Banner */}
        <TouchableOpacity 
          style={styles.inputBanner} 
          onPress={() => setModalVisible(true)}
          activeOpacity={0.9}
        >
          <View style={styles.inputBannerIcon}>
            <Ionicons name="sparkles" size={24} color="#FFD700" />
          </View>
          <View style={styles.inputBannerText}>
            <Text style={styles.inputBannerTitle}>{t.enterBurdenTitle}</Text>
            <Text style={styles.inputBannerSubtitle}>انقر هنا لإدخال ما يرهقك والحصول على السكينة بالأدلة الصحيحة</Text>
          </View>
          <Ionicons name="chevron-back-sharp" size={20} color="#10B981" />
        </TouchableOpacity>

        {/* Quick Relief Button */}
        <View style={styles.quickReliefBox}>
          <TouchableOpacity 
            style={styles.quickReliefBtn}
            onPress={() => {
              nextHourlyWisdom();
            }}
          >
            <Ionicons name="flash-sharp" size={18} color="#FFD700" />
            <Text style={styles.quickReliefBtnText}>{t.quickPeaceShot}</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.supportNavBtn}
            onPress={() => navigation.navigate('Support')}
          >
            <Ionicons name="analytics-outline" size={18} color="#38BDF8" />
            <Text style={styles.supportNavBtnText}>تحديد جذور المشكلة</Text>
          </TouchableOpacity>
        </View>

        {/* Category Chips */}
        <CategoryChips />

        {/* Hourly Wisdom Stream Header */}
        <View style={styles.wisdomHeaderRow}>
          <View style={styles.wisdomHeaderLeft}>
            <Ionicons name="time-outline" size={20} color="#10B981" />
            <Text style={styles.wisdomSectionTitle}>{t.hourlyWisdomTitle}</Text>
          </View>

          <TouchableOpacity style={styles.nextWisdomBtn} onPress={nextHourlyWisdom}>
            <Text style={styles.nextWisdomText}>التالي</Text>
            <Ionicons name="refresh-sharp" size={16} color="#10B981" />
          </TouchableOpacity>
        </View>

        {/* Authentic Quote Card */}
        <AuthenticQuoteCard wisdom={currentWisdom} />

        {/* SMS Auto Reply Status Footer Notice */}
        {autoReplySmsEnabled && (
          <View style={styles.smsNoticeBox}>
            <Ionicons name="chatbox-ellipses-sharp" size={18} color="#10B981" />
            <Text style={styles.smsNoticeText}>
              رسالة "أنا في بيت الله" مجهّزة للإرسال التلقائي لأي متصل أثناء أوقات الصلاة.
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Problem Selector Modal */}
      <ProblemSelectorModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        onSubmitted={() => navigation.navigate('Support')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  scrollArea: {
    flex: 1,
  },
  inputBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#064E3B',
    marginHorizontal: 16,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#10B981',
    marginBottom: 12,
    gap: 12,
  },
  inputBannerIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputBannerText: {
    flex: 1,
  },
  inputBannerTitle: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '800',
  },
  inputBannerSubtitle: {
    color: '#A7F3D0',
    fontSize: 11,
    marginTop: 2,
  },
  quickReliefBox: {
    flexDirection: 'row',
    marginHorizontal: 16,
    gap: 10,
    marginBottom: 12,
  },
  quickReliefBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#78350F40',
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#F59E0B',
  },
  quickReliefBtnText: {
    color: '#FFD700',
    fontWeight: '700',
    fontSize: 13,
  },
  supportNavBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#0369A130',
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#0284C7',
  },
  supportNavBtnText: {
    color: '#38BDF8',
    fontWeight: '700',
    fontSize: 13,
  },
  wisdomHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 8,
    marginBottom: 10,
  },
  wisdomHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  wisdomSectionTitle: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '700',
  },
  nextWisdomBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#1E293B',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#334155',
  },
  nextWisdomText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
  smsNoticeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#1E293B',
    marginHorizontal: 16,
    marginBottom: 24,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  smsNoticeText: {
    color: '#94A3B8',
    fontSize: 12,
    flex: 1,
  },
});
