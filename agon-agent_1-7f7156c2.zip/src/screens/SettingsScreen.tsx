import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, TextInput, Alert, Modal, ActivityIndicator } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { HeaderBar } from '../components/HeaderBar';
import { useApp } from '../context/AppContext';
import { CITY_PRESETS } from '../data/prayerTimesData';

export const SettingsScreen: React.FC = () => {
  const { 
    language, 
    t, 
    selectedCountryCode, 
    setSelectedCountryCode, 
    autoMuteEnabled, 
    setAutoMuteEnabled, 
    autoReplySmsEnabled, 
    setAutoReplySmsEnabled, 
    autoReplyText, 
    setAutoReplyText,
    muteDurationMinutes,
    setMuteDurationMinutes,
    simulatedSmsLogs
  } = useApp();

  const [cityModalVisible, setCityModalVisible] = useState(false);
  const [editingReplyText, setEditingReplyText] = useState(autoReplyText);
  const [isLocating, setIsLocating] = useState(false);

  const handleSaveReplyText = () => {
    setAutoReplyText(editingReplyText);
    Alert.alert('تم الحفظ', 'تم تحديث نص الرد الآلي "أنا في بيت الله" بنجاح.');
  };

  const handleGpsDetect = () => {
    setIsLocating(true);
    setTimeout(() => {
      setIsLocating(false);
      const nearest = CITY_PRESETS[Math.floor(Math.random() * CITY_PRESETS.length)];
      setSelectedCountryCode(nearest.countryCode);
      Alert.alert(
        'تم تحديد الموقع بـ GPS',
        `تم تحديد موقعك الحالي بنجاح: (${nearest.cityName[language]} - ${nearest.countryName[language]}).\n${t.gpsDetectSuccess}`
      );
    }, 1000);
  };

  const selectedCityObj = CITY_PRESETS.find(c => c.countryCode === selectedCountryCode) || CITY_PRESETS[0];

  return (
    <View style={styles.container}>
      <HeaderBar />

      <ScrollView style={styles.scrollArea} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.headerBox}>
          <Ionicons name="settings-sharp" size={32} color="#10B981" />
          <Text style={styles.title}>{t.tabSettings}</Text>
          <Text style={styles.subtitle}>تخصيص الكتم الصوتي واللغات وتفاصيل التطبيق</Text>
        </View>

        {/* 1. Country & City Location + GPS */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>موقع أوقات الصلاة والـ GPS:</Text>

          <TouchableOpacity style={styles.gpsTriggerBtn} onPress={handleGpsDetect} disabled={isLocating}>
            {isLocating ? (
              <ActivityIndicator size="small" color="#FFF" />
            ) : (
              <Ionicons name="navigate-circle-sharp" size={20} color="#FFF" />
            )}
            <Text style={styles.gpsTriggerBtnText}>
              {isLocating ? 'جاري تحديد إحداثيات الموقع...' : t.gpsDetectBtn}
            </Text>
          </TouchableOpacity>

          <View style={styles.settingDivider} />

          <TouchableOpacity style={styles.settingRow} onPress={() => setCityModalVisible(true)}>
            <View style={styles.settingLeft}>
              <Ionicons name="location-sharp" size={20} color="#10B981" />
              <View>
                <Text style={styles.settingLabel}>{t.cityCountry}</Text>
                <Text style={styles.settingVal}>
                  {selectedCityObj.cityName[language]} - {selectedCityObj.countryName[language]}
                </Text>
              </View>
            </View>
            <Ionicons name="chevron-back-sharp" size={18} color="#94A3B8" />
          </TouchableOpacity>
        </View>

        {/* 2. Auto-Mute Engine Settings */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>إعدادات الكتم الصوتي عند الصلاة:</Text>

          <View style={styles.settingRow}>
            <View style={styles.settingLeft}>
              <Ionicons name="volume-mute-sharp" size={20} color="#10B981" />
              <View style={styles.settingTextFlex}>
                <Text style={styles.settingLabel}>{t.enableAutoMute}</Text>
                <Text style={styles.settingSubLabel}>يكتم الصوت تلقائياً عند رفع الأذان وطوال مدة الصلاة</Text>
              </View>
            </View>
            <Switch
              value={autoMuteEnabled}
              onValueChange={setAutoMuteEnabled}
              trackColor={{ false: '#334155', true: '#059669' }}
              thumbColor={autoMuteEnabled ? '#10B981' : '#94A3B8'}
            />
          </View>

          <View style={styles.settingDivider} />

          {/* Mute Duration Duration Options */}
          <Text style={styles.settingLabelMargin}>{t.muteDurationText}:</Text>
          <View style={styles.durationRow}>
            {[15, 20, 30, 45].map((mins) => (
              <TouchableOpacity
                key={mins}
                style={[styles.durBtn, muteDurationMinutes === mins && styles.durBtnActive]}
                onPress={() => setMuteDurationMinutes(mins)}
              >
                <Text style={[styles.durBtnText, muteDurationMinutes === mins && styles.durBtnTextActive]}>
                  {mins} دقيقة
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 3. SMS Auto Reply Settings ("أنا في بيت الله") */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>إرسال رسالة "أنا في بيت الله" التلقائية:</Text>

          <View style={styles.settingRow}>
            <View style={styles.settingLeft}>
              <Ionicons name="chatbox-sharp" size={20} color="#38BDF8" />
              <View style={styles.settingTextFlex}>
                <Text style={styles.settingLabel}>{t.smsAutoReplyTitle}</Text>
                <Text style={styles.settingSubLabel}>{t.smsAutoReplyDesc}</Text>
              </View>
            </View>
            <Switch
              value={autoReplySmsEnabled}
              onValueChange={setAutoReplySmsEnabled}
              trackColor={{ false: '#334155', true: '#0284C7' }}
              thumbColor={autoReplySmsEnabled ? '#38BDF8' : '#94A3B8'}
            />
          </View>

          <View style={styles.settingDivider} />

          <Text style={styles.settingLabelMargin}>نص الرسالة التلقائية:</Text>
          <TextInput
            style={styles.smsInput}
            value={editingReplyText}
            onChangeText={setEditingReplyText}
            multiline
            numberOfLines={2}
          />

          <TouchableOpacity style={styles.saveSmsBtn} onPress={handleSaveReplyText}>
            <Ionicons name="save-outline" size={16} color="#FFF" />
            <Text style={styles.saveSmsBtnText}>{t.save}</Text>
          </TouchableOpacity>
        </View>

        {/* 4. Simulated SMS Logs */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>سجل الرسائل التلقائية المرسلة أثناء الصلاة:</Text>

          {simulatedSmsLogs.map((log) => (
            <View key={log.id} style={styles.logCard}>
              <View style={styles.logHeader}>
                <Text style={styles.logPhone}>{log.phone}</Text>
                <Text style={styles.logTime}>{log.time}</Text>
              </View>
              <Text style={styles.logText}>"{log.text}"</Text>
            </View>
          ))}
        </View>

        {/* 5. Sunni Authenticity Seal Guarantee */}
        <View style={styles.guaranteeBanner}>
          <Ionicons name="shield-checkmark-sharp" size={28} color="#FFD700" />
          <View style={styles.guaranteeTextFlex}>
            <Text style={styles.guaranteeTitle}>تعهد وصحة المصادر</Text>
            <Text style={styles.guaranteeDesc}>
              {t.sunniAuthenticityGuarantee}
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* City Selector Modal */}
      <Modal
        visible={cityModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setCityModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>اختر البلد والمدينة لأوقات الصلاة</Text>
              <TouchableOpacity onPress={() => setCityModalVisible(false)}>
                <Ionicons name="close" size={20} color="#94A3B8" />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.cityList}>
              {CITY_PRESETS.map((city) => (
                <TouchableOpacity
                  key={city.countryCode}
                  style={[styles.cityItem, selectedCountryCode === city.countryCode && styles.cityItemActive]}
                  onPress={() => {
                    setSelectedCountryCode(city.countryCode);
                    setCityModalVisible(false);
                  }}
                >
                  <Ionicons name="location-outline" size={18} color={selectedCountryCode === city.countryCode ? "#10B981" : "#94A3B8"} />
                  <Text style={[styles.cityText, selectedCountryCode === city.countryCode && styles.cityTextActive]}>
                    {city.cityName[language]} - {city.countryName[language]}
                  </Text>
                  {selectedCountryCode === city.countryCode && (
                    <Ionicons name="checkmark-circle" size={18} color="#10B981" />
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  scrollArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  headerBox: {
    alignItems: 'center',
    marginVertical: 16,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    marginTop: 6,
  },
  subtitle: {
    color: '#94A3B8',
    fontSize: 12,
    marginTop: 2,
  },
  sectionCard: {
    backgroundColor: '#1E293B',
    borderRadius: 18,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  sectionTitle: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
  },
  gpsTriggerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#059669',
    paddingVertical: 12,
    borderRadius: 12,
  },
  gpsTriggerBtnText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  settingTextFlex: {
    flex: 1,
  },
  settingLabel: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '600',
  },
  settingSubLabel: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 2,
  },
  settingVal: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 2,
  },
  settingDivider: {
    height: 1,
    backgroundColor: '#334155',
    marginVertical: 12,
  },
  settingLabelMargin: {
    color: '#CBD5E1',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  durationRow: {
    flexDirection: 'row',
    gap: 8,
  },
  durBtn: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#0F172A',
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#334155',
  },
  durBtnActive: {
    backgroundColor: '#059669',
    borderColor: '#10B981',
  },
  durBtnText: {
    color: '#CBD5E1',
    fontSize: 12,
    fontWeight: '600',
  },
  durBtnTextActive: {
    color: '#FFF',
    fontWeight: '800',
  },
  smsInput: {
    backgroundColor: '#0F172A',
    borderRadius: 12,
    padding: 10,
    color: '#F8FAFC',
    fontSize: 12,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 10,
  },
  saveSmsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#0284C7',
    paddingVertical: 10,
    borderRadius: 10,
  },
  saveSmsBtnText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
  },
  logCard: {
    backgroundColor: '#0F172A',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#334155',
  },
  logHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  logPhone: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
  logTime: {
    color: '#64748B',
    fontSize: 11,
  },
  logText: {
    color: '#CBD5E1',
    fontSize: 12,
  },
  guaranteeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#78350F20',
    padding: 16,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#F59E0B40',
    marginBottom: 30,
  },
  guaranteeTextFlex: {
    flex: 1,
  },
  guaranteeTitle: {
    color: '#FFD700',
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 4,
  },
  guaranteeDesc: {
    color: '#FEF3C7',
    fontSize: 12,
    lineHeight: 18,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalBox: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    width: '100%',
    maxHeight: 380,
    padding: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
    paddingBottom: 10,
  },
  modalTitle: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
  },
  cityList: {
    flex: 1,
  },
  cityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 10,
    marginBottom: 4,
    backgroundColor: '#0F172A',
  },
  cityItemActive: {
    backgroundColor: '#064E3B',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  cityText: {
    color: '#CBD5E1',
    fontSize: 13,
    flex: 1,
  },
  cityTextActive: {
    color: '#FFF',
    fontWeight: '700',
  },
});