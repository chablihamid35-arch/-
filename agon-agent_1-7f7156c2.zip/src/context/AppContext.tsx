import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Language, HardshipCategory, CommunityDua, UserBurden, AppSettings, AuthenticWisdom } from '../types';
import { translations, TranslationDictionary } from '../data/translations';
import { AUTHENTIC_DATABASE } from '../data/authenticDatabase';
import { CITY_PRESETS, getPrayerTimesForCity, getNextPrayer } from '../data/prayerTimesData';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: TranslationDictionary;
  
  // Prayer & Mute
  selectedCountryCode: string;
  setSelectedCountryCode: (code: string) => void;
  autoMuteEnabled: boolean;
  setAutoMuteEnabled: (enabled: boolean) => void;
  manualSilentMode: boolean;
  setManualSilentMode: (silent: boolean) => void;
  autoReplySmsEnabled: boolean;
  setAutoReplySmsEnabled: (enabled: boolean) => void;
  autoReplyText: string;
  setAutoReplyText: (text: string) => void;
  simulatedSmsLogs: { id: string; phone: string; time: string; text: string }[];
  addSimulatedSmsLog: (phone: string) => void;
  muteDurationMinutes: number;
  setMuteDurationMinutes: (duration: number) => void;
  
  // Psychological Support Engine
  activeCategory: HardshipCategory;
  setActiveCategory: (cat: HardshipCategory) => void;
  currentWisdomIndex: number;
  nextHourlyWisdom: () => void;
  currentWisdom: AuthenticWisdom;
  userBurdens: UserBurden[];
  addUserBurden: (text: string, category?: HardshipCategory) => UserBurden;
  activeUserBurden: UserBurden | null;
  
  // Community Duas
  communityDuas: CommunityDua[];
  togglePrayedForDua: (duaId: string) => void;
  addCommunityDua: (text: string, category: HardshipCategory) => void;
  
  // Bookmarks
  bookmarkedIds: string[];
  toggleBookmark: (id: string) => void;
  
  // Audio state
  playingAudioId: string | null;
  setPlayingAudioId: (id: string | null) => void;
  ambientSound: boolean;
  setAmbientSound: (enabled: boolean) => void;
}

const INITIAL_SETTINGS: AppSettings = {
  language: 'ar',
  selectedCountry: 'SA',
  selectedCity: 'مكة المكرمة',
  autoMuteEnabled: true,
  muteDurationMinutes: 20,
  autoReplySmsEnabled: true,
  autoReplyText: 'أنا في بيت الله - أؤدي الصلاة حالياً وسأتصل بك لاحقاً إن شاء الله',
  hourlyWisdomEnabled: true,
  ambientSoundEnabled: false,
  calculationMethod: 'MWL'
};

const INITIAL_COMMUNITY_DUAS: CommunityDua[] = [
  {
    id: 'dua_1',
    authorAlias: 'أبو عبد الله',
    country: 'المملكة العربية السعودية',
    timeAgo: 'منذ 10 دقائق',
    category: 'anxiety_stress',
    text: 'أسألكم الدعاء بظهر الغيب لشفاء والدتي ورفع الهم والقلق عن عائلتنا.',
    prayedCount: 142,
    hasUserPrayed: false,
    repliesCount: 18,
  },
  {
    id: 'dua_2',
    authorAlias: 'أختكم في الله',
    country: 'جمهورية مصر العربية',
    timeAgo: 'منذ 25 دقيقة',
    category: 'waswas_overthinking',
    text: 'أعاني من وسواس وتشتت في أفكاري يرهقني كثيراً، ادعوا الله لي بالسكينة والطمأنينة.',
    prayedCount: 89,
    hasUserPrayed: false,
    repliesCount: 12,
  },
  {
    id: 'dua_3',
    authorAlias: 'عبد الرحمن',
    country: 'الجزائر',
    timeAgo: 'منذ ساعة',
    category: 'debt_poverty',
    text: 'ادعوا لي بالرزق وتيسير قضاء الدين والفرج العاجل.',
    prayedCount: 205,
    hasUserPrayed: false,
    repliesCount: 31,
  },
  {
    id: 'dua_4',
    authorAlias: 'مؤمن في حاجتكم',
    country: 'المغرب',
    timeAgo: 'منذ ساعتين',
    category: 'fear_future',
    text: 'أمر بظروف قاسية وخوف شديد من المستقبل، نسأل الله الثبات والسلام الداخلي.',
    prayedCount: 167,
    hasUserPrayed: false,
    repliesCount: 24,
  }
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('ar');
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('SA');
  const [autoMuteEnabled, setAutoMuteEnabled] = useState<boolean>(true);
  const [manualSilentMode, setManualSilentMode] = useState<boolean>(false);
  const [autoReplySmsEnabled, setAutoReplySmsEnabled] = useState<boolean>(true);
  const [autoReplyText, setAutoReplyText] = useState<string>('أنا في بيت الله - أؤدي الصلاة حالياً وسأتصل بك لاحقاً إن شاء الله');
  const [muteDurationMinutes, setMuteDurationMinutes] = useState<number>(20);
  const [ambientSound, setAmbientSound] = useState<boolean>(false);
  
  const [simulatedSmsLogs, setSimulatedSmsLogs] = useState<{ id: string; phone: string; time: string; text: string }[]>([
    {
      id: 'log_1',
      phone: '+966 50 123 4567',
      time: 'قبل 15 دقيقة (أثناء صلاة الظهر)',
      text: 'أنا في بيت الله - أؤدي الصلاة حالياً وسأتصل بك لاحقاً إن شاء الله'
    }
  ]);

  const [activeCategory, setActiveCategory] = useState<HardshipCategory>('anxiety_stress');
  const [currentWisdomIndex, setCurrentWisdomIndex] = useState<number>(0);
  const [userBurdens, setUserBurdens] = useState<UserBurden[]>([]);
  const [activeUserBurden, setActiveUserBurden] = useState<UserBurden | null>(null);
  
  const [communityDuas, setCommunityDuas] = useState<CommunityDua[]>(INITIAL_COMMUNITY_DUAS);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);

  // Load preferences from AsyncStorage
  useEffect(() => {
    (async () => {
      try {
        const savedLang = await AsyncStorage.getItem('app_lang');
        if (savedLang) setLanguageState(savedLang as Language);

        const savedCountry = await AsyncStorage.getItem('app_country');
        if (savedCountry) setSelectedCountryCode(savedCountry);

        const savedAutoMute = await AsyncStorage.getItem('app_automute');
        if (savedAutoMute !== null) setAutoMuteEnabled(savedAutoMute === 'true');

        const savedBurdens = await AsyncStorage.getItem('app_burdens');
        if (savedBurdens) setUserBurdens(JSON.parse(savedBurdens));

        const savedBookmarks = await AsyncStorage.getItem('app_bookmarks');
        if (savedBookmarks) setBookmarkedIds(JSON.parse(savedBookmarks));
      } catch (e) {
        console.error('Failed loading storage settings', e);
      }
    })();
  }, []);

  const setLanguage = async (lang: Language) => {
    setLanguageState(lang);
    try {
      await AsyncStorage.setItem('app_lang', lang);
    } catch (e) {
      console.error(e);
    }
  };

  const filteredWisdoms = AUTHENTIC_DATABASE.filter(w => w.category === activeCategory);
  const currentWisdom = filteredWisdoms.length > 0 
    ? filteredWisdoms[currentWisdomIndex % filteredWisdoms.length]
    : AUTHENTIC_DATABASE[0];

  const nextHourlyWisdom = () => {
    setCurrentWisdomIndex(prev => prev + 1);
  };

  const addUserBurden = (text: string, category: HardshipCategory = activeCategory): UserBurden => {
    const newBurden: UserBurden = {
      id: `burden_${Date.now()}`,
      date: new Date().toLocaleDateString('ar-SA'),
      category,
      userInputText: text,
      status: 'active'
    };
    const updated = [newBurden, ...userBurdens];
    setUserBurdens(updated);
    setActiveUserBurden(newBurden);
    AsyncStorage.setItem('app_burdens', JSON.stringify(updated)).catch(() => {});
    return newBurden;
  };

  const addSimulatedSmsLog = (phone: string) => {
    const newLog = {
      id: `sms_${Date.now()}`,
      phone,
      time: 'الآن (تلقائي خلال الصلاة)',
      text: autoReplyText
    };
    setSimulatedSmsLogs(prev => [newLog, ...prev]);
  };

  const togglePrayedForDua = (duaId: string) => {
    setCommunityDuas(prev => prev.map(dua => {
      if (dua.id === duaId) {
        const hasPrayed = !dua.hasUserPrayed;
        return {
          ...dua,
          hasUserPrayed: hasPrayed,
          prayedCount: hasPrayed ? dua.prayedCount + 1 : dua.prayedCount - 1
        };
      }
      return dua;
    }));
  };

  const addCommunityDua = (text: string, category: HardshipCategory) => {
    const newDua: CommunityDua = {
      id: `dua_${Date.now()}`,
      authorAlias: 'مؤمن متضامن',
      country: CITY_PRESETS.find(c => c.countryCode === selectedCountryCode)?.countryName[language] || 'العالم الإسلامي',
      timeAgo: 'الآن',
      category,
      text,
      prayedCount: 1,
      hasUserPrayed: true,
      repliesCount: 0
    };
    setCommunityDuas(prev => [newDua, ...prev]);
  };

  const toggleBookmark = (id: string) => {
    let updated: string[];
    if (bookmarkedIds.includes(id)) {
      updated = bookmarkedIds.filter(bId => bId !== id);
    } else {
      updated = [...bookmarkedIds, id];
    }
    setBookmarkedIds(updated);
    AsyncStorage.setItem('app_bookmarks', JSON.stringify(updated)).catch(() => {});
  };

  const t = translations[language] || translations.ar;

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        selectedCountryCode,
        setSelectedCountryCode,
        autoMuteEnabled,
        setAutoMuteEnabled,
        manualSilentMode,
        setManualSilentMode,
        autoReplySmsEnabled,
        setAutoReplySmsEnabled,
        autoReplyText,
        setAutoReplyText,
        simulatedSmsLogs,
        addSimulatedSmsLog,
        muteDurationMinutes,
        setMuteDurationMinutes,
        activeCategory,
        setActiveCategory,
        currentWisdomIndex,
        nextHourlyWisdom,
        currentWisdom,
        userBurdens,
        addUserBurden,
        activeUserBurden,
        communityDuas,
        togglePrayedForDua,
        addCommunityDua,
        bookmarkedIds,
        toggleBookmark,
        playingAudioId,
        setPlayingAudioId,
        ambientSound,
        setAmbientSound
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
