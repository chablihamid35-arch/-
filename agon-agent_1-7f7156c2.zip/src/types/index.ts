export type Language = 'ar' | 'en' | 'fr' | 'ur' | 'tr' | 'id';

export type HardshipCategory = 
  | 'anxiety_stress'
  | 'waswas_overthinking'
  | 'sadness_grief'
  | 'debt_poverty'
  | 'anger_conflict'
  | 'fear_future'
  | 'sin_guilt'
  | 'loneliness'
  | 'illness_pain';

export type SourceType = 'quran' | 'hadith_sahih' | 'sahaba' | 'tabi' | 'imam_sunnah';

export interface AuthenticWisdom {
  id: string;
  category: HardshipCategory;
  type: SourceType;
  arabicText: string;
  translation: Record<Language, string>;
  source: string; // e.g., "صحيح البخاري - 6363" or "سورة الشرح: 5-6" or "جامع العلوم والحكم لابن رجب"
  narratorOrAuthor: string; // e.g., "رسول الله ﷺ", "أبو بكر الصديق", "الحسن البصري", "الإمام الشافعي"
  psychologicalContext: Record<Language, string>; // Gentle emotional support explanation
  diagnosticQuestion?: Record<Language, string>; // Gentle diagnostic question to help identify cause
}

export interface PrayerTime {
  name: string;
  key: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
  time: string; // "05:15"
  isNext?: boolean;
}

export interface CountryCity {
  countryCode: string;
  countryName: Record<Language, string>;
  cityName: Record<Language, string>;
  latitude: number;
  longitude: number;
  timezone: string;
}

export interface CommunityDua {
  id: string;
  authorAlias: string;
  country: string;
  timeAgo: string;
  category: HardshipCategory;
  text: string;
  prayedCount: number;
  hasUserPrayed?: boolean;
  repliesCount: number;
}

export interface UserBurden {
  id: string;
  date: string;
  category: HardshipCategory;
  userInputText: string;
  identifiedIssue?: string;
  selectedWisdomId?: string;
  status: 'active' | 'resolved';
}

export interface AppSettings {
  language: Language;
  selectedCountry: string;
  selectedCity: string;
  autoMuteEnabled: boolean;
  muteDurationMinutes: number; // e.g. 20 mins after Adhan
  autoReplySmsEnabled: boolean;
  autoReplyText: string;
  hourlyWisdomEnabled: boolean;
  ambientSoundEnabled: boolean;
  calculationMethod: string;
}
