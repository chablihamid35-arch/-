import React from 'react';
import { ScrollView, TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { HardshipCategory } from '../types';
import { useApp } from '../context/AppContext';

interface CategoryItem {
  id: HardshipCategory;
  titleKey: keyof typeof import('../data/translations').translations.ar;
  iconName: keyof typeof Ionicons.glyphMap;
}

const CATEGORIES: CategoryItem[] = [
  { id: 'anxiety_stress', titleKey: 'catAnxiety', iconName: 'leaf-outline' },
  { id: 'waswas_overthinking', titleKey: 'catWaswas', iconName: 'headset-outline' },
  { id: 'sadness_grief', titleKey: 'catSadness', iconName: 'cloud-outline' },
  { id: 'debt_poverty', titleKey: 'catDebt', iconName: 'wallet-outline' },
  { id: 'anger_conflict', titleKey: 'catAnger', iconName: 'flame-outline' },
  { id: 'fear_future', titleKey: 'catFear', iconName: 'compass-outline' },
  { id: 'sin_guilt', titleKey: 'catSin', iconName: 'water-outline' },
  { id: 'loneliness', titleKey: 'catLoneliness', iconName: 'person-outline' },
  { id: 'illness_pain', titleKey: 'catIllness', iconName: 'fitness-outline' },
];

export const CategoryChips: React.FC = () => {
  const { activeCategory, setActiveCategory, t } = useApp();

  return (
    <View style={styles.wrapper}>
      <Text style={styles.sectionHeader}>{t.selectHardshipCategory}</Text>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
      >
        {CATEGORIES.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <TouchableOpacity
              key={cat.id}
              style={[styles.chip, isActive && styles.chipActive]}
              onPress={() => setActiveCategory(cat.id)}
              activeOpacity={0.8}
            >
              <Ionicons 
                name={cat.iconName} 
                size={16} 
                color={isActive ? "#FFF" : "#94A3B8"} 
              />
              <Text style={[styles.chipText, isActive && styles.chipTextActive]}>
                {t[cat.titleKey]}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    marginVertical: 8,
  },
  sectionHeader: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  scrollContainer: {
    paddingHorizontal: 16,
    gap: 8,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#1E293B',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#334155',
  },
  chipActive: {
    backgroundColor: '#059669',
    borderColor: '#10B981',
  },
  chipText: {
    color: '#CBD5E1',
    fontSize: 13,
    fontWeight: '600',
  },
  chipTextActive: {
    color: '#FFF',
    fontWeight: '700',
  },
});
