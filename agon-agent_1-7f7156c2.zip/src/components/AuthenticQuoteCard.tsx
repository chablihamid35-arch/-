import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Share, Alert } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { AuthenticWisdom } from '../types';
import { useApp } from '../context/AppContext';

interface Props {
  wisdom: AuthenticWisdom;
  onSelectCategory?: () => void;
}

export const AuthenticQuoteCard: React.FC<Props> = ({ wisdom, onSelectCategory }) => {
  const { language, t, bookmarkedIds, toggleBookmark, playingAudioId, setPlayingAudioId } = useApp();
  const [copied, setCopied] = useState(false);

  const isBookmarked = bookmarkedIds.includes(wisdom.id);
  const isPlaying = playingAudioId === wisdom.id;

  const handleShare = async () => {
    try {
      const shareText = `"${wisdom.arabicText}"\n\n📌 المصدر: ${wisdom.source}\n👤 القائل: ${wisdom.narratorOrAuthor}\n\n— مشارك من تطبيق (مبعد الشيطان) للسكينة والدعم النفسي من صحيح السنة`;
      await Share.share({ message: shareText });
    } catch (e) {
      console.error(e);
    }
  };

  const handleAudioToggle = () => {
    if (isPlaying) {
      setPlayingAudioId(null);
    } else {
      setPlayingAudioId(wisdom.id);
    }
  };

  const getSourceBadgeColor = (type: string) => {
    switch (type) {
      case 'quran': return '#059669'; // Green
      case 'hadith_sahih': return '#2563EB'; // Blue
      case 'sahaba': return '#7C3AED'; // Purple
      case 'tabi': return '#D97706'; // Amber
      case 'imam_sunnah': return '#DC2626'; // Rose
      default: return '#059669';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'quran': return 'القرآن الكريم (كلام الله)';
      case 'hadith_sahih': return 'حديث صحيح ثابِت';
      case 'sahaba': return 'قول صحابي جليل';
      case 'tabi': return 'قول تابعي جليل';
      case 'imam_sunnah': return 'إمام من أهل السنة والجماعة';
      default: return 'سنة صحيحة';
    }
  };

  return (
    <View style={styles.cardContainer}>
      {/* Type & Verification Badge */}
      <View style={styles.badgeHeader}>
        <View style={[styles.typeBadge, { backgroundColor: getSourceBadgeColor(wisdom.type) }]}>
          <Ionicons name="checkmark-seal-sharp" size={14} color="#FFF" />
          <Text style={styles.typeBadgeText}>{getTypeLabel(wisdom.type)}</Text>
        </View>

        <TouchableOpacity 
          style={styles.bookmarkBtn} 
          onPress={() => toggleBookmark(wisdom.id)}
        >
          <Ionicons 
            name={isBookmarked ? "bookmark" : "bookmark-outline"} 
            size={22} 
            color={isBookmarked ? "#FFD700" : "#94A3B8"} 
          />
        </TouchableOpacity>
      </View>

      {/* Main Arabic Text */}
      <View style={styles.arabicBox}>
        <Text style={styles.arabicText}>«{wisdom.arabicText}»</Text>
      </View>

      {/* Translation if not Arabic */}
      {language !== 'ar' && (
        <View style={styles.translationBox}>
          <Text style={styles.translationText}>{wisdom.translation[language]}</Text>
        </View>
      )}

      {/* Citation Metadata */}
      <View style={styles.citationRow}>
        <View style={styles.citationItem}>
          <Ionicons name="book-outline" size={14} color="#10B981" />
          <Text style={styles.citationText}><Text style={styles.boldLabel}>{t.sourceLabel}:</Text> {wisdom.source}</Text>
        </View>
        <View style={styles.citationItem}>
          <Ionicons name="person-outline" size={14} color="#38BDF8" />
          <Text style={styles.citationText}><Text style={styles.boldLabel}>{t.narratorLabel}:</Text> {wisdom.narratorOrAuthor}</Text>
        </View>
      </View>

      {/* Psychological Comfort & Context */}
      <View style={styles.psychBox}>
        <View style={styles.psychHeader}>
          <Ionicons name="heart-circle-outline" size={20} color="#10B981" />
          <Text style={styles.psychTitle}>السكينة والدعم النفسي:</Text>
        </View>
        <Text style={styles.psychText}>{wisdom.psychologicalContext[language] || wisdom.psychologicalContext.ar}</Text>
      </View>

      {/* Diagnostic Question */}
      {wisdom.diagnosticQuestion && (
        <View style={styles.questionBox}>
          <View style={styles.questionHeader}>
            <Ionicons name="help-circle-outline" size={18} color="#FFD700" />
            <Text style={styles.questionTitle}>{t.gentleQuestionTitle}</Text>
          </View>
          <Text style={styles.questionText}>{wisdom.diagnosticQuestion[language] || wisdom.diagnosticQuestion.ar}</Text>
        </View>
      )}

      {/* Card Actions Footer */}
      <View style={styles.actionFooter}>
        <TouchableOpacity 
          style={[styles.audioPlayBtn, isPlaying && styles.audioPlayBtnActive]} 
          onPress={handleAudioToggle}
        >
          <Ionicons name={isPlaying ? "pause" : "volume-medium"} size={18} color="#FFF" />
          <Text style={styles.audioPlayText}>
            {isPlaying ? 'إيقاف التلاوة' : 'الاستماع بالصوت'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
          <Ionicons name="share-social-outline" size={18} color="#CBD5E1" />
          <Text style={styles.shareText}>{t.share}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  cardContainer: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 18,
    marginHorizontal: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  badgeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  typeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  typeBadgeText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '700',
  },
  bookmarkBtn: {
    padding: 4,
  },
  arabicBox: {
    backgroundColor: '#0F172A',
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 12,
  },
  arabicText: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '700',
    textAlign: 'center',
    lineHeight: 34,
    fontFamily: 'System',
  },
  translationBox: {
    backgroundColor: '#1E293B',
    padding: 12,
    borderRadius: 12,
    marginBottom: 12,
    borderLeftWidth: 3,
    borderLeftColor: '#10B981',
  },
  translationText: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 22,
    fontStyle: 'italic',
  },
  citationRow: {
    gap: 6,
    marginBottom: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  citationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  boldLabel: {
    fontWeight: '700',
    color: '#94A3B8',
  },
  citationText: {
    color: '#CBD5E1',
    fontSize: 13,
  },
  psychBox: {
    backgroundColor: '#064E3B20',
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#10B98140',
    marginBottom: 10,
  },
  psychHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  psychTitle: {
    color: '#10B981',
    fontWeight: '700',
    fontSize: 13,
  },
  psychText: {
    color: '#E2E8F0',
    fontSize: 13,
    lineHeight: 21,
  },
  questionBox: {
    backgroundColor: '#78350F20',
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#F59E0B40',
    marginBottom: 14,
  },
  questionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  questionTitle: {
    color: '#FFD700',
    fontWeight: '700',
    fontSize: 13,
  },
  questionText: {
    color: '#FEF3C7',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 20,
  },
  actionFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 10,
    marginTop: 4,
  },
  audioPlayBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#059669',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
    flex: 1,
    justifyContent: 'center',
  },
  audioPlayBtnActive: {
    backgroundColor: '#DC2626',
  },
  audioPlayText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
  },
  shareBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#0F172A',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  shareText: {
    color: '#CBD5E1',
    fontSize: 13,
    fontWeight: '600',
  },
});
