import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../context/AppContext';
import { HardshipCategory } from '../types';

interface Props {
  visible: boolean;
  onClose: () => void;
  onSubmitted?: () => void;
}

export const ProblemSelectorModal: React.FC<Props> = ({ visible, onClose, onSubmitted }) => {
  const { t, addUserBurden, setActiveCategory, activeCategory } = useApp();
  const [inputText, setInputText] = useState('');
  const [selectedCat, setSelectedCat] = useState<HardshipCategory>(activeCategory);

  const handleSubmit = () => {
    if (!inputText.trim()) {
      Alert.alert('تنبيه', 'يرجى كتابة ما يجهدك بكلماتك أو اختيار الفئة لتقديم الدعم الفوري.');
      return;
    }

    addUserBurden(inputText.trim(), selectedCat);
    setActiveCategory(selectedCat);
    setInputText('');
    onClose();
    if (onSubmitted) onSubmitted();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <View style={styles.titleBox}>
              <Ionicons name="chatbubbles-outline" size={24} color="#10B981" />
              <Text style={styles.title}>{t.enterBurdenTitle}</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Ionicons name="close" size={20} color="#94A3B8" />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            <Text style={styles.subtitle}>{t.enterBurdenSubtitle}</Text>

            <TextInput
              style={styles.textInput}
              placeholder={t.enterBurdenPlaceholder}
              placeholderTextColor="#64748B"
              multiline
              numberOfLines={4}
              value={inputText}
              onChangeText={setInputText}
              textAlignVertical="top"
            />

            <View style={styles.guaranteeBox}>
              <Ionicons name="shield-checkmark" size={18} color="#FFD700" />
              <Text style={styles.guaranteeText}>{t.sunniAuthenticityGuarantee}</Text>
            </View>

            <TouchableOpacity style={styles.submitBtn} onPress={handleSubmit}>
              <Ionicons name="sparkles" size={20} color="#FFF" />
              <Text style={styles.submitBtnText}>{t.analyzeBurdenBtn}</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#1E293B',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    maxHeight: '85%',
    borderWidth: 1,
    borderColor: '#334155',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
    paddingBottom: 12,
  },
  titleBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    flex: 1,
  },
  closeBtn: {
    padding: 4,
    backgroundColor: '#0F172A',
    borderRadius: 12,
  },
  subtitle: {
    color: '#CBD5E1',
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 14,
  },
  textInput: {
    backgroundColor: '#0F172A',
    borderRadius: 16,
    padding: 14,
    color: '#F8FAFC',
    fontSize: 14,
    minHeight: 110,
    borderWidth: 1,
    borderColor: '#334155',
    marginBottom: 14,
  },
  guaranteeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#78350F20',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#F59E0B40',
    marginBottom: 16,
  },
  guaranteeText: {
    color: '#FEF3C7',
    fontSize: 12,
    flex: 1,
    fontWeight: '500',
  },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#059669',
    paddingVertical: 14,
    borderRadius: 16,
    gap: 8,
  },
  submitBtnText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '800',
  },
});
