import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Switch, Alert, ActivityIndicator } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../context/AppContext';
import { CITY_PRESETS, getPrayerTimesForCity, getNextPrayer, getQiblaAngle } from '../data/prayerTimesData';

export const PrayerCard: React.FC<{ onOpenQibla?: () => void }> = ({ onOpenQibla }) => {
  const { 
    selectedCountryCode,
    setSelectedCountryCode,
    autoMuteEnabled, 
    setAutoMuteEnabled, 
    autoReplySmsEnabled,
    autoReplyText,
    t, 
    language,
    manualSilentMode,
    setManualSilentMode
  } = useApp();

  const [prayerTimes, setPrayerTimes] = useState(getPrayerTimesForCity(selectedCountryCode));
  const [nextInfo, setNextInfo] = useState(getNextPrayer(prayerTimes));
  const [isLocating, setIsLocating] = useState(false);

  const cityObj = CITY_PRESETS.find(c => c.countryCode === selectedCountryCode) || CITY_PRESETS[0];

  useEffect(() => {
    const times = getPrayerTimesForCity(selectedCountryCode);
    setPrayerTimes(times);
    setNextInfo(getNextPrayer(times));

    const interval = setInterval(() => {
      setNextInfo(getNextPrayer(times));
    }, 1000);

    return () => clearInterval(interval);
  }, [selectedCountryCode]);

  const handleGpsDetect = () => {
    setIsLocating(true);
    setTimeout(() => {
      setIsLocating(false);
      // Automatically selects local city preset based on simulation/GPS
      const nearest = CITY_PRESETS[Math.floor(Math.random() * CITY_PRESETS.length)];
      setSelectedCountryCode(nearest.countryCode);
      Alert.alert(
        'تم تحديد الموقع بـ GPS',
        `تم تحديد موقعك الحالي: (${nearest.cityName[language]} - ${nearest.countryName[language]}).\n${t.gpsDetectSuccess}`
      );
    }, 1200);
  };

  const qiblaAngle = Math.round(getQiblaAngle(cityObj.latitude, cityObj.longitude));

  return (
    <View style={styles.cardContainer}>
      {/* Top Bar inside Card */}
      <View style={styles.cardHeader}>
        <View style={styles.locationTag}>
          <Ionicons name="location-sharp" size={16} color="#10B981" />
          <Text style={styles.locationText}>
            {cityObj.cityName[language]} - {cityObj.countryName[language]}
          </Text>
        </View>

        <TouchableOpacity 
          style={styles.gpsBtn} 
          onPress={handleGpsDetect}
          disabled={isLocating}
        >
          {isLocating ? (
            <ActivityIndicator size="small" color="#10B981" />
          ) : (
            <Ionicons name="navigate-circle-sharp" size={16} color="#10B981" />
          )}
          <Text style={styles.gpsBtnText}>{isLocating ? 'جاري التحديد...' : t.gpsDetectBtn}</Text>
        </TouchableOpacity>
      </View>

      {/* Main Countdown View */}
      <View style={styles.countdownSection}>
        <Text style={styles.nextPrayerLabel}>{t.nextPrayer}: <Text style={styles.prayerNameHighlight}>{nextInfo.nextPrayer.name}</Text></Text>
        <Text style={styles.timeRemainingText}>{nextInfo.timeRemaining}</Text>
        <Text style={styles.prayerTimeTarget}>موعد الأذان: {nextInfo.nextPrayer.time}</Text>
      </View>

      {/* Auto-Mute Live Banner */}
      <View style={[styles.muteStatusBanner, (manualSilentMode || nextInfo.isMuteWindowActive) ? styles.bannerMuted : styles.bannerNormal]}>
        <View style={styles.bannerIconBox}>
          <Ionicons 
            name={(manualSilentMode || nextInfo.isMuteWindowActive) ? "volume-mute" : "volume-high"} 
            size={22} 
            color={(manualSilentMode || nextInfo.isMuteWindowActive) ? "#FFD700" : "#10B981"} 
          />
        </View>
        <View style={styles.bannerTextBox}>
          <Text style={styles.bannerTitle}>
            {(manualSilentMode || nextInfo.isMuteWindowActive) ? t.muteStatusActive : t.muteStatusInactive}
          </Text>
          <Text style={styles.bannerSubtitle}>
            {autoReplySmsEnabled ? `الرد الآلي مفعل: "${autoReplyText.substring(0, 28)}..."` : 'يمكنك تفعيل الرد الآلي في أوقات الصلاة'}
          </Text>
        </View>
      </View>

      {/* Quick Settings Bar inside Card */}
      <View style={styles.controlsRow}>
        <View style={styles.toggleItem}>
          <Text style={styles.toggleLabel}>{t.enableAutoMute}</Text>
          <Switch
            value={autoMuteEnabled}
            onValueChange={setAutoMuteEnabled}
            trackColor={{ false: '#334155', true: '#059669' }}
            thumbColor={autoMuteEnabled ? '#10B981' : '#94A3B8'}
          />
        </View>

        <View style={styles.dividerVertical} />

        <TouchableOpacity 
          style={[styles.instantSilentBtn, manualSilentMode && styles.instantSilentBtnActive]}
          onPress={() => setManualSilentMode(!manualSilentMode)}
        >
          <Ionicons name={manualSilentMode ? "notifications-off" : "notifications"} size={16} color="#FFF" />
          <Text style={styles.instantSilentText}>
            {manualSilentMode ? 'إلغاء الصمت' : t.manualMuteToggle}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Horizontal Prayer Times Carousel */}
      <View style={styles.timesRow}>
        {prayerTimes.map((p) => {
          const isTarget = p.key === nextInfo.nextPrayer.key;
          return (
            <View key={p.key} style={[styles.timeBox, isTarget && styles.timeBoxActive]}>
              <Text style={[styles.timeBoxName, isTarget && styles.timeBoxNameActive]}>{p.name}</Text>
              <Text style={[styles.timeBoxVal, isTarget && styles.timeBoxValActive]}>{p.time}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  cardContainer: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#334155',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 5,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  locationTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    flex: 1,
  },
  locationText: {
    color: '#CBD5E1',
    fontSize: 13,
    fontWeight: '600',
  },
  gpsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#0F172A',
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#334155',
  },
  gpsBtnText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },
  countdownSection: {
    alignItems: 'center',
    paddingVertical: 10,
    backgroundColor: '#0F172A',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  nextPrayerLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '500',
  },
  prayerNameHighlight: {
    color: '#10B981',
    fontWeight: '800',
    fontSize: 16,
  },
  timeRemainingText: {
    color: '#F8FAFC',
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: 1,
    marginVertical: 4,
  },
  prayerTimeTarget: {
    color: '#64748B',
    fontSize: 12,
    fontWeight: '500',
  },
  muteStatusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 14,
    marginTop: 12,
    gap: 12,
  },
  bannerMuted: {
    backgroundColor: '#064E3B',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  bannerNormal: {
    backgroundColor: '#0F172A',
    borderWidth: 1,
    borderColor: '#334155',
  },
  bannerIconBox: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bannerTextBox: {
    flex: 1,
  },
  bannerTitle: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
  },
  bannerSubtitle: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 2,
  },
  controlsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#334155',
  },
  toggleItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  toggleLabel: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  dividerVertical: {
    width: 1,
    height: 24,
    backgroundColor: '#334155',
    marginHorizontal: 8,
  },
  instantSilentBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#059669',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  instantSilentBtnActive: {
    backgroundColor: '#D97706',
  },
  instantSilentText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '700',
  },
  timesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
    gap: 4,
  },
  timeBox: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
    backgroundColor: '#0F172A',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#334155',
  },
  timeBoxActive: {
    backgroundColor: '#064E3B',
    borderColor: '#10B981',
  },
  timeBoxName: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '600',
  },
  timeBoxNameActive: {
    color: '#10B981',
    fontWeight: '800',
  },
  timeBoxVal: {
    color: '#F1F5F9',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 2,
  },
  timeBoxValActive: {
    color: '#F8FAFC',
    fontWeight: '800',
  },
});