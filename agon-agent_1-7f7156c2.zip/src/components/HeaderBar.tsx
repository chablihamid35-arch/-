import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, ScrollView } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../context/AppContext';
import { Language } from '../types';

const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: 'ar', label: 'العربية (الأصل)', flag: '🇸🇦' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'ur', label: 'أردو (Urdu)', flag: '🇵🇰' },
  { code: 'tr', label: 'Türkçe', flag: '🇹🇷' },
  { code: 'id', label: 'Bahasa Indonesia', flag: '🇮🇩' },
];

export const HeaderBar: React.FC = () => {
  const { language, setLanguage, t, manualSilentMode, setManualSilentMode, autoMuteEnabled } = useApp();
  const [langModalVisible, setLangModalVisible] = useState(false);

  const currentLangObj = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];

  return (
    <View style={styles.headerContainer}>
      <View style={styles.topRow}>
        <View style={styles.titleSection}>
          <Text style={styles.appTitle}>{t.appName}</Text>
          <View style={styles.badgeRow}>
            <View style={[styles.statusDot, manualSilentMode || autoMuteEnabled ? styles.dotGreen : styles.dotOrange]} />
            <Text style={styles.statusBadgeText}>
              {manualSilentMode ? t.mosqueModeOn : autoMuteEnabled ? 'الكتم التلقائي مفعّل' : 'الكتم بانتظار الأذان'}
            </Text>
          </View>
        </View>

        <View style={styles.actionsRow}>
          {/* Mosque Silent Mode Quick Toggle */}
          <TouchableOpacity 
            style={[styles.iconBtn, manualSilentMode && styles.iconBtnActive]} 
            onPress={() => setManualSilentMode(!manualSilentMode)}
            activeOpacity={0.8}
          >
            <Ionicons 
              name={manualSilentMode ? "notifications-off" : "notifications"} 
              size={20} 
              color={manualSilentMode ? "#FFD700" : "#E2E8F0"} 
            />
          </TouchableOpacity>

          {/* Language Picker Switcher */}
          <TouchableOpacity 
            style={styles.langBtn} 
            onPress={() => setLangModalVisible(true)}
            activeOpacity={0.8}
          >
            <Text style={styles.langFlag}>{currentLangObj.flag}</Text>
            <Text style={styles.langCode}>{language.toUpperCase()}</Text>
            <Ionicons name="chevron-down" size={14} color="#CBD5E1" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Language Modal Selector */}
      <Modal
        visible={langModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setLangModalVisible(false)}
      >
        <TouchableOpacity 
          style={styles.modalOverlay} 
          activeOpacity={1} 
          onPress={() => setLangModalVisible(false)}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Ionicons name="language-outline" size={24} color="#10B981" />
              <Text style={styles.modalTitle}>{t.languageSelect}</Text>
            </View>
            <ScrollView style={styles.langList}>
              {LANGUAGES.map((item) => (
                <TouchableOpacity
                  key={item.code}
                  style={[styles.langItem, language === item.code && styles.langItemActive]}
                  onPress={() => {
                    setLanguage(item.code);
                    setLangModalVisible(false);
                  }}
                >
                  <Text style={styles.langItemFlag}>{item.flag}</Text>
                  <Text style={[styles.langItemText, language === item.code && styles.langItemTextActive]}>
                    {item.label}
                  </Text>
                  {language === item.code && (
                    <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    backgroundColor: '#0F172A',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1E293B',
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  titleSection: {
    flex: 1,
  },
  appTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#F8FAFC',
    letterSpacing: 0.5,
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  dotGreen: {
    backgroundColor: '#10B981',
  },
  dotOrange: {
    backgroundColor: '#F59E0B',
  },
  statusBadgeText: {
    fontSize: 12,
    color: '#94A3B8',
    fontWeight: '500',
  },
  actionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  iconBtn: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: '#1E293B',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  iconBtnActive: {
    backgroundColor: '#064E3B',
    borderColor: '#10B981',
  },
  langBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E293B',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
    gap: 4,
    borderWidth: 1,
    borderColor: '#334155',
  },
  langFlag: {
    fontSize: 14,
  },
  langCode: {
    color: '#F1F5F9',
    fontSize: 12,
    fontWeight: '700',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    width: '100%',
    maxWidth: 360,
    padding: 20,
    borderWidth: 1,
    borderColor: '#334155',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
    paddingBottom: 12,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#F8FAFC',
  },
  langList: {
    maxHeight: 280,
  },
  langItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 12,
    marginBottom: 6,
    backgroundColor: '#0F172A',
  },
  langItemActive: {
    backgroundColor: '#064E3B',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  langItemFlag: {
    fontSize: 20,
    marginRight: 12,
  },
  langItemText: {
    fontSize: 15,
    color: '#CBD5E1',
    flex: 1,
    fontWeight: '500',
  },
  langItemTextActive: {
    color: '#F8FAFC',
    fontWeight: '700',
  },
});
